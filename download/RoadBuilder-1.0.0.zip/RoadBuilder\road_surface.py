"""道路路面生成（纯 Python，补片法）—— 对标 iCity 实测几何。

输入：网格的「边 = 道路中心线」（面 = 街区，忽略）。
输出：一张平面路面 mesh（verts, faces）。

几何规则：
  · 顶点 >=3 条边（交叉口）：补片 = 边长 2x路宽 的正方形，四角半径 路宽/2 的四分之一圆
    （圆心 = 正方形四角）；内部从顶点做扇形三角化（iCity 那种放射线），
    顶点落在轮廓外时自动改用耳切三角化。
  · 顶点 2 条边（路的拐弯）：四边形带（同心圆环），效果等同几何节点扫掠 ——
    内侧圆弧 R = 路宽/2、外侧圆弧 R = 1.5x路宽，两弧同心、角度一一对应，
    之间全是四边形（没有三角形）；两端端面垂直于路。
  · 顶点 1 条边：端头平截。
  · 每条路段的端头都在「距顶点 1 个路宽（90 度时）」处收口，两臂夹角越小伸得越远，
    超过臂长 45% 时自动缩半径。
  以上对任意夹角都成立（公式里只有点积，不含任何「垂直」假设）。
"""

import math


# ---------- 2D 向量小工具 ----------
def _sub(a, b): #这里是拿到两个顶点坐标，算方向向量的函数
    return (a[0] - b[0], a[1] - b[1])


def _add(a, b): #向量加法
    return (a[0] + b[0], a[1] + b[1])


def _mul(a, s): #向量乘法
    return (a[0] * s, a[1] * s)


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def _cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def _perp_ccw(a):
    return (-a[1], a[0])


def _norm(a):
    '''这里是向量的归一化，hypot是勾股定理函数，用于算三角形斜边的长度'''
    l = math.hypot(a[0], a[1])
    if l < 1e-12:
        return (0.0, 0.0)
    return (a[0] / l, a[1] / l)


def _angle_ccw(a, b):
    '''这里接受两个向量，返回的是他俩的夹角，一定是正数'''
    ang = math.atan2(_cross(a, b), _dot(a, b)) #这里因为算叉乘和点乘有可能会出现负数，因此算出来的ang有可能是负的
    return ang if ang >= 0.0 else ang + 2.0 * math.pi


def _line_isect(p, d, q, e):
    den = _cross(d, e)
    if abs(den) < 1e-12:
        return None
    dpq = _sub(q, p)
    return _cross(dpq, e) / den, _cross(dpq, d) / den


def _poly_area(pts):
    s = 0.0
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        s += x1 * y2 - x2 * y1
    return s * 0.5


def _point_in_tri(p, a, b, c, eps=1e-9):
    d1 = _cross(_sub(b, a), _sub(p, a))
    d2 = _cross(_sub(c, b), _sub(p, b))
    d3 = _cross(_sub(a, c), _sub(p, c))
    return ((d1 >= -eps and d2 >= -eps and d3 >= -eps) or
            (d1 <= eps and d2 <= eps and d3 <= eps))


# ---------- 圆弧 ----------
def _arc_center(ui, ni, wi, uj, nj, wj, r):
    """圆心：到两条侧线的有符号距离分别是 (wi/2 + r) 与 -(wj/2 + r)。"""
    c = _dot(ni, nj)
    s = _dot(ui, nj)
    if abs(s) < 1e-12:
        s = 1e-12
    x = (-(wj * 0.5 + r) - (wi * 0.5 + r) * c) / s
    return _add(_mul(ui, x), _mul(ni, wi * 0.5 + r))


def _tangent_pt(o, u, n, off):
    """O 在「过原点、方向 u、法向偏移 off」直线上的垂足。"""
    t = _dot(o, u)
    return (u[0] * t + n[0] * off, u[1] * t + n[1] * off)


def _fit_radius(ui, ni, wi, uj, nj, wj, r, max_i, max_j):
    """夹半径：切点不能跑出臂的两端之外（两端各留 45%）。"""
    for _ in range(10):
        o = _arc_center(ui, ni, wi, uj, nj, wj, r)
        di = _dot(_tangent_pt(o, ui, ni, wi * 0.5), ui)
        dj = _dot(_tangent_pt(o, uj, nj, -wj * 0.5), uj)
        over = 1.0
        if max_i > 0.0 and abs(di) > max_i:
            over = min(over, max_i / abs(di))
        if max_j > 0.0 and abs(dj) > max_j:
            over = min(over, max_j / abs(dj))
        if over >= 1.0 - 1e-9:
            return r
        r *= over
    return r


def _arc_pts(o, r, t_from, t_to, segments):
    a0 = math.atan2(t_from[1] - o[1], t_from[0] - o[0])
    a1 = math.atan2(t_to[1] - o[1], t_to[0] - o[0])
    da = a1 - a0
    while da <= -math.pi:
        da += 2.0 * math.pi
    while da > math.pi:
        da -= 2.0 * math.pi
    n = max(1, int(segments))
    pts = []
    for k in range(n + 1):
        a = a0 + da * (k / float(n))
        pts.append((o[0] + abs(r) * math.cos(a), o[1] + abs(r) * math.sin(a)))
    pts[0] = t_from
    pts[-1] = t_to
    return pts


def _corner_join(ui, wi, uj, wj, radius_ratio, max_i, max_j, arc_segments):
    """arm i（其 CCW 侧）与 arm j（其 CW 侧）之间这段边界，坐标以顶点为原点。"""
    ni = _perp_ccw(ui)
    nj = _perp_ccw(uj)
    theta = _angle_ccw(ui, uj)
    foot_i = _mul(ni, wi * 0.5)
    foot_j = _mul(nj, -wj * 0.5)

    if abs(theta - math.pi) <= 1e-6:        # 直通
        return [foot_i, foot_j]

    if theta > math.pi:                     # 外侧：尖角拼接
        hit = _line_isect(foot_i, ui, foot_j, uj)
        if hit is None:
            return [foot_i, foot_j]
        return [_add(foot_i, _mul(ui, hit[0]))]

    # 内侧：凹角圆弧，半径默认 路宽/2
    r = _fit_radius(ui, ni, wi, uj, nj, wj, radius_ratio * min(wi, wj), max_i, max_j)
    if abs(r) <= 1e-9:
        hit = _line_isect(foot_i, ui, foot_j, uj)
        if hit is None:
            return [foot_i, foot_j]
        return [_add(foot_i, _mul(ui, hit[0]))]
    o = _arc_center(ui, ni, wi, uj, nj, wj, r)
    ti = _tangent_pt(o, ui, ni, wi * 0.5)
    tj = _tangent_pt(o, uj, nj, -wj * 0.5)
    return _arc_pts(o, r, ti, tj, arc_segments)


def _deg2_ring(ui, wi, uj, wj, radius_ratio, max_i, max_j, segments):
    """顶点只有 2 条边（路的拐弯）：生成一圈同心圆环，全是四边形。

    返回 (inner_pts, outer_pts) 或 None。两组点按角度一一对应：
      inner_pts[0] 在 arm i 的 CCW 侧、[-1] 在 arm j 的 CW 侧（内侧弧 R = 路宽/2）
      outer_pts 同心，半径 = 内侧半径 + 路宽（外侧弧 R = 1.5 路宽）

    参数：ui/uj = 两条臂的单位方向；wi/wj = 两条路的路宽；
          radius_ratio = 内弧半径系数（0.5 → w/2）；
          max_i/max_j = 两条臂各自允许的最大切点距离（臂长 × 0.45）；
          segments = 圆弧分几段。
    """
    # ① 这条臂 i 逆时针转到臂 j 的角度。调用者保证传进来的这一对是「内侧那对」（< 180°）
    theta = _angle_ccw(ui, uj)
    # 夹角 ≈0（两臂几乎重叠）或 ≈180°（直路穿过）→ 没有圆角可做，交给通用路径兜底
    if not (1e-6 < theta < math.pi - 1e-6):
        return None
    ni = _perp_ccw(ui)                  # 臂 i 的左法线（单位向量）
    nj = _perp_ccw(uj)                  # 臂 j 的左法线（单位向量）
    tan_h = math.tan(theta * 0.5)       # 半夹角的 tan
    if tan_h < 1e-9:                    # 夹角太小 → tan 为 0，会除零
        return None
    w = min(wi, wj)                     # 两条路取窄的当基准
    r_in = radius_ratio * w             # 内弧半径（默认 0.5w）
    t = (w * 0.5 + r_in) / tan_h        # 切点沿臂的距离（内、外两条弧的 t 相同，见下）
    lim = min([x for x in (max_i, max_j) if x > 0] or [1e9])   # 允许的最大切点距离
    if t > lim:                         # 切点要伸出臂外了 → 把半径缩回来
        r_in = max(0.0, lim * tan_h - w * 0.5)   # 因为 t=(w/2+r)/tan 与 r 线性 → 直接反解
    if r_in <= 1e-9:                    # 缩到没有半径了 → 放弃
        return None
    o = _arc_center(ui, ni, wi, uj, nj, wj, r_in)     # 圆心：到两条内边线距离都 = r_in
    ti = _tangent_pt(o, ui, ni, wi * 0.5)             # 臂 i 一侧的切点（CCW 侧边线上）
    tj = _tangent_pt(o, uj, nj, -wj * 0.5)            # 臂 j 一侧的切点（CW 侧边线上）
    r_out = r_in + w                    # 外弧半径 = 内弧 + 一个路宽 → 与内弧同心
    di = _norm(_sub(ti, o))             # 从圆心指向「臂 i 那个切点」的单位方向
    dj = _norm(_sub(tj, o))             # 从圆心指向「臂 j 那个切点」的单位方向
    a0 = math.atan2(di[1], di[0])       # 起点角度（相对 +X 轴）
    a1 = math.atan2(dj[1], dj[0])       # 终点角度
    da = a1 - a0                        # 扫过的角度
    while da <= -math.pi:               # 把 da 归一到 (−180°, 180°]：
        da += 2.0 * math.pi
    while da > math.pi:                 # 总是走「短的那一边」绕
        da -= 2.0 * math.pi
    n = max(2, int(segments))           # 至少分 2 段
    inner, outer = [], []               # 内弧点列、外弧点列
    for k in range(n + 1):              # 从 0 到 n 共 n+1 个角度
        a = a0 + da * (k / float(n))    # 第 k 个角度（线性插值）
        vec = (math.cos(a), math.sin(a))          # 该角度上的单位方向（相对圆心）
        inner.append(_add(o, _mul(vec, r_in)))    # 内弧点 = 圆心 + r_in × 方向
        outer.append(_add(o, _mul(vec, r_out)))   # 外弧点 = 圆心 + r_out × 同一方向
    inner[0], inner[-1] = ti, tj                  # 首尾直接钉成精确切点（避免浮点误差）
    outer[0] = _add(o, _mul(di, r_out))           # 外弧首点 = 圆心 + r_out × 同方向
    outer[-1] = _add(o, _mul(dj, r_out))          # 外弧末点 = 圆心 + r_out × 同方向
    return inner, outer                 # 调用者用它配成 n 个四边形


# ---------- 补片三角化（>=3 条边时用） ----------
def _fan(ci, idxs, pts):
    tris = []
    total = 0.0
    for k in range(len(idxs)):
        i1, i2 = idxs[k], idxs[(k + 1) % len(idxs)]
        if i1 == ci or i2 == ci or i1 == i2:
            continue
        a = _poly_area([pts[ci], pts[i1], pts[i2]])
        if a <= 1e-12:
            return [], False
        total += a
        tris.append((ci, i1, i2))
    return tris, True


def _clean_collinear(idxs, pts, eps=1e-9):
    out = list(idxs)
    changed = True
    while changed and len(out) > 3:
        changed = False
        n = len(out)
        for k in range(n):
            a, b, c = pts[out[(k - 1) % n]], pts[out[k]], pts[out[(k + 1) % n]]
            if abs(_cross(_sub(b, a), _sub(c, b))) <= eps:
                out.pop(k)
                changed = True
                break
    return out


def _ear_clip(idxs, pts):
    """耳切三角化（简单多边形，逆时针）。顶点落在轮廓外时兜底用。"""
    idxs = _clean_collinear(idxs, pts)
    order = list(range(len(idxs)))
    tris = []
    guard = 0
    while len(order) > 3 and guard < 20000:
        guard += 1
        m = len(order)
        clipped = False
        for k in range(m):
            i0, i1, i2 = order[(k - 1) % m], order[k], order[(k + 1) % m]
            p0, p1, p2 = pts[idxs[i0]], pts[idxs[i1]], pts[idxs[i2]]
            if _poly_area([p0, p1, p2]) <= 1e-10:
                continue
            hit = False
            for j in order:
                if j in (i0, i1, i2):
                    continue
                if _point_in_tri(pts[idxs[j]], p0, p1, p2, eps=-1e-10):
                    hit = True
                    break
            if hit:
                continue
            tris.append((idxs[i0], idxs[i1], idxs[i2]))
            order.pop(k)
            clipped = True
            break
        if not clipped:
            break
    if len(order) == 3:
        tris.append((idxs[order[0]], idxs[order[1]], idxs[order[2]]))
    return tris


# ---------- 主函数 ----------
def build_road_surface(points, edges, width, radius_ratio=0.5, arc_segments=8, z=None):
    """把「边 = 道路中心线」的网格算成「有宽度的路面」。

    输入：
      points : [(x, y), ...]              顶点坐标（顶点 = 路段端点 / 交叉口）
      edges  : [(a, b), ...]              边（每条边 = 一条道路的中心线）
      width  : 路宽 w（中心线左右各 w/2）
      radius_ratio : 转角圆弧半径系数（默认 0.5 → 半径 = w/2，对应 iCity 实测）
      arc_segments : 每段圆弧分几段（默认 8）
      z      : 可选，每个顶点的 z（给了才输出 3D 点）

    输出：
      verts  : [(x, y[, z]), ...]         点坐标表
      faces  : [(0,1,2,3), (0,8,9,1), ...] 面 = 顶点编号的列表（没有坐标）
      info   : 统计信息（strips/patches/ring_quads/degenerate...）

    整体流程：① 建邻接表 → ② 逐顶点把臂排序、算每个间隙的边界点
             → ③ 给点编号去重 → ④ 用编号拼面（路段带子 / 拐弯圆环 / 交叉口补片）
    """
    # ============ ① 建邻接表：谁跟谁连着 ============
    nv = len(points)                        # 顶点总数
    adj = [[] for _ in range(nv)]           # adj[v] = 顶点 v 的所有邻居（下标就是顶点编号）
    for (a, b) in edges:                    # 遍历每一条边
        if a == b:                          # 自己连自己（退化边）→ 跳过
            continue
        adj[a].append(b)                    # 把 b 记进 a 的邻居表
        adj[b].append(a)                    # 把 a 记进 b 的邻居表（无向图，两边都要记）

    half = width * 0.5                      # 半路宽：后面偏移边线全靠它

    def arm_dir(v, n): #这里传入的参数都是索引
        """求「从顶点 v 指向邻居 n」这条臂的单位方向 u 和臂长 L。"""
        d = _sub(points[n], points[v])      # 方向向量 = 邻居坐标 − 顶点坐标（2D 相减，扔掉 z）
        return _norm(d), math.hypot(d[0], d[1])   # 返回：(单位方向 u, 臂长 L)

    # 下面四个字典，key 里带顶点编号，逐个顶点算完后登记进去
    side_pt = {}          # (顶点, 邻居) -> (CCW 侧点, CW 侧点)：这条路在这一端的「横截面」两个端点
    side_z = {}           # (顶点, 邻居) -> 该端点的 z（沿用所属顶点的 z）
    corner_loops = {}     # 顶点 -> 交叉口补片的一圈轮廓点（≥3 条臂时用）
    rings = {}            # 顶点 -> (内弧点列, 外弧点列)：拐弯处的同心圆环（2 条臂时用）
    xwalk_inters = []     # 路口顶点 (x, y, tau)：边线要避开这些位置的核心区
    xwalk_slot_ids = []   # 与 xwalk_slots 平行：每条停车线属于 (顶点号, 邻居顶点号)
    xwalk_inters_ids = [] # 与 xwalk_inters 平行：路口顶点的原始顶点号
    xwalk_slots = []      # 斑马线槽位：路口每条臂一个（横截面两点 + 臂方向 + 高度）

    # ============ ② 逐个顶点处理 ============
    for v in range(nv):                     # 遍历所有顶点
        nb = adj[v]                         # 这个顶点的邻居列表，这个adj[]数组里装的是相邻顶点的索引
        deg = len(nb)                       # 度 = 这个顶点有几条臂
        if deg == 0:                        # 孤立点（没有任何边）→ 不管
            continue
        c = points[v]                       # 顶点自身坐标（后面所有「局部坐标」都要加回它）
        zv = z[v] if z else None            # 该顶点的 z（没给 z 就是 None）

        # ---- 情况 1：只有 1 条边 → 端头直接平截，没有转角 ----
        if deg == 1:
            u, _ = arm_dir(v, nb[0])        # 这条臂的方向
            n = _perp_ccw(u)                # 左法线 = 把 u 逆时针转 90°
            side_pt[(v, nb[0])] = (_add(c, _mul(n, half)),      # 横截面两个端点：
                                   _add(c, _mul(n, -half)))     # 顶点 ± (w/2)·n
            side_z[(v, nb[0])] = zv
            continue                        # 这个顶点处理完了

        # ---- 通用准备：把臂按角度（相对 +X 轴）升序排序 ----
        arms = []                           # 每项 = (atan2 角度, 邻居编号, 单位方向, 臂长)
        for m_i in nb:                      # 遍历这个顶点的每条臂
            u, ln = arm_dir(v, m_i)         # 求方向与长度，这个函数传入的是顶点的索引，返回这俩顶点构成的方向向量和该方向向量的长度
            arms.append((math.atan2(u[1], u[0]), m_i, u, ln))   # 记下：相对 +X 轴的角度，这个math.atan2(u[1], u[0])就是算和+x的夹角
        arms.sort(key=lambda t: t[0])       # 按角度升序排 → 得到一圈逆时针的环形顺序
        m = len(arms)                       # 臂的条数（= deg）

        # ---- 情况 2：2 条边 → 路的拐弯 → 同心圆环四边形带 ----
        if deg == 2:
            theta0 = _angle_ccw(arms[0][2], arms[1][2]) #臂0→臂1逆时针转过的角度（0~360°）
            if abs(theta0 - math.pi) <= 1e-6:
                # 两条臂正好反向（直路穿过）→ 不生成补片，两臂各自平截
                for k in range(2):                            #这里就是把在法向量上移动得到的顶点算出来，存到side_pt这个键值对里
                    n = _perp_ccw(arms[k][2])                 # 该臂的左法线
                    side_pt[(v, arms[k][1])] = (_add(c, _mul(n, half)),
                                                _add(c, _mul(n, -half)))
                    side_z[(v, arms[k][1])] = zv
                continue
            ik = 0 if theta0 < math.pi else 1   # 「内侧那对」= 夹角 < 180° 的那一对臂
            nk = (ik + 1) % 2                   # 另一条臂
            #上边theta0这个判断其实是为了找出内侧角，因为_deg2_ring这个函数需要的是两个向量的夹角小于180，且里边的计算顺序定了，必须是臂 i 逆时针转到臂 j 的角度小于180，因此通过theta0去决定哪个向量放在前边
            res = _deg2_ring(arms[ik][2], width, arms[nk][2], width,     # 算同心圆环：
                             radius_ratio,                               #   内弧半径系数
                             arms[ik][3] * 0.45, arms[nk][3] * 0.45,     #   两条臂各留 45% 做上限
                             arc_segments)                               #   弧分几段
            if res is not None:                 # 算成功
                inner, outer = res              # inner/outer：内弧、外弧上的点（各 N+1 个，角度一一对应）
                rings[v] = (inner, outer)       # 登记这个圆环（局部坐标，后面再加 c）
                side_pt[(v, arms[ik][1])] = (_add(inner[0], c), _add(outer[0], c))    # 臂 ik 的横截面
                side_pt[(v, arms[nk][1])] = (_add(outer[-1], c), _add(inner[-1], c))  # 臂 nk 的横截面
                side_z[(v, arms[ik][1])] = zv
                side_z[(v, arms[nk][1])] = zv
                continue                        # 这个顶点处理完了
            # res 为 None（半径被夹没了）→ 落到下面通用路径兜底

        # ---- 情况 3：≥3 条边 → 交叉口补片 ----
        joins = []                              # 每个「间隙」的边界点列（从臂 k 的 CCW 侧 到 臂 k+1 的 CW 侧）
        _ds_x = []
        for k in range(m):
            _, _, ui, li = arms[k]              # 第 k 条臂：方向 ui、长度 li
            _, _, uj, lj = arms[(k + 1) % m]    # 下一条臂（绕回 0）
            joins.append(_corner_join(ui, width, uj, width, radius_ratio,   # 算这段转角：
                                      li * 0.45, lj * 0.45,                 #   切点不超臂长 45%
                                      arc_segments))                        #   圆弧 / 直通 / 尖角
        # 把每个间隙的两个端点，登记到对应臂的两侧
        for k in range(m):
            _, n_k, _, _ = arms[k]              # 第 k 条臂通向的邻居编号
            side_pt[(v, n_k)] = (_add(joins[k][0], c),          # 该臂「CCW 侧」点 = 本间隙的起点
                                 _add(joins[(k - 1) % m][-1], c))  # 该臂「CW 侧」点 = 上一个间隙的终点
            side_z[(v, n_k)] = zv
            # 斑马线槽位：这条臂上「切线之外」的中心线点。
            # 两侧相邻间隙的切线距离取大者（直通那侧切线在顶点上，算 0）。
            u_k = arms[k][2]
            th_a = _angle_ccw(arms[(k - 1) % m][2], u_k)
            th_b = _angle_ccw(u_k, arms[(k + 1) % m][2])
            r_x = radius_ratio * width
            d_a = (width * 0.5 + r_x) / math.tan(th_a * 0.5) if th_a < math.pi - 1e-9 else 0.0
            d_b = (width * 0.5 + r_x) / math.tan(th_b * 0.5) if th_b < math.pi - 1e-9 else 0.0
            d_x = min(max(max(d_a, d_b), 0.0), 0.45 * arms[k][3])
            xwalk_slots.append((_add(c, _mul(u_k, d_x)), u_k, width, zv))
            xwalk_slot_ids.append((v, arms[k][1]))
            _ds_x.append(d_x)

        xwalk_inters.append((c[0], c[1], max(_ds_x) if _ds_x else 0.0))
        xwalk_inters_ids.append(v)
        # 拼出这个交叉口的补片轮廓（一圈）：逐臂「弦」+ 间隙的「弧」
        loop = []
        for k in range(m):
            _, n_k, _, _ = arms[k]
            p_ccw, p_cw = side_pt[(v, n_k)]     # 该臂两侧的两个点（就是这一端的弦）
            loop.append(p_cw)                   # 弦的一端
            loop.append(p_ccw)                  # 弦的另一端
            loop.extend([_add(p, c) for p in joins[k][1:-1]])   # 间隙圆弧的中间点（首尾已在弦上）
        clean = []                              # 清理：去掉相邻重复点（间距 < 1e-7 视为同一个点）
        for p in loop:
            if not clean or math.hypot(p[0] - clean[-1][0], p[1] - clean[-1][1]) > 1e-7:
                clean.append(p)
        if len(clean) > 2 and math.hypot(clean[0][0] - clean[-1][0],    # 首尾也重复的话去掉末尾那个
                                        clean[0][1] - clean[-1][1]) <= 1e-7:
            clean.pop()
        corner_loops[v] = clean

    # ============ ③ 点去重 + 编号 ============
    verts = []                              # 输出：点坐标表
    vidx = {}                               # 坐标 -> 编号 的字典（去重用）

    def vid(p, zv):
        """给一个坐标分配编号；同一个坐标永远返回同一个编号（这就是「无缝」的来源）。"""
        key = (round(p[0], 6), round(p[1], 6))      # 坐标取 6 位小数当键（吃掉浮点误差）
        i = vidx.get(key)
        if i is None:                                # 没见过这个坐标 → 新增
            i = len(verts)
            vidx[key] = i
            verts.append(p if zv is None else (p[0], p[1], zv))   # 有 z 就存 3D 点
        return i                                     # 返回编号

    faces = []                              # 输出：面（每个面 = 一串顶点编号）
    stats = {'degenerate': 0, 'strips': 0, 'patches': 0, 'patches_clipped': 0,
             'ring_quads': 0}               # 统计（方便自检）

    # ============ ④-1 路段带子：每条边一个四边形 ============
    for (a, b) in edges:                    # 遍历每条边
        if a == b or (a, b) not in side_pt or (b, a) not in side_pt:
            continue                        # 退化边 / 缺端面（比如孤立边）→ 跳过
        a_ccw, a_cw = side_pt[(a, b)]       # a 端的两个端点（左、右）
        b_ccw, b_cw = side_pt[(b, a)]       # b 端的两个端点（注意：从 b 看，ccw 侧是另一侧）
        za = side_z[(a, b)]                 # a 端的 z
        zb = side_z[(b, a)]                 # b 端的 z
        quad = [vid(a_ccw, za), vid(a_cw, za), vid(b_ccw, zb), vid(b_cw, zb)]  # 四边形 = 4 个编号
        area = _poly_area([verts[i][:2] for i in quad])     # 有向面积（判断绕向 + 退化）
        if len(set(quad)) < 3 or abs(area) <= 1e-9:         # 点重复 / 面积≈0 → 视为退化面
            stats['degenerate'] += 1
            continue
        if area < 0:                        # 面积是负的 = 顺时针绕
            quad = quad[::-1]               # 反转顺序 → 统一成逆时针（法线朝上）
        faces.append(quad)                  # 收下这个面
        stats['strips'] += 1                # 计数

    # ============ ④-2 拐弯圆环带：每个圆环 N 个四边形 ============
    for v, (inner, outer) in rings.items():     # 遍历所有拐弯
        c = points[v]                           # 该顶点的坐标（把局部坐标加回去）
        zv = z[v] if z else None
        for k in range(len(inner) - 1):         # 内弧相邻两点配一对
            quad = [vid(_add(inner[k], c), zv), vid(_add(inner[k + 1], c), zv),
                    vid(_add(outer[k + 1], c), zv), vid(_add(outer[k], c), zv)]  # 内弧一格 + 外弧对应一格
            area = _poly_area([verts[i][:2] for i in quad])
            if len(set(quad)) < 3 or abs(area) <= 1e-9:
                stats['degenerate'] += 1
                continue
            if area < 0:
                quad = quad[::-1]
            faces.append(quad)
            stats['ring_quads'] += 1

    # ============ ④-3 交叉口补片：从顶点扇形三角化 ============
    for v, loop in corner_loops.items():        # 遍历所有交叉口
        if len(loop) < 3:                       # 轮廓点太少 → 不成面
            continue
        a = _poly_area(loop)                    # 轮廓的有向面积
        if abs(a) <= 1e-9:                      # 面积≈0 → 退化
            stats['degenerate'] += 1
            continue
        if a < 0:                               # 轮廓是顺时针 → 反转成逆时针
            loop = list(reversed(loop))
            a = -a
        c = points[v]                           # 顶点坐标 = 扇形三角化的中心
        zv = z[v] if z else None
        ci = vid(c, zv)                         # 中心点的编号
        uniq = []                               # 把轮廓点转成编号，并去掉相邻重复
        for p in loop:
            i = vid(p, zv)
            if not uniq or uniq[-1] != i:
                uniq.append(i)
        if len(uniq) > 1 and uniq[0] == uniq[-1]:
            uniq.pop()
        if len(uniq) < 3:
            continue
        pts2 = [p[:2] for p in verts]           # 所有点的 2D 坐标（下面算面积用）
        tris, ok = _fan(ci, uniq, pts2)         # 先试「从中心点扇形三角化」
        if not ok or abs(sum(_poly_area([pts2[t[0]], pts2[t[1]], pts2[t[2]]])   # 扇形不成立：
                             for t in tris) - a) > max(1e-6, 1e-6 * a):         #   三角形面积和 ≠ 轮廓面积
            tris = _ear_clip(uniq, pts2)        # （顶点落在轮廓外）→ 改用耳切三角化
            if tris:
                stats['patches_clipped'] += 1   # 记录「走了耳切」的次数
        made = 0
        for (i0, i1, i2) in tris:                       # 逐个三角形收下
            if i0 == i1 or i1 == i2 or i0 == i2:
                continue                                # 三点有重复 → 跳过
            ar = _poly_area([pts2[i0], pts2[i1], pts2[i2]])
            if abs(ar) <= 1e-12:                        # 面积≈0（三点共线）→ 退化
                stats['degenerate'] += 1
                continue
            faces.append([i0, i1, i2] if ar > 0 else [i0, i2, i1])   # 统一次序（法线朝上）
            made += 1
        if made:                                        # 该交叉口至少出了一个面
            stats['patches'] += 1

    # ============ ⑤ 返回结果 ============
    info = {'verts': len(verts), 'faces': len(faces)}
    info.update(stats)                      # 把统计信息并进去
    info['crosswalk_slots'] = xwalk_slots   # 路口每条臂的斑马线槽位
    info['intersections'] = xwalk_inters
    info['slot_ids'] = xwalk_slot_ids
    info['intersection_ids'] = xwalk_inters_ids
    return verts, faces, info               # 交给 operator → from_pydata(verts, [], faces)


def poly_area(pts):
    return _poly_area(pts)