# -*- coding: utf-8 -*-
"""车流：路线生成 + 车辆摆放 + IDM 仿真 + 烘焙关键帧（Blender 内出动画）

★★ 信号唯一真源 = trafficlight 的相位表 ★★
    车到停车线前用 trafficlight.can_go(plan, loc, group, role) 查"能不能过"，
    绝不再自己算绿信比 —— 上一版"车不理灯"的根源就是仿真硬编码了 45%/45%，
    而灯的动画是另一套。

设计要点（都是上一轮踩出来的）
────────────────────────────────────────────────────────────
1) 路线 = 有向车道段随机游走 + 路口**解析倒角**（直线→圆弧→直线，R=路宽/2），
   收尾朝起点收敛 ⇒ **闭合环路**（车跑到头平滑回绕，不瞬移）。
2) 前车 = 投影到本车路线（横向 ≤2.6m、前方 ≤40m）+ **必须是同一段车道/同一条连接线**
   （路径身份）。否则路口里"隔壁连接线"的车会被当成前车 ⇒ 两车互相堵死在路口。
3) 停车线：每个进口臂一个，位置取**场景里那盏灯的位置**（车正好停在灯前）；
   红绿由相位表决定：group 直接读灯的 rb_phase（保证和灯绝对一致），
   role 按转向几何算（左转 = 左；直行/右转 = 直行档，与灯的分组一致）。
4) 车的姿态：只驱动**骨架 rig**（mesh 是它的子级）：
       rig.matrix_world = T(位置) @ Rz(偏航) @ T(-车体中心) @ 库里静止矩阵
   克隆必须用会话级库里的**静止姿态**、且保住父子、共享 mesh 数据。
"""

import math
import random

import bpy
from mathutils import Vector

_BLEND_D = 6.0     # 航向混合：只在弯口(接缝)前这么多米内才开始转
TAG_VEH = "rb_veh"
_S = None          # 当前设置（车轮动画读参数）

# 最后一次生成的统计（自检/测试用）
LAST_INFO = {}
LAST_XREF = []      # (路口, 臂, 按臂查表组, 看灯组, 灯名) 两种取法不一致的记录
LAST_FACE = (None, 0, 0.0)   # 灯面朝向自校准：(偏移K度, 参与灯数, 离散度)
_FACE_K = [None]             # 本次生成用的 K
_FACE_K_MEMO = [None, None]   # K 的计算缓存（含参与灯数/离散度）

# ── IDM 参数（跟车模型）────────────────────────────────────────────
A_MAX = 1.6
B_COMF = 2.0
T_HEAD = 1.4
S0 = 2.0
DELTA = 4.0
CAR_LEN = 5.0

_FPS = 24.0


# ════════════════════════════════════════════════════════════════
#  一、几何小工具
# ════════════════════════════════════════════════════════════════

def _unit(dx, dy):
    L = math.hypot(dx, dy)
    return None if L < 1e-12 else (dx / L, dy / L)


def lane_offsets(w, ratio=0.5):
    """一侧两条车道的**中心线偏移**（相对道路轴线）。返回如 [1.875, 5.625]。"""
    b = [0.0, w * 0.5 * ratio, w * 0.5]
    return [(b[i] + b[i + 1]) * 0.5 for i in range(len(b) - 1)]


def poly_len(pts):
    return sum(math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1])
               for i in range(len(pts) - 1))


def mk_sampler(path):
    """返回 (累积弧长表, 总长, 采样函数 s→(x, y, ux, uy))。"""
    acc = [0.0]
    for i in range(len(path) - 1):
        acc.append(acc[-1] + math.hypot(path[i + 1][0] - path[i][0],
                                        path[i + 1][1] - path[i][1]))
    total = acc[-1]

    def smp(s):
        if total <= 0:
            return (path[0][0], path[0][1], 1.0, 0.0)
        s = s % total
        lo, hi = 0, len(acc) - 1
        while lo < hi - 1:
            mid = (lo + hi) // 2
            if acc[mid] <= s:
                lo = mid
            else:
                hi = mid
        k = min(lo, len(path) - 2)
        seg = acc[k + 1] - acc[k]
        f = 0.0 if seg < 1e-9 else (s - acc[k]) / seg
        ax, ay = path[k]
        bx, by = path[k + 1]
        u1 = _unit(bx - ax, by - ay) or (1.0, 0.0)
        # ★★ 航向连续化（转弯丝滑的关键）：切线 = 本段方向 与 下一段方向 的线性混合。
        #   原来直接返回"本段方向"⇒ 航向在每段之间突变（16 段时每段跳 5.6°）⇒ 车一顿一顿。
        #   混合后航向本身连续，分段数只影响"贴圆的程度"，顺滑不再靠它。
        if len(path) >= 3:
            kk = k + 1
            if kk >= len(path) - 1:
                kk = 0                                   # 闭环：接回第一段
            u2 = _unit(path[kk + 1][0] - path[kk][0], path[kk + 1][1] - path[kk][1])
            if u2 is not None:
                # ★ 只在【离接缝 6 米以内】才混合航向。
                #   原来按整段比例混合 ⇒ 长直段会一路慢慢歪
                #   （用户看到的现象：入弯前车身已经侧着了 ✗）
                _rem = (1.0 - f) * seg
                _w = 1.0 - _rem / _BLEND_D
                if _w > 0.0:
                    _w = min(1.0, _w)
                    mx = (1.0 - _w) * u1[0] + _w * u2[0]
                    my = (1.0 - _w) * u1[1] + _w * u2[1]
                    n2 = math.hypot(mx, my)
                    if n2 > 1e-6:
                        u1 = (mx / n2, my / n2)
        return (ax + (bx - ax) * f, ay + (by - ay) * f, u1[0], u1[1])

    return acc, total, smp


def push(pts, q):
    """加点（连续重复点去掉，避免 0 长度段）。"""
    if pts and math.hypot(q[0] - pts[-1][0], q[1] - pts[-1][1]) < 1e-6:
        return
    pts.append((float(q[0]), float(q[1])))


def turn_fillet(p_in, u_in, p_out, u_out, R):
    """解析倒角：直线 → 圆弧 → 直线（返回额外要插的点，不含首尾）。

    p_in/p_out：两条直线的"虚拟交点"附近的点；u_in/u_out：进出方向单位向量。
    做法：两条线延长相交得虚拟角点 P，再按 R 算切点 T1/T2 与圆心 O。
    """
    d = _unit(u_in[0] + u_out[0], u_in[1] + u_out[1])     # 角平分线方向
    if d is None:
        return []
    cos_h = max(-1.0, min(1.0, u_in[0] * u_out[0] + u_in[1] * u_out[1]))
    ang = math.acos(cos_h)                                 # 转向角
    if ang < math.radians(1.0) or ang > math.radians(179.0):
        return []
    tau = R * math.tan(ang * 0.5)
    P = (p_in[0] + u_in[0] * tau, p_in[1] + u_in[1] * tau)
    n_in = (u_in[1], -u_in[0])
    cross = u_in[0] * u_out[1] - u_in[1] * u_out[0]
    sgn = 1.0 if cross > 0 else -1.0
    O = (P[0] + n_in[0] * (R * sgn), P[1] + n_in[1] * (R * sgn))
    a0 = math.atan2(P[1] - O[1], P[0] - O[0])
    n = 8
    out = []
    for i in range(1, n):
        t = a0 + (math.pi * 0.5 * sgn) * (i / float(n))
        out.append((O[0] + R * math.cos(t), O[1] + R * math.sin(t)))
    return out


# ════════════════════════════════════════════════════════════════
#  二、路线生成（车道段随机游走 + 倒角 + 闭合）
# ════════════════════════════════════════════════════════════════

def _vertex_info(pts, edges):
    """每个顶点的邻接、度、以及（度=2 时）转弯半径用的夹角。"""
    adj = {}
    for eid, (a, b) in enumerate(edges):
        adj.setdefault(a, []).append((b, eid))
        adj.setdefault(b, []).append((a, eid))
    return adj


def lane_routes(pts, edges, road_w=15.0, lane_ratio=0.5, lane_index=0,
                n=1, seed=0, target_len=750.0, bend_r=None, movement=None,
                turn_radius=None, turn_seg=16, road_ratio=0.5, lane_shift=0.0):
    """生成 n 条路线（每条都是**闭合环路**）。

    几何：先取车道中心线（相对轴线偏移），到路口/拐角处做**解析倒角**：
    把相邻两段的车道中心线延长求交得虚拟角点 P，切距 tau = R*tan(δ/2)，
    得到切点 T1（本段）/ T2（下一段）与圆弧。

    ★ 关键（踩过坑）：**必须按切点修剪**。上一版把整段车道线画到端点再加圆弧，
      相邻两段之间会留 0.5~1m 的豁口 ⇒ 车每过一个弯就"跳"一下。
      另外闭环时要把首点对齐到收尾切点（否则每圈在接缝处跳一次）。
    """
    offs = lane_offsets(road_w, lane_ratio)
    if not edges or not offs:
        return []
    # ★ 按动作分车道（用户需求）：
    #     movement="left"    → 走【靠黄线的内侧车道】，每个路口优先左转
    #     movement="through" → 走【外侧车道】，每个路口优先直行（没直行就右转）
    #   ⇒ 左转车和直行/右转车各排各的队，后者等绿灯时不会挡住前者
    if movement == "left":
        _li = 0
    elif movement == "through":
        _li = min(1, len(offs) - 1)
    else:
        _li = max(0, min(len(offs) - 1, int(lane_index)))
    # ★ 车道内横向微调（面板「车道内横向微调」）：负 = 往黄线侧挪。
    #   车的落位以【车体包围盒中心】为准，模型本身（后视镜/天线等）可能让视觉重心略偏，
    #   所以留一个可调量由肉眼校准。
    off = offs[_li] + float(lane_shift)
    # ★ 转弯半径：默认取"路宽一半"，但两个【对向左转】的圆弧净间距 = 2√2·|R−车道偏移| − 2R，
    #   R=7.5 时只有 0.9m ⇒ 车宽 2m ⇒ 车身必然在路口中间互相咬住。
    #   调大到 10~12m，间距升到 3~4.6m ⇒ 对向左转不再重叠（真实路口左转半径也是 10~15m）。
    R_fil = float(turn_radius) if (turn_radius and float(turn_radius) > 0.5) else road_w * 0.5
    R_bend = road_w if bend_r is None else bend_r
    adj = _vertex_info(pts, edges)
    rr = random.Random(seed)
    edge_ids = list(range(len(edges)))
    routes = []

    def lane_line(a, b):
        u = _unit(pts[b][0] - pts[a][0], pts[b][1] - pts[a][1])
        if u is None:
            return None
        r = (u[1], -u[0])
        p0 = (pts[a][0] + r[0] * off, pts[a][1] + r[1] * off)
        p1 = (pts[b][0] + r[0] * off, pts[b][1] + r[1] * off)
        return p0, p1, u, r

    def line_intersect(p0, u0, p1, u1):
        den = u0[0] * (-u1[1]) - u0[1] * (-u1[0])
        if abs(den) < 1e-9:
            return None
        dx, dy = p1[0] - p0[0], p1[1] - p0[1]
        t = (dx * (-u1[1]) - dy * (-u1[0])) / den
        return (p0[0] + u0[0] * t, p0[1] + u0[1] * t)

    def _cls_rank(u_now, v_to):
        """候选方向的"动作类别"打分：按 movement 偏好排序（越小越优先）。"""
        u_o = _unit(pts[v_to][0] - pts[cur_b_ref[0]][0],
                    pts[v_to][1] - pts[cur_b_ref[0]][1])
        if u_o is None:
            return 9
        cosd = max(-1.0, min(1.0, u_now[0] * u_o[0] + u_now[1] * u_o[1]))
        ang = math.acos(cosd)
        cr = u_now[0] * u_o[1] - u_now[1] * u_o[0]
        if ang < math.radians(5.0):
            cls = "S"
        elif cr > 0:
            cls = "L"
        else:
            cls = "R"
        if movement == "left":
            return {"L": 0, "S": 1, "R": 2}[cls]
        if movement == "through":
            return {"S": 0, "R": 1, "L": 2}[cls]
        return 0

    cur_b_ref = [0]                                  # _cls_rank 用（当前臂的端点）

    for ci in range(max(1, int(n))):
        for _att in range(6):                    # 收尾失败就重试
            closed = False
            e0 = rr.choice(edge_ids)
            a, b = edges[e0]
            if rr.random() < 0.5:
                a, b = b, a
            start_v, start_nbr = a, b
            route = []
            guard = 0
            closing = False
            seen = set()
            cur_a, cur_b, cur_eid = a, b, e0
            entry = None
            while guard < 400:
                guard += 1
                ll = lane_line(cur_a, cur_b)
                nb = adj.get(cur_b, [])
                if ll is None or not nb:
                    break
                p0, p1, u, r = ll
                if entry is not None:
                    t0 = (entry[0] - p0[0]) * u[0] + (entry[1] - p0[1]) * u[1]
                else:
                    t0 = 0.0
                t1 = math.hypot(p1[0] - p0[0], p1[1] - p0[1])
                cur_b_ref[0] = cur_b
                if t1 - t0 < 1.0:
                    break
                # 先选下一段（要知道它才能算倒角切点）
                cand = [(v, e) for (v, e) in nb if not (v == cur_a and e == cur_eid)]
                if not cand:
                    break
                if closing:
                    if cur_b == start_v and any(v == start_nbr and e == e0 for (v, e) in cand):
                        nx = (start_nbr, e0)
                        closing_last = True
                    else:
                        bd = {start_v: 0}
                        q = [start_v]
                        while q:
                            x = q.pop(0)
                            for (v2, _e2) in adj.get(x, []):
                                if v2 not in bd:
                                    bd[v2] = bd[x] + 1
                                    q.append(v2)
                        pool = [t for t in cand if t[0] == start_v or t[0] not in seen] or cand
                        if cur_b == start_nbr:
                            pool = [t for t in pool if t[0] != start_v] or pool
                        if movement in ("left", "through") and pool:
                            _bk2 = min(_cls_rank(u, t[0]) for t in pool)
                            _p2 = [t for t in pool if _cls_rank(u, t[0]) == _bk2]
                            nx = min(_p2, key=lambda t: (bd.get(t[0], 10 ** 9), t[0]))
                        else:
                            nx = min(pool, key=lambda t: (bd.get(t[0], 10 ** 9), t[0]))
                        seen.add(nx[0])
                        closing_last = False
                else:
                    if movement in ("left", "through"):
                        _bk = min(_cls_rank(u, t[0]) for t in cand)
                        _pl = [t for t in cand if _cls_rank(u, t[0]) == _bk]
                        nx = rr.choice(_pl)
                    else:
                        nx = rr.choice(cand)
                    closing_last = False
                v_next, e_next = nx
                u_out = _unit(pts[v_next][0] - pts[cur_b][0], pts[v_next][1] - pts[cur_b][1])
                if u_out is None:
                    break
                cosd = max(-1.0, min(1.0, u[0] * u_out[0] + u[1] * u_out[1]))
                ang = math.acos(cosd)
                if ang < math.radians(5.0):
                    T1 = (p0[0] + u[0] * t1, p0[1] + u[1] * t1)
                    arc, T2 = [], None
                else:
                    nb2 = lane_line(cur_b, v_next)
                    if nb2 is None:
                        break
                    P2 = line_intersect(p0, u, nb2[0], nb2[2])
                    if P2 is None:
                        break
                    # ★ 度>=3（路口）：用面板「转弯半径」
                    #   ★ 度=2（普通弯道）：照抄路面模块 road_surface._deg2_ring 的同心圆环 ——
                    #     路面内弧 = corner_ratio*w、外弧 = 内弧+w ⇒ 道路轴线半径 = w*(ratio+0.5)
                    #     车道在轴线【右侧】偏移 off ⇒ 左转时车道在外侧(+off)、右转时在内侧(−off)
                    #     （原代码一律用 R = 路宽−偏移、不分左右 ⇒ 车直接跑出路面外 ✗）
                    cross = u[0] * nb2[2][1] - u[1] * nb2[2][0]
                    if len(nb) >= 3:
                        R = R_fil
                    else:
                        _mid = road_w * (road_ratio + 0.5)
                        R = max(1.0, _mid + off if cross > 0 else _mid - off)
                    tau = R * math.tan(ang * 0.5)
                    T1 = (P2[0] - u[0] * tau, P2[1] - u[1] * tau)
                    T2 = (P2[0] + nb2[2][0] * tau, P2[1] + nb2[2][1] * tau)
                    # ★ 圆心：在角点 P 的【角平分线】上、距 P 为 R/sin(δ/2)。
                    #   （原来写成"距 P 为 R"⇒ 圆心偏了 ⇒ 圆弧扫不到切点 ⇒
                    #    实测每个弯都出现 68°/92° 的硬折，车看着就是"很怪"）
                    bx = -u[0] + nb2[2][0]
                    by = -u[1] + nb2[2][1]
                    bl = math.hypot(bx, by)
                    if bl < 1e-9:
                        break
                    _dist = R / max(1e-6, math.sin(ang * 0.5))
                    O = (P2[0] + bx / bl * _dist, P2[1] + by / bl * _dist)
                    a0 = math.atan2(T1[1] - O[1], T1[0] - O[0])
                    a1 = math.atan2(T2[1] - O[1], T2[0] - O[0])
                    da = a1 - a0
                    while da > math.pi:
                        da -= 2 * math.pi
                    while da < -math.pi:
                        da += 2 * math.pi
                    # ★ 圆弧分段数（面板「转弯分段数」，默认 16）。
                    #   R=12 的 90° 弧：8 段 ⇒ 每段转 11.25°，车看着一顿一顿（卡卡的）；
                    #                 16 段 ⇒ 每段 5.6°，明显丝滑；想更顺可以调到 24/32。
                    _nseg = max(4, int(turn_seg))
                    arc = [(O[0] + R * math.cos(a0 + da * i / float(_nseg)),
                            O[1] + R * math.sin(a0 + da * i / float(_nseg)))
                           for i in range(1, _nseg)]
                if t0 < 0.05:
                    push(route, p0)
                push(route, T1)
                for q2 in arc:
                    push(route, q2)
                if T2 is not None:
                    push(route, T2)
                entry = T2
                cur_a, cur_b, cur_eid = cur_b, v_next, e_next
                if closing_last:
                    closed = True
                    break
                if (not closing) and poly_len(route) >= 0.6 * float(target_len):
                    closing = True
            if closed and len(route) >= 4:
                d = math.hypot(route[-1][0] - route[0][0], route[-1][1] - route[0][1])
                if d < 60.0:
                    # ★ 首点对齐到收尾切点 ⇒ 环路严格连续（否则每圈在接缝处跳一次）
                    route[0] = route[-1]
                    routes.append(route)
                    break
    return routes


def route_labels(path, pts, edges, road_w, lane_ratio=0.5):
    """每小段的"路径身份"：('L',边,方向,车道) / ('C',顶点,-1,-1,-1,-1)。

    前车判据要用它：只有**同一条车道段/同一条连接线**上的车才算前车，
    否则路口里隔壁连接线的车会被误当成就堵住自己。
    """
    n = len(path)
    labs = [None] * (n - 1)
    offs = lane_offsets(road_w, lane_ratio)
    for k in range(n - 1):
        p, q = path[k], path[k + 1]
        mid = ((p[0] + q[0]) * 0.5, (p[1] + q[1]) * 0.5)
        for eid, (a, b) in enumerate(edges):
            for (i, j, dbit) in ((a, b, 0), (b, a, 1)):
                u = _unit(pts[j][0] - pts[i][0], pts[j][1] - pts[i][1])
                if u is None:
                    continue
                L = math.hypot(pts[j][0] - pts[i][0], pts[j][1] - pts[i][1])
                if (abs(mid[0] - (pts[i][0] + pts[j][0]) * 0.5) > L * 0.5 + 30.0
                        or abs(mid[1] - (pts[i][1] + pts[j][1]) * 0.5) > L * 0.5 + 30.0):
                    continue
                r = (u[1], -u[0])
                for ki, o in enumerate(offs):
                    Ax, Ay = pts[i][0] + r[0] * o, pts[i][1] + r[1] * o
                    ok = True
                    for (px, py) in (p, q):
                        dvx, dvy = px - Ax, py - Ay
                        if abs(dvx * r[0] + dvy * r[1]) > 0.08:
                            ok = False
                            break
                        t = dvx * u[0] + dvy * u[1]
                        if t < -0.4 or t > L + 0.4:
                            ok = False
                            break
                    if ok:
                        labs[k] = ("L", eid, dbit, ki)
                        break
                if labs[k] is not None:
                    break
            if labs[k] is not None:
                break
    for k in range(n - 1):
        if labs[k] is not None:
            continue
        mid = ((path[k][0] + path[k + 1][0]) * 0.5, (path[k][1] + path[k + 1][1]) * 0.5)
        v, bd = -1, 1e9
        for vi, (vx, vy) in enumerate(pts):
            d = math.hypot(mid[0] - vx, mid[1] - vy)
            if d < bd:
                bd, v = d, vi
        if bd > 40.0:
            v = -1
        labs[k] = ("C", v, -1, -1)
    return labs


def proj_on_path(path, sarc, s, total, P, window=40.0):
    """把点 P 投影到路线（只扫本车前方 0..window 米），返回 (弧长差, 横向距离)。

    路线是闭环 ⇒ 允许绕回（s 接近 total 时看前面的 0..window）。
    """
    if total <= 0:
        return None
    best = None
    s_end = s + window
    for k in range(len(path) - 1):
        a0, a1 = sarc[k], sarc[k + 1]
        # 与窗口 [s, s+window] 有交集（考虑绕回）
        for base in (0.0, -total):
            lo, hi = s + base, s_end + base
            if a1 < lo or a0 > hi:
                continue
            ax, ay = path[k]
            bx, by = path[k + 1]
            ex, ey = bx - ax, by - ay
            L2 = ex * ex + ey * ey
            if L2 < 1e-9:
                continue
            t = ((P[0] - ax) * ex + (P[1] - ay) * ey) / L2
            t = max(0.0, min(1.0, t))
            fx, fy = ax + ex * t, ay + ey * t
            lat = math.hypot(P[0] - fx, P[1] - fy)
            ds = (a0 + math.sqrt(L2) * t + base) - s
            ds = ds % total
            if ds < 0.0:
                ds += total
            if 0.02 < ds <= window + 1e-6:
                if best is None or ds < best[0]:
                    best = (ds, lat)
    return best


def label_at(path, sarc, total, labs, s):
    if not labs or total <= 0:
        return None
    s = s % total
    k = 0
    for i in range(len(sarc) - 1):
        if sarc[i] <= s:
            k = i
        else:
            break
    k = max(0, min(k, len(labs) - 1))
    return labs[k]


# ════════════════════════════════════════════════════════════════
#  三、停车线（每条进口臂一个）—— group 直接读场景里的灯
# ════════════════════════════════════════════════════════════════

def _arm_light_group(pts, v, nbr, lights, road_w, face_K=None):
    """找这条进口臂（v→nbr）对应的那盏灯，返回 (方向组, 停车距离)。

    方向组**直接读灯的 rb_phase** ⇒ 车和灯不可能不一致；
    停车距离 = 灯在臂方向上的投影距离（车正好停在灯前）。

    ★ 必须【朝向校验】：灯要"面朝这条臂的外侧"（= 正对迎面驶来的车）。
      少了这一步，T 字路口 20m 内同时有两条街的灯时，会把这条臂绑到对面/隔壁那盏，
      ⇒ 车服从另一半周期的相位 ⇒ 现象就是"双红全亮车却走、左转绿亮车却停"（反相）。
    """
    u = _unit(pts[nbr][0] - pts[v][0], pts[nbr][1] - pts[v][1])
    if u is None:
        return None, None
    r = (u[1], -u[0])
    want_face = math.degrees(math.atan2(u[1], u[0]))          # 灯面应朝这条臂的外侧
    best = None
    for o in lights:
        dx, dy = o.location.x - pts[v][0], o.location.y - pts[v][1]
        along = dx * u[0] + dy * u[1]
        lat = dx * r[0] + dy * r[1]
        # ★ 窗口收紧：原来 along<6*路宽、|lat|<2.5*路宽 ⇒ 密集路口会抓到隔壁路口的灯
        if not (2.0 < along < road_w * 2.6):
            continue
        if not (road_w * 0.35 < abs(lat) < road_w * 1.3):
            continue
        # ★★ 朝向校验：灯面（rotation_z + K）必须朝这条臂的外侧 ±35°
        if face_K is not None:
            _face = math.degrees(o.rotation_euler.z) + face_K
            if abs((_face - want_face + 180.0) % 360.0 - 180.0) > 35.0:
                continue
        d = abs(along - road_w * 1.4) + abs(abs(lat) - (road_w * 0.5 + 0.9))
        gp = o.get("rb_phase", None)
        gp = int(gp) if gp is not None else None
        if gp is not None and (best is None or d < best[0]):
            best = (d, gp, along)
    if best is None:
        return None, None
    return best[1], best[2]


def light_face_offset(pts, intersections, lights, road_w=15.0):
    """★ 自校准：灯的 rotation_euler.z → "灯面朝向"的换算偏移。

    灯的朝向不是猜的：灯是给某条进口臂装的，**灯面应当朝那条臂的外端**
    （这样迎面来的车才看得见）。于是：
        偏移 K = 臂方向角 − 灯的 rotation_z      （对每盏灯都算一遍）
    所有灯应当得出同一个 K（取中位数），离散度大就说明朝向不统一。
    返回 (K度, 参与校准的灯数, 离散度)。
    """
    vals = []
    for it in intersections:
        v = it["v"]
        for o in lights:
            dx = o.location.x - pts[v][0]
            dy = o.location.y - pts[v][1]
            if math.hypot(dx, dy) > road_w * 3.0:
                continue
            best = None
            for nbr in it["nbrs"]:
                u = _unit(pts[nbr][0] - pts[v][0], pts[nbr][1] - pts[v][1])
                if not u:
                    continue
                along = dx * u[0] + dy * u[1]
                lat = dx * u[1] - dy * u[0]
                if along <= 0.0:
                    continue
                sc = abs(abs(lat) - (road_w * 0.5 + 0.9)) + 0.25 * abs(along - road_w * 1.4)
                if best is None or sc < best[0]:
                    best = (sc, math.degrees(math.atan2(u[1], u[0])))
            if best:
                vals.append(best[1] - math.degrees(o.rotation_euler.z))
    if not vals:
        return None, 0, 0.0
    vals.sort()
    k = vals[len(vals) // 2]
    return k, len(vals), max(abs(x - k) for x in vals)


def face_K_cached(pts, intersections, lights, road_w=15.0):
    """灯面朝向偏移 K 的缓存版（同一次生成里只算一遍）。"""
    global _FACE_K_MEMO
    if _FACE_K_MEMO[0] is None:
        k, n, dev = light_face_offset(pts, intersections, lights, road_w)
        _FACE_K_MEMO[0] = k
        _FACE_K_MEMO[1] = (n, dev)
    return _FACE_K_MEMO[0]


def light_group_by_sight(car_pos, u_in, lights, road_w=15.0, max_deg=60.0, face_K=None):
    """★ 用户的直觉：车看的是【正对着它车头、最近的那盏灯】。

    做法：从车头位置出发，只找"在车头前方 ±60°、且 2.2 倍路宽以内"的灯，
    取最近的那盏，读它的组号（rb_phase）。
    ⇒ 不用再去猜"这条进口臂对应哪盏灯"，避免拿到别的路口/别的方向的灯。
    返回 (组号, 灯名, 距离) ；找不到返回 (None, None, None)。
    """
    if not u_in or not lights:
        return (None, None, None)
    best = None
    for o in lights:
        dx = o.location.x - car_pos[0]
        dy = o.location.y - car_pos[1]
        d = math.hypot(dx, dy)
        if d > road_w * 2.2 or d < 1e-6:
            continue
        cosv = (dx * u_in[0] + dy * u_in[1]) / d          # 必须在车头前方
        if cosv < math.cos(math.radians(max_deg)):
            continue
        # ★ 关键：只有"灯面朝向车头"的灯才算（背对 / 90° 的一律排除）
        #   灯面朝向 = rotation_z + K（K 由场景自校准）；要求它 ≈ 车头反方向 ±40°
        if face_K is not None:
            _face = math.degrees(o.rotation_euler.z) + face_K
            _want = math.degrees(math.atan2(u_in[1], u_in[0])) + 180.0
            if abs((_face - _want + 180.0) % 360.0 - 180.0) > 40.0:
                continue
        gp = o.get("rb_phase", None)
        if gp is None:
            continue
        if best is None or d < best[0]:
            best = (d, int(gp), o.name)
    return (best[1], best[2], best[0]) if best else (None, None, None)


def _arc_near(path, sarc, p):
    """世界点 p 到路线(折线)的最近位置 -> (弧长, 距离)"""
    best = None
    for i in range(len(path)):
        q = path[i]
        d = math.hypot(p.x - q[0], p.y - q[1])
        if best is None or d < best[1]:
            best = (sarc[i], d)
    return best


def build_stops(pts, edges, intersections, path, sarc, total, smp, labels,
                lights, ref_deg, road_w=15.0, xwalks=(), step=1.5):
    """扫出这条路线上的停车线 → [(弧长, 方向组, 转向角色, 禁区长度)]。

    · 方向组：读该臂上那盏灯的 rb_phase（和灯绝对一致）
    · 角色  ：左转 → 'left'；直行/右转 → 'rite'（与灯的分组一致）
    """
    stops = []
    if total <= 0:
        return stops
    offs = lane_offsets(road_w)
    arm = {}                                     # (v, nbr) → (group, stop_dist)
    learned = []                                 # [(方向, 组)] —— 从"匹配到灯"的臂上学的
    for it in intersections:
        v = it["v"]
        for nbr in it["nbrs"]:
            _k_use = face_K_cached(pts, intersections, lights, road_w)
            g, sd = _arm_light_group(pts, v, nbr, lights, road_w, face_K=_k_use)
            arm[(v, nbr)] = (g, sd)
            if g is not None:
                u2 = _unit(pts[nbr][0] - pts[v][0], pts[nbr][1] - pts[v][1])
                if u2:
                    learned.append((u2, int(g)))

    def group_of(u_in):
        """★ 组号从灯上学：找方向最接近的"已匹配到灯"的臂，用它的组。

        保证和灯的约定【绝对一致】。之前用几何自己算，实测和灯反了 60/72 条，
        混着用 ⇒ 一部分车按错相位走 ⇒ 闯红灯 + 路口相撞。
        """
        if not u_in:
            return None
        bb = None
        for (u2, g2) in learned:
            d = abs(u_in[0] * u2[0] + u_in[1] * u2[1])
            if bb is None or d > bb[0]:
                bb = (d, g2)
        if bb is not None and bb[0] > math.cos(math.radians(35.0)):
            return bb[1]
        return None
    seen_zone = []
    _XREF = []                                   # 臂查表组 vs 看灯组 不一致的记录
    # 灯面朝向自校准（只算一次；K 的离散度大说明灯的朝向不统一）
    _k, _kn, _kdev = light_face_offset(pts, intersections, lights, road_w)
    _FACE_K[0] = _k
    global LAST_FACE
    LAST_FACE = (_k, _kn, _kdev)
    # 起点如果已经在某个禁区里，先跳过（否则会记一条假停车线）
    s0 = 0.0
    for it in intersections:
        tv = it["tau"] + 2.0
        q = smp(0.0)
        if math.hypot(q[0] - pts[it["v"]][0], q[1] - pts[it["v"]][1]) < tv:
            s = 0.0
            while s < total:
                q = smp(s)
                if math.hypot(q[0] - pts[it["v"]][0], q[1] - pts[it["v"]][1]) > tv:
                    break
                s += step
            s0 = s
            break
    global LAST_XREF
    LAST_XREF = LAST_XREF + _XREF
    s = s0
    skip_until = -1.0
    while s < total:
        x, y, ux, uy = smp(s)
        hit = None
        for it in intersections:
            v = it["v"]
            tv = it["tau"] + 2.0
            if math.hypot(x - pts[v][0], y - pts[v][1]) < tv:
                hit = it
                break
        if hit is not None:
            v = hit["v"]
            # ★★ 判定"我这条臂" = 与【车的行驶方向】最反平行的那条臂
            #    （车是朝路口开的 ⇒ 行驶方向 = −该臂的外向方向）
            #   原写法用"背离车位置的臂 + 取最近"：在路口角上会被【垂直方向的臂】抢走
            #   （实测：车在东侧臂上却被判成南侧臂 ⇒ 组0记成组1 ⇒ 相位反相）。
            u_car = _unit(ux, uy)
            best = None
            for nbr in hit["nbrs"]:
                u2 = _unit(pts[nbr][0] - pts[v][0], pts[nbr][1] - pts[v][1])
                if u2 is None or u_car is None:
                    continue
                dotc = u2[0] * u_car[0] + u2[1] * u_car[1]      # 越小 = 越对着来
                if best is None or dotc < best[0]:
                    best = (dotc, nbr)
            in_nbr = best[1] if best else None
            # ★ 主判据：按【进口臂查表】取组（这张表已审计：与几何组 16/16 一致）
            #   以前用"车头前方最近的灯"当主判据 —— 在 T 字路口/转弯处附近不止一盏灯，
            #   会挑中另一条街的灯 ⇒ 车按错误相位走（实测：几何组=0 的臂被记成组1）
            #   ⇒ 全红还全速通过 838 次。现在"看灯"只留作交叉核对。
            grp_arm, sdist = (arm.get((v, in_nbr)) if in_nbr is not None else (None, None))
            grp = grp_arm
            if grp is None:                       # 这张表没给 → 退回"学过同向臂"的组
                grp = group_of(_unit(ux, uy))
            if grp is None:                       # 实在学不到才用几何兜底
                grp = 0
            # 交叉核对（诊断用）：看灯拿到的组 vs 按臂查表的组
            _pos = smp(s)
            _g_sight, lname, _ld = light_group_by_sight((_pos[0], _pos[1]),
                                                        _unit(ux, uy), lights, road_w,
                                                        face_K=_FACE_K[0])
            if (_g_sight is not None) and (int(_g_sight) != int(grp)):
                _XREF.append((v, in_nbr, int(grp), int(_g_sight), lname))
            # 转向角色：比较"进来的方向"和"出去的方向"
            u_in = _unit(ux, uy)
            q2 = smp(min(total - 0.1, s + hit["tau"] + 6.0))
            u_out = _unit(q2[2], q2[3])
            role = "rite"
            if u_in and u_out:
                cross = u_in[0] * u_out[1] - u_in[1] * u_out[0]
                cosd = max(-1.0, min(1.0, u_in[0] * u_out[0] + u_in[1] * u_out[1]))
                ang = math.degrees(math.acos(cosd))
                if ang > 20.0 and cross > 0:
                    role = "left"
            zone = 2.0 * hit["tau"] + 2.0
            sd = sdist if sdist else (hit["tau"] + 2.0)
            # ** 硬夹：停车线不许落进斑马线（灯配偏/投影偏深时的兜底）
            #   用最近的斑马线把停车线往外夹 => 车头到斑马线至少留 0.3m
            if xwalks:
                _cw = []
                for _o in xwalks:
                    for _c in _o.bound_box:
                        _wp = _o.matrix_world @ Vector(_c)
                        _a, _d = _arc_near(path, sarc, _wp)
                        if _d < 12.0:
                            _cw.append(_a)
                _before = [a for a in _cw if a < s and (s - a) < 14.0]
                if _before:
                    _lim = min(_before) - 0.3
                    if s > _lim:
                        s = _lim
            stops.append((s, grp, role, zone, sd))
            skip_until = s + 2.0 * hit["tau"] + 22.0
        s += step
        if s < skip_until:
            s = skip_until
    return stops


# ════════════════════════════════════════════════════════════════
#  四、车辆：克隆 + 姿态
# ════════════════════════════════════════════════════════════════

def _library_cars(coll_name="Cars", n_max=None):
    """从资产里找车辆库：返回 [(merged_obj, rig_obj), ...]（**排除空集合**）"""
    out = []
    for c in bpy.data.collections:
        nm = c.name.strip()
        if nm == coll_name or not nm.startswith(coll_name + " "):
            continue
        objs = [o for o in c.objects if o.type in ("MESH", "ARMATURE")]
        rig = next((o for o in objs if o.type == "ARMATURE"), None)
        mesh = next((o for o in objs if o.type == "MESH"), None)
        if rig and mesh:
            out.append((mesh, rig))
        if n_max and len(out) >= n_max:      # n_max=None ⇒ 不限数量（和建筑一样全拿）
            break
    return out


def clear_vehicles():
    for o in [o for o in bpy.data.objects if o.get(TAG_VEH)]:
        try:
            bpy.data.objects.remove(o, do_unlink=True)
        except Exception:
            pass


def _wheel_rig_info(x_rig):
    """从骨架读出轮子骨骼：{名: (是否前轮, 轮半径, 转向轴(骨骼局部))}、轴距、轮半径"""
    from mathutils import Vector
    out = {}
    M = x_rig.matrix_world
    ws = [pb.name for pb in x_rig.pose.bones if "wheel" in pb.name.lower()]
    if not ws:
        return out, 3.1, 0.36
    xs = []
    for n in ws:
        b = x_rig.data.bones[n]
        xs.append((n, b.head_local.x, b.head_local.z))
    xmax = max(v[1] for v in xs)
    xmin = min(v[1] for v in xs)
    wb = abs(xmax - xmin)
    zs = [abs(v[2]) for v in xs]
    wr = (sum(zs) / len(zs)) if zs else 0.36
    for (n, bx, bz) in xs:
        front = bx >= (xmax + xmin) * 0.5
        try:
            axis_w = M.to_3x3().inverted() @ Vector((0.0, 0.0, 1.0))   # 世界Z → 骨架空间
            al = x_rig.data.bones[n].matrix_local.to_3x3().inverted() @ axis_w
            al.normalize()
        except Exception:
            al = Vector((0.0, 0.0, 1.0))
        out[n] = (front, abs(bz) if abs(bz) > 0.05 else 0.36, al)
    return out, max(0.5, wb), max(0.1, wr)


def _wheel_signals(poses, wb, wr, tau=0.35, gain=1.0, max_steer=35.0, dt=1.0 / 24.0):
    """按帧算：滚动角(弧度) + 前轮转向角(弧度)

    ★ 转向角 = 一阶滞后（真实驾驶员打方向的过程）：
        目标角 δ_target = atan(轴距 × 曲率)，曲率 = Δyaw/Δs
        实际角 δ += (δ_target − δ) · dt/τ   ⇒ 进弯【慢慢变大】、出弯【慢慢变小】✓
      （直接用曲率会"咔"一下打到最大，所以必须有这道平滑）
    """
    n = len(poses)
    spin = [0.0] * n
    steer = [0.0] * n
    spun = 0.0
    cur = 0.0
    k = min(1.0, max(0.02, dt / max(0.05, tau)))
    for i in range(1, n):
        d = math.hypot(poses[i][0] - poses[i - 1][0], poses[i][1] - poses[i - 1][1])
        dyaw = (poses[i][2] - poses[i - 1][2] + math.pi) % (2 * math.pi) - math.pi
        spun += d / wr
        spin[i] = spun
        tgt = 0.0
        if d > 0.05:
            tgt = math.atan(wb * (dyaw / d)) * float(gain)          # 目标转向角（曲率决定）
        tgt = max(-max_steer, min(max_steer, math.degrees(tgt)))
        cur += (math.radians(tgt) - cur) * k                        # ★ 一阶滞后：慢慢追
        steer[i] = cur
    return steer, spin


def bake_wheels(r2, x_rig, steer, spin, wheel_r=0.0, rate=1.0):
    """把滚动/转向写进 4 个轮子骨骼（直接驱动，不经过任何中间骨骼）"""
    from mathutils import Matrix
    info, wb, wr = _wheel_rig_info(x_rig)
    if not info:
        return 0
    if wheel_r and wheel_r > 0.02:                 # 面板可覆盖轮半径
        pass
    for nm, (front, r, axis) in info.items():
        pb = r2.pose.bones.get(nm)
        if pb is None:
            continue
        pb.rotation_mode = "QUATERNION"
        for i in range(len(steer)):
            M = Matrix.Rotation(steer[i] if front else 0.0, 4, axis)
            # ★ rate = 「车轮滚动动画速率」：1.0 按真实轮半径滚（不滑），越大转越快
            _sp_i = spin[i] * float(rate) if rate else spin[i]
            q = M @ Matrix.Rotation(_sp_i, 4, "Y")                 # 先滚动(绕车轴) 再转向(绕竖轴)
            pb.rotation_quaternion = q.to_quaternion()
            pb.keyframe_insert("rotation_quaternion", frame=i + 1)
    return len(info)


def _car_static(x_mesh, x_rig):
    """记录库里这辆车的**静止姿态**：车体中心 + rig 矩阵。

    ★ 必须"先复位再记"：库里若带动画，直接记就会记到动画姿态 ⇒ 越点越歪。
    这里临时把动作摘掉、刷新依赖图，记完再装回去。
    """
    saved = []
    for ob in (x_rig, x_mesh):
        ad = ob.animation_data
        if ad is not None and ad.action is not None:
            saved.append((ad, ad.action))
            ad.action = None
    try:
        bpy.context.view_layer.update()
    except Exception:
        pass
    dg = bpy.context.evaluated_depsgraph_get()
    try:
        # ★ 必须遍历【实际顶点】求包围盒。
        #   原来用 evaluated_get(dg).bound_box —— 在 --background 下经常返回退化/零值
        #   ⇒ C.z 变成 0 ⇒ 落位不去掉车模型自身的高度偏移 ⇒ 整车悬空 0.609m（实测）。
        ev = x_mesh.evaluated_get(dg)
        try:
            me = ev.to_mesh()
            cos = [x_mesh.matrix_world @ v.co for v in me.vertices]
            ev.to_mesh_clear()
        except Exception:
            cos = []
        if not cos:
            cos = [x_mesh.matrix_world @ v.co for v in x_mesh.data.vertices]
        C = Vector(((min(p.x for p in cos) + max(p.x for p in cos)) * 0.5,
                    (min(p.y for p in cos) + max(p.y for p in cos)) * 0.5,
                    min(p.z for p in cos)))          # z 取【最低点】= 轮胎触地
    except Exception:
        C = x_mesh.matrix_world.translation.copy()
    M0 = x_rig.matrix_world.copy()
    for (ad, act) in saved:                    # 装回去
        try:
            ad.action = act
        except Exception:
            pass
    return C, M0


def place_vehicles(target_coll, library, routes, count=50, plan=None,
                   speed=10.0, frames=1560, seed=0, name_prefix="RB_CAR_",
                   fps=24.0, yaw_offset=0.0, pts=None, edges=None,
                   intersections=(), lights=(), road_w=15.0, ref_deg=0.0,
                   xwalks=(),
                   settings=None):
    """按路线铺车并烘焙动画。返回 info dict。"""
    global _FPS, LAST_XREF, _FACE_K_MEMO, _S
    _FPS = float(fps)
    _S = settings
    _FACE_K_MEMO = [None, None]
    LAST_XREF = []
    clear_vehicles()
    info = {"count": 0, "cars": [], "cycle": None, "stops": 0, "laps": [],
            "diag": {"red_violations": 0, "viol_ex": [], "still": 0, "tot": 0,
                     "jumps": 0, "jump_ex": [], "min_gap": 1e9, "min_gap_at": None,
                     "same_dir_hits": 0, "cross_hits": 0}}
    if not routes or not library or plan is None:
        return info, "没有路线 / 车辆库 / 相位表"
    dt = 1.0 / _FPS
    n = max(1, int(count))
    use = [routes[i % len(routes)] for i in range(n)]
    cars = []
    for ci in range(n):
        path = use[ci]
        acc, total, smp = mk_sampler(path)
        if total <= 1.0:
            continue
        labels = route_labels(path, pts, edges, road_w) if (pts and edges) else None
        stops = (build_stops(pts, edges, intersections, path, acc, total, smp, labels,
                             lights, ref_deg, road_w, xwalks)
                 if (pts and edges and intersections) else [])
        # ★ 出生点校正：若撒点正好落在【停车线前方 / 斑马线上】（= 已越过停车线），
        #   红灯判定要求"还没越过停车线"才成立 ⇒ 那种车永远判不到红灯，
        #   会一直杵在斑马线上 ✗（实测：2 辆车在帧16 压在斑马线上）
        #   ⇒ 把它退到停车线外侧 8m 再开始
        s0 = total * ci / float(n)
        for _st in stops:
            _d = (_st[0] - s0) % total
            if _d > total - 15.0:
                s0 = (_st[0] - 8.0) % total
                break
        cars.append({
            "ci": ci, "path": path, "sarc": acc, "total": total, "smp": smp,
            "s": s0, "v": float(speed),
            "mesh": library[ci % len(library)][0], "rig": library[ci % len(library)][1],
            "labs": labels, "stops": stops, "stop": None, "red": None, "lead": None,
        })
        info["stops"] += len(stops)
    if not cars:
        return info, "路线太短"

    # 记录库车的静止姿态（在动画之前！）
    lib_static = {}
    for (mesh, rig) in library:
        lib_static[rig.name] = _car_static(mesh, rig)

    # 克隆
    for c in cars:
        x_mesh, x_rig = c["mesh"], c["rig"]
        r2 = x_rig.copy()
        r2.name = name_prefix + "rig_" + str(c["ci"])
        r2[TAG_VEH] = 1
        r2.animation_data_clear()
        try:
            r2.rotation_mode = "XYZ"
        except Exception:
            pass
        m2 = x_mesh.copy()
        m2.name = name_prefix + "mesh_" + str(c["ci"])
        m2[TAG_VEH] = 1
        m2.animation_data_clear()
        m2.parent = r2                                     # ★ 保住父子
        m2.matrix_parent_inverse = x_mesh.matrix_parent_inverse.copy()
        # ★★ 关键：复制对象时，骨架修改器仍指向【库原件的骨架】⇒ 轮子动画（烘在克隆骨架上）
        #     根本作用不到克隆车身上！必须改指向克隆自己的骨架。
        for _md in list(m2.modifiers):
            if _md.type == "ARMATURE":
                _md.object = r2
        target_coll.objects.link(r2)
        target_coll.objects.link(m2)
        c["rig2"], c["mesh2"] = r2, m2
        c["C"], c["M0"] = lib_static[x_rig.name]
        c["pose"] = []
        info["cars"].append(r2.name)
    info["count"] = len(cars)

    # ── 主循环 ────────────────────────────────────────────────
    # ★ 先预热：车是按"沿路线均分"撒下去的，可能正好落在红灯停车线正前方
    #   （10 m/s 要 31m 才刹得住）⇒ 起步就会"冲"过红灯（实测 25 次）。
    #   预热 10 秒让每辆车先安顿好；从 f==1 起才清零统计、开始记录动画。
    warm = int(round(_FPS * 10.0))
    for f in range(1 - warm, int(frames) + 1):
        loc = f - 1
        if f == 1:                                  # 预热结束：清零统计 + 清空姿态缓存
            for _c in cars:
                _c["pose"] = []
            info["diag"].update({"red_violations": 0, "viol_ex": [], "still": 0,
                                 "tot": 0, "jumps": 0, "jump_ex": [],
                                 "min_gap": 1e9, "min_gap_at": None,
                                 "same_dir_hits": 0, "cross_hits": 0})
        P = [c["smp"](c["s"]) for c in cars]
        # 前车 + 信号
        for i, c in enumerate(cars):
            best = None
            for j, o in enumerate(cars):
                if i == j:
                    continue
                d2 = (P[j][0] - P[i][0]) ** 2 + (P[j][1] - P[i][1]) ** 2
                if d2 > 50.0 * 50.0:
                    continue
                pr = proj_on_path(c["path"], c["sarc"], c["s"], c["total"], P[j], 40.0)
                if pr is None:
                    continue
                ds, lat = pr
                if ds <= 0.05 or lat > 2.6:
                    continue
                if c.get("labs") and o.get("labs"):
                    if label_at(c["path"], c["sarc"], c["total"], c["labs"], c["s"] + ds) != \
                       label_at(o["path"], o["sarc"], o["total"], o["labs"], o["s"]):
                        continue
                if best is None or ds < best[0]:
                    best = (ds, j)
            c["lead"] = best
            # 红灯：最近的停车线
            c["red"] = None
            for st in c.get("stops", []):
                (s_st, grp, role, zone, sd) = st
                ds = (s_st - c["s"]) % c["total"]
                # ★ 只要车【还没越过停车线】就要判灯（原来写成 zone < ds，
                #   等于让停车线 32m 以内的车统统不看灯 ⇒ 全速闯红灯 23 次）。
                #   越过之后 ds 会绕成接近整圈，自然不会命中。
                if 0.5 < ds <= 45.0:
                    try:
                        from . import trafficlight as TL
                        ok = TL.can_go(plan, loc, grp, role)
                        if ok:
                            # ★ 提前量：等我开到停车线时它还绿吗？
                            #   绿灯末尾的闪烁 = "要变红"的预告。不提前判的话，车会在
                            #   相位切换的瞬间刹不住而"滑"进路口 ⇒ 既像闯红灯、
                            #   又会和下一相位的车撞（实测 25 次闯红灯 / 最近 0.38m）。
                            t_arr = ds / max(c["v"], 1.0)
                            ok = TL.can_go(plan, loc + int(t_arr * _FPS), grp, role)
                    except Exception:
                        ok = True
                    if not ok:
                        c["red"] = ds
                        break
        # 速度更新
        # ★ 停车线退让 = 灯位退让(tlight_along) + 0.5m + 面板额外退让
        #   因为灯杆在【斑马线外沿】，若把"灯的位置"当停车线，整辆车会压在斑马线上 ✗
        #   退到 灯位+0.5 ⇒ 车头正好落在斑马线【内侧】，不压斑马线 ✓
        _sback = (float(getattr(_S, "tlight_along", 3.2) or 0.0) + 1.0
                  + float(getattr(_S, "traffic_stop_back", 0.0) or 0.0))
        for i, c in enumerate(cars):
            v0 = float(speed)
            gap, dv = None, 0.0
            if c["lead"] is not None:
                ds, j = c["lead"]
                gap = max(0.3, ds - CAR_LEN)
                dv = c["v"] - cars[j]["v"]
            if c["red"] is not None:
                # ★ 车头停在【斑马线内侧】：目标 = 灯位 − _sback（_sback 见上）
                #   gap 的含义 = 车头到停车线；IDM 稳定时 gap 约等于 S0(2m)
                g2 = max(0.3, (c["red"] + S0 - _sback) - CAR_LEN * 0.5)
                if gap is None or g2 < gap:
                    gap, dv = g2, c["v"]
            acc = A_MAX * (1.0 - (c["v"] / v0) ** DELTA) if v0 > 0 else 0.0
            if gap is not None:
                inter = (S0 + max(0.0, c["v"] * T_HEAD + c["v"] * dv / (2.0 * math.sqrt(A_MAX * B_COMF)))) / gap
                acc -= A_MAX * (inter ** 2)
            c["v"] = max(0.0, c["v"] + acc * dt)
            s_old = c["s"]
            c["s"] = (c["s"] + c["v"] * dt) % c["total"]
            _dg = info["diag"]
            _dg["tot"] += 1
            if c["v"] < 0.3:
                _dg["still"] += 1
            # ★ 闯红灯判定：这一步是否跨过某条停车线，而当时那个相位是红的
            for (s_st, grp, role, zone, sd) in c.get("stops", []):
                passed = (s_old <= s_st < c["s"]) if c["s"] >= s_old else (s_old <= s_st or s_st < c["s"])
                if passed:
                    try:
                        from . import trafficlight as TL
                        ok2 = TL.can_go(plan, loc, grp, role)
                    except Exception:
                        ok2 = True
                    # ★ 只有"带着速度冲过停车线"才算闯红灯；
                    #   在停车线前低速蠕行/停下时越过 1cm 不算（实测那种是误报）
                    if not ok2 and c["v"] > 3.0:
                        _dg["red_violations"] += 1
                        if len(_dg["viol_ex"]) < 6:
                            _dg["viol_ex"].append((f, c["ci"], grp, role, round(c["v"], 1)))
            x, y, ux, uy = c["smp"](c["s"])
            yaw = math.atan2(uy, ux) + yaw_offset
            # 跳变（几何非法）与最近车距
            if c["pose"]:
                px, py, _py2 = c["pose"][-1]
                dd = math.hypot(x - px, y - py)
                if dd > 1.2 * max(0.05, c["v"]) * dt + 0.05:
                    info["diag"]["jumps"] += 1
                    if len(info["diag"]["jump_ex"]) < 6:
                        info["diag"]["jump_ex"].append((f, c["ci"], round(dd, 2)))
            c["pose"].append((x, y, yaw))

        # 最近车距（每 4 帧统计一次，够用又便宜）
        # ★ 硬约束收尾：不许任何车钻进前车车身
        #   （IDM 正常跟车没问题，但极短车距下可能来不及 ⇒ 实测两车最近 0.04m）
        if f >= 1:
            # 硬夹：不许钻进前车车身（IDM 在极短车距下可能来不及）
            for _i2, _c2 in enumerate(cars):
                if _c2.get("lead") is None:
                    continue
                _j2 = _c2["lead"][1]
                _d2 = (cars[_j2]["s"] - _c2["s"]) % _c2["total"]
                if _d2 < CAR_LEN:
                    _c2["s"] = (cars[_j2]["s"] - CAR_LEN) % _c2["total"]

        # 最近车距 + 几何冲突（每 4 帧统计一次，够用又便宜）
        if f >= 1 and f % 4 == 0 and len(cars) > 1 and cars[0]["pose"]:
            for _a in range(len(cars)):
                for _b in range(_a + 1, len(cars)):
                    _pa = cars[_a]["pose"][-1]
                    _pb = cars[_b]["pose"][-1]
                    _dd = math.hypot(_pa[0] - _pb[0], _pa[1] - _pb[1])
                    if _dd < info["diag"]["min_gap"]:
                        info["diag"]["min_gap"] = _dd
                        info["diag"]["min_gap_at"] = (f, _a, _b)
                    if _dd < 4.5:
                        _deg = math.degrees(abs((_pa[2] - _pb[2] + math.pi) % (2 * math.pi) - math.pi))
                        if _deg < 45.0:
                            info["diag"]["same_dir_hits"] += 1
                        elif 60.0 < _deg < 125.0:
                            info["diag"]["cross_hits"] += 1

    # ── 烘焙关键帧（批量写，快）──────────────────────────────
    for c in cars:
        r2 = c["rig2"]
        C, M0 = c["C"], c["M0"]
        piv = C.copy()
        # ★ 落位自校准：先按第 1 帧位姿摆一次，量"整车离地多少"，然后整体下移
        #   （库原件最低点在 −0.607、克隆件却在 +0.173 ⇒ 悬空 17cm，实测过）
        zoff = 0.0
        try:
            from mathutils import Matrix as _M
            _p0 = c["pose"][0] if c["pose"] else (0.0, 0.0, 0.0)
            r2.matrix_world = (_M.Translation(Vector((_p0[0], _p0[1], 0.0)))
                               @ _M.Rotation(_p0[2], 4, "Z")
                               @ _M.Translation(-piv) @ M0)
            bpy.context.view_layer.update()
            _dg2 = bpy.context.evaluated_depsgraph_get()
            _ev2 = c["mesh2"].evaluated_get(_dg2)
            _mm = _ev2.to_mesh()
            _zm = min((_ev2.matrix_world @ v.co).z for v in _mm.vertices)
            _ev2.to_mesh_clear()
            zoff = -float(_zm)
        except Exception as _e:
            zoff = 0.0
        r2.animation_data_create()
        act = bpy.data.actions.new(name_prefix + "act_" + str(c["ci"]))
        r2.animation_data.action = act
        try:
            if hasattr(act, "slots") and len(act.slots) == 0:
                act.slots.new(id_type="OBJECT", name=r2.name)
            if hasattr(r2.animation_data, "action_slot") and len(getattr(act, "slots", [])) >= 1:
                r2.animation_data.action_slot = act.slots[0]
        except Exception:
            pass
        f_loc = [act.fcurves.new("location", index=i) for i in range(3)]
        f_rot = [act.fcurves.new("rotation_euler", index=i) for i in range(3)]
        for fc in f_loc + f_rot:
            fc.keyframe_points.add(len(c["pose"]))
        for k, (x, y, yaw) in enumerate(c["pose"], start=1):
            # rig 矩阵 = T(位置) @ Rz(偏航) @ T(-车体中心) @ 库里静止矩阵
            from mathutils import Matrix
            # ★ 对象承载【位置 + 偏航】⇒ 骨骼 pose 全 0，坐标系数值和资产完全一致 ✓
            Mw = (Matrix.Translation(Vector((x, y, zoff)))
                  @ Matrix.Rotation(yaw, 4, "Z")
                  @ Matrix.Translation(-piv)
                  @ M0)
            l, r, _s = Mw.decompose()
            for i in range(3):
                kp = f_loc[i].keyframe_points[k - 1]
                kp.co = (float(k), float(l[i]))
                kp.interpolation = "LINEAR"
            for i in range(3):
                kp = f_rot[i].keyframe_points[k - 1]
                kp.co = (float(k), float(r.to_euler("XYZ")[i]))
                kp.interpolation = "LINEAR"
        for fc in f_loc + f_rot:
            fc.update()
        # ★ 车轮动画：直接驱动 4 个轮子骨骼（滚动 + 前轮转向，转向带渐入/渐出）
        try:
            if bool(getattr(_S, "traffic_wheel_anim", True)):
                _info, _wb, _wr = _wheel_rig_info(c["rig"])
                _st, _sp = _wheel_signals(c["pose"], _wb, _wr,
                                          tau=float(getattr(_S, "traffic_steer_tau", 0.35) or 0.35),
                                          gain=float(getattr(_S, "traffic_steer_gain", 1.0) or 1.0),
                                          dt=dt)
                _n = bake_wheels(r2, c["rig"], _st, _sp,
                                 rate=float(getattr(_S, "traffic_wheel_rate", 1.0) or 1.0))
                if _n and c.get("ci") == 0:
                    print("[RB_CAR] 车轮骨骼已驱动：%d 根（滚动 + 前轮转向，含渐入渐出）" % _n)
        except Exception as _e:
            print("[RB_CAR] 车轮动画跳过:", _e)
    info["cycle"] = int(frames)
    global LAST_INFO
    LAST_INFO = info
    return info, ""


# ════════════════════════════════════════════════════════════════
#  五、操作符：一键生成车流
# ════════════════════════════════════════════════════════════════

def _read_network(obj):
    """从网格对象读 (顶点, 边) —— 与建路面用的是同一份坐标（局部坐标）。"""
    pts = [(v.co.x, v.co.y) for v in obj.data.vertices]
    edges = [(e.vertices[0], e.vertices[1]) for e in obj.data.edges]
    return pts, edges


def _intersections(pts, edges, tau):
    adj = {}
    for (a, b) in edges:
        adj.setdefault(a, []).append(b)
        adj.setdefault(b, []).append(a)
    out = []
    for v, nbrs in adj.items():
        if len(nbrs) >= 3:
            out.append({"v": v, "nbrs": list(nbrs), "tau": float(tau)})
    return out


class BuildTrafficOperator(bpy.types.Operator):
    """按车道生成车流，遵守红绿灯相位表（信号唯一真源 = trafficlight）"""
    bl_idname = "road_builder.build_traffic"
    bl_label = "生成车流"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.road_builder
        obj = context.active_object
        if obj is None or obj.type != "MESH" or len(obj.data.edges) == 0:
            obj = next((o for o in bpy.data.objects
                        if o.type == "MESH" and len(o.data.edges) >= 4 and not o.get(TAG_VEH)), None)
        if obj is None:
            self.report({"ERROR"}, "找不到路网网格（请先生成道路，或选中网格对象）")
            return {"CANCELLED"}

        from . import trafficlight as TL
        plan = TL.plan_from_settings(s)
        pts, edges = _read_network(obj)
        road_w = float(getattr(s, "road_width", 15.0))
        ratio = float(getattr(s, "corner_radius_ratio", 0.5))
        tau = road_w * (0.5 + ratio) / math.tan(math.radians(45.0))

        # 全局参考轴（只在找不到灯时兜底用）
        ref_deg = 0.0
        inter0 = _intersections(pts, edges, tau)
        if inter0 and inter0[0]["nbrs"]:
            u = _unit(pts[inter0[0]["nbrs"][0]][0] - pts[inter0[0]["v"]][0],
                      pts[inter0[0]["nbrs"][0]][1] - pts[inter0[0]["v"]][1])
            if u:
                ref_deg = math.degrees(math.atan2(u[1], u[0]))

        # ★ 每次生成前清掉"跨次运行的缓存"（Ctrl+Z 后那些缓存可能指向已消失的数据 ✗）
        global LAST_FACE, LAST_XREF, _FACE_K_MEMO
        LAST_FACE = (None, 0, 0.0)
        LAST_XREF = None
        try:
            _FACE_K_MEMO = {}
        except Exception:
            pass

        lights = [o for o in bpy.data.objects if o.get("rb_tlight")]
        xwalks = [o for o in bpy.data.objects if o.get("rb_crosswalk")]
        cyc = plan["cycle"] if plan else int(getattr(s, "tlight_cycle", 1560))
        frames = int(getattr(s, "traffic_frames", 0) or 0) or int(context.scene.frame_end)
        speed = float(getattr(s, "traffic_speed", 10.0))
        target_len = max(300.0, speed * float(cyc) / float(_FPS))

        # 车辆库：从资产追加（若当前文件里没有）
        lib = _library_cars(getattr(s, "traffic_coll", "Cars") or "Cars")
        if not lib:
            asset = getattr(s, "asset_lib", "") or ""
            if asset:
                try:
                    with bpy.data.libraries.load(asset, link=False) as (src, dst):
                        names = [n for n in src.collections
                                 if n == "Cars" or n.startswith("Cars ")]
                        dst.collections = names
                    lib = _library_cars(getattr(s, "traffic_coll", "Cars") or "Cars")
                except Exception as e:
                    self.report({"WARNING"}, "追加车辆库失败：%s" % e)
        if not lib:
            self.report({"ERROR"}, "找不到车辆库（资产里 CarNN 的集合，前缀 = %s）"
                        % (getattr(s, "traffic_coll", "Cars") or "Cars"))
            return {"CANCELLED"}

        # ★ 分两类生成路线（用户需求：左转走内侧靠黄线车道、直行/右转走外侧车道，
        #   各排各的队 ⇒ 直行/右转车等绿灯时不会挡住后面的左转车）
        _lr = float(getattr(s, "traffic_left_ratio", 0.5))
        _nl = max(1, int(round(12 * _lr)))
        _base = int(getattr(s, "traffic_seed", 0))
        _tr = float(getattr(s, "traffic_turn_radius", 0.0) or 0.0)
        _tseg = int(getattr(s, "traffic_turn_seg", 16) or 16)
        _rt_l = lane_routes(pts, edges, road_w=road_w,
                            lane_ratio=float(getattr(s, "laneline_ratio", 0.5)),
                            movement="left", n=_nl, seed=_base, target_len=target_len,
                            turn_radius=_tr, turn_seg=_tseg,
                            road_ratio=float(getattr(s, "corner_radius_ratio", 0.5)),
                            lane_shift=float(getattr(s, "traffic_lane_shift", 0.0)))
        _rt_t = lane_routes(pts, edges, road_w=road_w,
                            lane_ratio=float(getattr(s, "laneline_ratio", 0.5)),
                            movement="through", n=max(1, 12 - _nl), seed=_base + 1,
                            target_len=target_len, turn_radius=_tr, turn_seg=_tseg,
                            road_ratio=float(getattr(s, "corner_radius_ratio", 0.5)),
                            lane_shift=float(getattr(s, "traffic_lane_shift", 0.0)))
        routes = []
        for _k in range(max(len(_rt_l), len(_rt_t))):
            if _k < len(_rt_l):
                routes.append(_rt_l[_k])
            if _k < len(_rt_t):
                routes.append(_rt_t[_k])
        if not routes:
            routes = lane_routes(pts, edges, road_w=road_w,
                                 lane_ratio=float(getattr(s, "laneline_ratio", 0.5)),
                                 lane_index=int(getattr(s, "traffic_lane", 0)),
                                 n=6, seed=_base, target_len=target_len)
        print("[RB_CAR] 路线：左转类 %d 条（内侧车道）/ 直行右转类 %d 条（外侧车道）"
              % (len(_rt_l), len(_rt_t)))
        if not routes:
            self.report({"ERROR"}, "路线生成失败（网格太小？）")
            return {"CANCELLED"}

        tgt = bpy.data.collections.get(getattr(s, "traffic_target", "RB_Traffic") or "RB_Traffic")
        if tgt is None:
            tgt = bpy.data.collections.new(getattr(s, "traffic_target", "RB_Traffic") or "RB_Traffic")
            context.scene.collection.children.link(tgt)

        info, err = place_vehicles(
            tgt, lib, routes, count=int(getattr(s, "traffic_count", 50)), plan=plan,
            speed=speed, frames=frames, seed=int(getattr(s, "traffic_seed", 0)),
            fps=float(context.scene.render.fps or 24),
            pts=pts, edges=edges, intersections=inter0, lights=lights,
            road_w=road_w, ref_deg=ref_deg, xwalks=xwalks, settings=s,
            yaw_offset=float(getattr(s, "traffic_yaw", 0.0)))
        if err:
            self.report({"ERROR"}, err)
            return {"CANCELLED"}
        # ★ 灯识别自检：车"看到的灯"和"按进口臂查到的灯"有多少条对不上
        print("[RB_CAR] 车流：%d 辆 / %d 条路线 / %d 个停车线 / %d 帧"
              % (info["count"], len(routes), info["stops"], frames))
        _k, _kn, _kdev = LAST_FACE
        print("[RB_CAR] 灯面朝向自校准：偏移 K = %s 度（参与 %d 盏，离散度 %.1f 度）%s"
              % (("None" if _k is None else round(_k, 1)), _kn, _kdev,
                 "  ★离散度大 ⇒ 灯的朝向不统一，必须看场景" if _kdev > 25.0 else ""))
        _n_x = len(LAST_XREF)
        print("[RB_CAR] 灯识别交叉核对：%s" %
              ("全部一致 ✓" if not _n_x else
               "★不一致 %d 条（路口,臂,按臂组,看灯组,灯名）= %s" % (_n_x, LAST_XREF[:6])))
        self.report({"INFO"}, "车流：%d 辆 / %d 条路线 / %d 个停车线 / %d 帧"
                    % (info["count"], len(routes), info["stops"], frames))
        return {"FINISHED"}
