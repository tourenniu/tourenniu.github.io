"""人行道生成：把路面的「边界」沿外法线挤出一条带子，并整体抬高 z。

思路和路面生成一样（算点 → 编号 → 拼面），但输入是「已经算好的路面 mesh」，
所以第一步是先从面里把边界找出来：

  1. 找边界边：只被「一个面」用到的边。因为面的顶点是逆时针的，所以
     a→b 这条边走的时候路面在左边 → 朝外的法线 = 边方向顺时针转 90° = (u_y, −u_x)。
  2. 把边界边按 a→b 的走向串成闭合环：最外圈一个环，每个街区也是一个环（街区 = 洞）。
     洞的方向是「顺时针」（有向面积为负），后面街区填面就靠这个区分。
  3. 每个边界点沿外法线挪 width，得到「外缘点」（offset_loop）：
       · 相邻两条边的外法线几乎相同（直线段内部 / 圆弧内部）→ 用两条法线的平均方向挪
       · 真拐角（法线夹角大）：
           凸角（法线逆时针转）→ 补一小段半径 width 的圆弧（圆角）
           凹角（法线顺时针转）→ 取两条外移线的交点（斜接）
  4. 拼面：
       顶面：每条边界 → 一个四边形（路面边界 → 外缘）
       立面（路缘）：从路面高度 z 竖直拉到 z + height
"""

import math

from .road_surface import _sub, _add, _mul, _dot, _cross, _line_isect


def boundary_edges(verts, faces):
    """返回边界边 [(a, b, nout), ...]：a→b 是它在面里的走向，nout 是朝外的单位法线。"""
    use = {}
    for f in faces:
        n = len(f)
        for k in range(n):
            a, b = f[k], f[(k + 1) % n]
            key = (a, b) if a < b else (b, a)
            use.setdefault(key, []).append((a, b))
    out = []
    for key, lst in use.items():
        if len(lst) != 1:                       # 被两个面共用 = 内部边
            continue
        a, b = lst[0]
        d = _sub(verts[b][:2], verts[a][:2])
        L = math.hypot(d[0], d[1])
        if L < 1e-12:
            continue
        u = (d[0] / L, d[1] / L)
        out.append((a, b, (u[1], -u[0])))       # 顺时针转 90° → 朝外
    return out


def chains(edges):
    """按 a→b 把边界边串成闭合环。"""
    head = {}
    for k, (a, b, n) in enumerate(edges):
        head.setdefault(a, []).append(k)
    used = [False] * len(edges)
    loops = []
    for k0 in range(len(edges)):
        if used[k0]:
            continue
        loop, k = [], k0
        while not used[k]:
            a, b, n = edges[k]
            used[k] = True
            loop.append([a, b, n])
            cand = [kk for kk in head.get(b, []) if not used[kk]]
            if not cand:
                break
            k = cand[0]
        if len(loop) >= 3:
            loops.append(loop)
    return loops


def loops_of(verts, faces):
    """一次性拿到所有边界环。"""
    return chains(boundary_edges(verts, faces))


def loop_points(verts, loop):
    """环上的点（按走向），以及每个点处「进入 / 离开」的外法线。"""
    m = len(loop)
    P = [verts[loop[k][0]][:2] for k in range(m)]
    Nin = [loop[(k - 1) % m][2] for k in range(m)]
    Nout = [loop[k][2] for k in range(m)]
    return P, Nin, Nout


def loop_area(P):
    """环的有向面积：负 = 洞（街区）。"""
    s = 0.0
    n = len(P)
    for k in range(n):
        x1, y1 = P[k]
        x2, y2 = P[(k + 1) % n]
        s += x1 * y2 - x2 * y1
    return s * 0.5


def _arc_mid(center, r, a0, a1, seg):
    """圆弧上的中间点（不含首尾），走最短的那一边。"""
    da = a1 - a0
    while da <= -math.pi:
        da += 2.0 * math.pi
    while da > math.pi:
        da -= 2.0 * math.pi
    seg = max(1, int(seg))
    pts = []
    for k in range(1, seg):
        a = a0 + da * k / float(seg)
        pts.append((center[0] + r * math.cos(a), center[1] + r * math.sin(a)))
    return pts


def offset_loop(verts, loop, width, join_segments=3, smooth_deg=25.0):
    """把一条边界环沿外法线外移 width。

    返回 (groups, info)：
      groups[k] = 第 k 个边界点对应的「外缘点」（1 个点，或凸角处的一小段圆弧点）

    规则：
      · 平滑（直线段 / 凸弧）→ 沿两条法线的平均方向挪 width
      · 凸角（法线逆时针转）→ 补一小段半径 width 的圆弧
      · 凹角（转到很急）→ 取两条外移线的交点（斜接）
      · 凹圆弧往里收的时候夹紧到局部曲率半径，不至于收穿
      · **最后一步：连续几个外缘点离得太近（小于 2% 宽度）就合并成一个点**
        —— 拐角被打包成一个角点，四边形退化成三角面，街区就变成干净的形状
    """
    P, Nin, Nout = loop_points(verts, loop)
    m = len(P)
    cos_lim = math.cos(math.radians(smooth_deg))
    info = {'join_arcs': 0, 'miter': 0, 'merged': 0}

    def seg_dir(k):                                    # 第 k 段（P[k] → P[k+1]）方向
        d = _sub(P[(k + 1) % m], P[k])
        L = math.hypot(d[0], d[1]) or 1.0
        return (d[0] / L, d[1] / L)

    def cur_radius(k):
        ang = math.acos(max(-1.0, min(1.0, _dot(Nin[k], Nout[k]))))
        if ang < 1e-6:
            return 1e9
        pv1, pv2 = P[(k - 1) % m], P[(k + 1) % m]
        seg = 0.5 * (math.hypot(P[k][0] - pv1[0], P[k][1] - pv1[1]) +
                     math.hypot(pv2[0] - P[k][0], pv2[1] - P[k][1]))
        return seg / ang

    def offset_one(k, w):
        a, b = Nin[k], Nout[k]
        n = _add(a, b)
        L = math.hypot(n[0], n[1])
        n = a if L < 1e-9 else (n[0] / L, n[1] / L)
        return _add(P[k], _mul(n, w))

    # ---- 逐点算外缘点 ----
    groups = []
    for k in range(m):
        pk = P[k]
        a, b = Nin[k], Nout[k]
        if _dot(a, b) >= cos_lim:                          # 平滑
            w_eff = width
            if _cross(a, b) < 0.0:                         # 凹弧：夹紧，别收穿
                w_eff = min(width, max(0.0, cur_radius(k) - 1e-3))
            groups.append([offset_one(k, w_eff)])
        elif _cross(a, b) > 0.0:                           # 凸角 → 补小圆弧
            q0 = _add(pk, _mul(a, width))
            q1 = _add(pk, _mul(b, width))
            a0 = math.atan2(q0[1] - pk[1], q0[0] - pk[0])
            a1 = math.atan2(q1[1] - pk[1], q1[0] - pk[0])
            groups.append([q0] + _arc_mid(pk, width, a0, a1, join_segments) + [q1])
            info['join_arcs'] += 1
        else:                                              # 凹角（急转）→ 斜接
            up = _sub(pk, P[(k - 1) % m])
            un = _sub(P[(k + 1) % m], pk)
            hit = _line_isect(_add(pk, _mul(a, width)), up,
                              _add(pk, _mul(b, width)), un)
            if hit is None or abs(hit[0]) > width * 6.0:
                q0 = _add(pk, _mul(a, width))
                q1 = _add(pk, _mul(b, width))
                groups.append([((q0[0] + q1[0]) * 0.5, (q0[1] + q1[1]) * 0.5)])
            else:
                groups.append([_add(_add(pk, _mul(a, width)), _mul(up, hit[0]))])
                info['miter'] += 1

    # ---- 就近合并：连续的单点外缘点离得太近 → 合成一个点 ----
    eps = max(1e-4, 0.02 * width)
    single = [len(g) == 1 for g in groups]
    if sum(single) >= 2:
        start = next((k for k in range(m) if not single[k]), None)
        order = list(range(m)) if start is None else [(start + 1 + i) % m for i in range(m - 1)]
        done = set()
        i = 0
        while i < len(order):
            k = order[i]
            if not single[k]:
                i += 1
                continue
            run = [k]
            j = i + 1
            px, py = groups[k][0]
            while j < len(order) and single[order[j]]:
                qx, qy = groups[order[j]][0]
                if math.hypot(qx - px, qy - py) > eps:
                    break
                run.append(order[j])
                j += 1
            if len(run) >= 2:
                # 把「同一拐角」的相邻单点也吸收进来（外缘点离拐角足够近）
                anchor_q = groups[run[0]][0]
                lim = max(eps, 0.6 * width)
                while True:
                    kp = (run[0] - 1) % m
                    if not single[kp] or kp in run or kp in done:
                        break
                    q = groups[kp][0]
                    if math.hypot(q[0] - anchor_q[0], q[1] - anchor_q[1]) > lim:
                        break
                    run.insert(0, kp)
                while True:
                    kn = (run[-1] + 1) % m
                    if not single[kn] or kn in run or kn in done:
                        break
                    q = groups[kn][0]
                    if math.hypot(q[0] - anchor_q[0], q[1] - anchor_q[1]) > lim:
                        break
                    run.append(kn)
                # 角点 = 两侧外移线的交点（拿不到就用平均）
                p_a, d_a = groups[run[0]][0], seg_dir((run[0] - 1) % m)
                p_b, d_b = groups[run[-1]][0], seg_dir(run[-1])
                hit = _line_isect(p_a, d_a, p_b, d_b)
                if hit is not None and abs(hit[0]) <= width * 8.0 + 1e-9:
                    Q = _add(p_a, _mul(d_a, hit[0]))
                else:
                    Q = (sum(groups[t][0][0] for t in run) / len(run),
                         sum(groups[t][0][1] for t in run) / len(run))
                for t in run:
                    groups[t] = [Q]
                    done.add(t)
                info['merged'] += len(run)
                i = j
            else:
                i += 1
    return groups, info


def flatten(groups):
    """把 groups 拉平成一条不带重复相邻点的点列。"""
    pts = []
    for g in groups:
        for p in g:
            if not pts or abs(p[0] - pts[-1][0]) > 1e-9 or abs(p[1] - pts[-1][1]) > 1e-9:
                pts.append(p)
    if len(pts) > 1 and abs(pts[0][0] - pts[-1][0]) <= 1e-9 and abs(pts[0][1] - pts[-1][1]) <= 1e-9:
        pts.pop()
    return pts


def build_sidewalk(verts, faces, width, height, wall=True, join_segments=3,
                   smooth_deg=25.0):
    """生成人行道。

    verts/faces : 路面（build_road_surface 的输出）
    width       : 人行道宽度（沿外法线挤出多少）
    height      : 抬高多少（z 方向）
    wall        : 是否要路缘立面

    返回 (sv_verts, sv_faces, info)；sv_faces 里的索引是「局部」的（从 0 开始）。
    """
    info = {'loops': 0, 'band': 0, 'wall': 0, 'join_arcs': 0, 'miter': 0, 'merged_total': 0, 'flipped': 0, 'skipped': 0}
    z0 = [(v[2] if len(v) > 2 else 0.0) for v in verts]
    loops = loops_of(verts, faces)

    sv = []
    svf = []
    cache = {}

    def vid(p, z):
        key = (round(p[0], 6), round(p[1], 6), round(z, 6))
        i = cache.get(key)
        if i is None:
            i = len(sv)
            cache[key] = i
            sv.append((p[0], p[1], z))
        return i

    for loop in loops:
        m = len(loop)
        if m < 3:
            continue
        info['loops'] += 1
        P = [verts[loop[k][0]][:2] for k in range(m)]
        ZZ = [z0[loop[k][0]] for k in range(m)]
        off, oinfo = offset_loop(verts, loop, width, join_segments, smooth_deg)
        info['join_arcs'] += oinfo['join_arcs']
        info['miter'] += oinfo['miter']
        info['merged_total'] += oinfo.get('merged', 0)

        # ---- 顶面 + 立面 ----
        for k in range(m):
            k2 = (k + 1) % m
            p0, p1 = P[k], P[k2]
            za, zb = ZZ[k], ZZ[k2]
            top_a, top_b = za + height, zb + height
            q0 = off[k][-1]           # 起点用「离开法线」那侧的外缘点
            q1 = off[k2][0]           # 终点用「进入法线」那侧的外缘点
            if abs(q0[0] - q1[0]) < 1e-9 and abs(q0[1] - q1[1]) < 1e-9:
                # 拐角被合并成一个斜接点 → 这一格退化成三角形
                quad = [vid(q0, top_a), vid(p1, top_b), vid(p0, top_a)]
            else:
                quad = [vid(q0, top_a), vid(q1, top_b), vid(p1, top_b), vid(p0, top_a)]
            # 绕向自检：投影面积 ≤0 就反过来 / 丢掉（兜底，保证顶面永远朝上）
            poly = [sv[i][:2] for i in quad]
            a2 = 0.0
            for j in range(len(poly)):
                x1, y1 = poly[j]; x2, y2 = poly[(j + 1) % len(poly)]
                a2 += x1 * y2 - x2 * y1
            if a2 < -1e-12:
                quad = list(reversed(quad))
                info['flipped'] += 1
                a2 = -a2
            if a2 <= 1e-9:
                info['skipped'] += 1
                continue
            svf.append(quad)
            info['band'] += 1
            if wall:
                svf.append([vid(p0, za), vid(p1, zb), vid(p1, top_b), vid(p0, top_a)])
                info['wall'] += 1
        # 凸角的小圆弧：补一块扇形 + 一段立面
        for k in range(m):
            arc = off[k]
            if len(arc) < 3:
                continue
            pk = P[k]
            za, top_a = ZZ[k], ZZ[k] + height
            for j in range(len(arc) - 1):
                a0, a1 = arc[j], arc[j + 1]
                svf.append([vid(pk, top_a), vid(a0, top_a), vid(a1, top_a)])
                if wall:
                    svf.append([vid(a1, top_a), vid(a0, top_a), vid(a0, za), vid(a1, za)])
    return sv, svf, info