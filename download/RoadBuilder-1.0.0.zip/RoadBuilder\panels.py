import bpy

from .operators import BuildRoadOperator, BuildRoadSurfaceOperator

# ★ 面板分组的「父面板」id：所有子面板都挂到它下面（可折叠）
_MAIN_ID = "VIEW3D_PT_road_builder"


class RoadBuilderPanel(bpy.types.Panel):
    """主面板：只放"最常按的两个按钮"和路宽 —— 其余都收进下面的子面板。"""

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "道路生成"
    bl_label = "道路生成"
    bl_idname = _MAIN_ID

    def draw(self, context):
        layout = self.layout
        settings = context.scene.road_builder

        # ★★ 入口：没点「开始使用」之前，面板只有这一个按钮（和 iCity 一样）
        if not settings.rb_started:          # ★ 跟着本文件走
            box0 = layout.box()
            box0.label(text="第一次使用：先点下面的按钮", icon='INFO')
            box0.operator("road_builder.start_use", text="开始使用", icon='PLAY')
            layout.label(text="（会导入资产材质 + 注册资产库）", icon='QUESTION')
            return

        # ★ 资产库路径：放最上面，一目了然（合集/材质/模型都从这里找）
        box = layout.box()
        box.label(text="资产库（合集 / 材质 / 模型都从这里找）", icon='FILE_BLEND')
        box.prop(settings, "asset_lib")
        layout.separator()

        layout.prop(settings, "road_width")
        layout.separator()
        layout.operator(BuildRoadOperator.bl_idname, text="生成道路(几何节点)", icon='MESH_PLANE')
        layout.separator()
        layout.operator(BuildRoadSurfaceOperator.bl_idname,
                        text="生成道路", icon='MESH_GRID')
        layout.label(text="其余设置见下面的分组 ↓", icon='INFO')


class _SubPanel(bpy.types.Panel):
    """所有子面板的公共设置。"""

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "道路生成"
    bl_parent_id = _MAIN_ID

    @classmethod
    def poll(cls, context):
        """★ 没点「开始使用」之前：这些分组整组【不显示】（只剩主面板那个小框）"""
        try:
            return bool(context.scene.road_builder.rb_started)   # ★ 跟着本文件走
        except Exception:
            return False


class RBP_PT_intersection(_SubPanel):
    """① 路口圆弧 / 人行道 / 地块 / 模型资产。"""

    bl_label = "① 路口 · 人行道 · 地块"
    bl_idname = "VIEW3D_PT_rb_intersection"

    def draw(self, context):
        layout = self.layout
        s = context.scene.road_builder
        col = layout.column(align=True)

        col.label(text="路口圆弧倒角:", icon='MOD_BEVEL')
        col.prop(s, "corner_radius_ratio")
        col.prop(s, "corner_segments")
        col.separator()
        col.prop(s, "gen_sidewalk")
        if s.gen_sidewalk:
            col.prop(s, "sidewalk_width")
            col.prop(s, "sidewalk_height")
        col.separator()
        col.prop(s, "gen_blocks")
        col.prop(s, "gen_buildings")
        if s.gen_buildings:
            col.prop(s, "bld_count")
            col.prop(s, "bld_height_mode")
            if s.bld_height_mode == 'RANGE':
                col.prop(s, "bld_h_min")
                col.prop(s, "bld_h_max")
            else:
                col.prop(s, "bld_height_pct")
            col.prop(s, "bld_gap")
            col.prop(s, "bld_seed")
        col.separator()
        col.prop(s, "use_asset")
        if s.use_asset:
            col.prop(s, "asset_coll")
            col.prop(s, "asset_random_dir")
        col.operator("road_builder.add_building_asset",
                     text="把我的模型加入建筑资产", icon='IMPORT')
        col.label(text="（选中模型 → 点按钮；也可在当前文件建同名集合临时替换）", icon='INFO')
        col.label(text="（资产库路径在主面板最上面）", icon='INFO')


class RBP_PT_marking(_SubPanel):
    """② 路面材质 / 斑马线 / 各种标线。"""

    bl_label = "② 路面材质 · 斑马线 · 标线"
    bl_idname = "VIEW3D_PT_rb_marking"

    def draw(self, context):
        layout = self.layout
        s = context.scene.road_builder
        col = layout.column(align=True)

        col.prop(s, "use_road_mat")
        if s.use_road_mat:
            col.template_ID(s, "road_mat_name")
            col.template_ID(s, "sidewalk_mat_name")
            col.prop(s, "road_mat_uv_scale")
        col.separator()
        col.prop(s, "gen_crosswalk")
        if s.gen_crosswalk:
            col.prop(s, "crosswalk_obj")
            col.prop(s, "crosswalk_gap")
            col.prop(s, "crosswalk_scale")
            col.prop(s, "crosswalk_lift")
        col.separator()
        col.label(text="标线（起点相对斑马线）:", icon='DRIVER_DISTANCE')
        col.prop(s, "line_xwalk_gap")
        col.prop(s, "gen_edgeline")
        if s.gen_edgeline:
            col.template_ID(s, "edgeline_obj")
            col.prop(s, "edgeline_inset")
            col.prop(s, "edgeline_width")
            col.prop(s, "edgeline_lift")
        col.prop(s, "gen_centerline")
        if s.gen_centerline:
            col.template_ID(s, "centerline_obj")
            col.prop(s, "centerline_width")
            col.prop(s, "centerline_sep")
            col.prop(s, "centerline_lift")
        col.prop(s, "gen_laneline")
        if s.gen_laneline:
            col.template_ID(s, "laneline_obj")
            col.prop(s, "laneline_ratio")
            col.prop(s, "laneline_dash")
            col.prop(s, "laneline_gap")
            col.prop(s, "laneline_width")
            col.prop(s, "laneline_lift")


class RBP_PT_tlight(_SubPanel):
    """③ 红绿灯：位置 + 信号时序（四相位）。"""

    bl_label = "③ 红绿灯"
    bl_idname = "VIEW3D_PT_rb_tlight"

    def draw(self, context):
        layout = self.layout
        s = context.scene.road_builder
        col = layout.column(align=True)

        col.prop(s, "gen_tlight")
        if not s.gen_tlight:
            return
        col.prop(s, "tlight_obj")
        col.separator()
        col.label(text="位置:", icon='EMPTY_AXIS')
        col.prop(s, "tlight_right")
        col.prop(s, "tlight_lateral")
        col.prop(s, "tlight_along")
        col.prop(s, "tlight_rot")
        col.separator()
        box = col.box()
        box.label(text="信号时序（四相位：左转 → 直行/右转）", icon='TIME')
        box.prop(s, "tlight_left")
        box.prop(s, "tlight_phase")
        box.prop(s, "tlight_cycle")
        box.prop(s, "tlight_blink_n")
        box.prop(s, "tlight_blink_len")
        box.label(text="周期由资产形态推出（每条相位 = 常亮 + 闪烁）", icon='INFO')
        col.separator()
        col.prop(s, "tlight_scale")
        col.prop(s, "tlight_lift")


class RBP_PT_traffic(_SubPanel):
    """④ 交通流：车辆数/车速/转弯/停车 等主参数。"""

    bl_label = "④ 交通流"
    bl_idname = "VIEW3D_PT_rb_traffic"

    def draw(self, context):
        layout = self.layout
        s = context.scene.road_builder
        col = layout.column(align=True)

        col.prop(s, "gen_traffic")
        if not s.gen_traffic:
            return
        col.operator("road_builder.build_traffic", text="生成车流", icon='AUTO')
        col.separator()
        box = col.box()
        box.label(text="基本（遵守上面的相位表）", icon='AUTO')
        box.prop(s, "traffic_count")
        box.prop(s, "traffic_speed")
        box.prop(s, "traffic_left_ratio")
        col.separator()
        box2 = col.box()
        box2.label(text="转弯与停车", icon='MOD_CURVE')
        box2.prop(s, "traffic_turn_radius")
        box2.prop(s, "traffic_turn_seg")
        box2.prop(s, "traffic_lane_shift")
        box2.prop(s, "traffic_stop_back")


class RBP_PT_wheel(_SubPanel):
    """⑤ 车轮动画：滚动 + 前轮转向（代码直接驱动 4 根轮骨）。"""

    bl_label = "⑤ 车轮动画"
    bl_idname = "VIEW3D_PT_rb_wheel"

    def draw(self, context):
        layout = self.layout
        s = context.scene.road_builder
        col = layout.column(align=True)

        col.prop(s, "traffic_wheel_anim")
        if not s.traffic_wheel_anim:
            col.label(text="（关掉后轮子不动）", icon='INFO')
            return
        col.prop(s, "traffic_wheel_rate")
        box = col.box()
        box.label(text="前轮转向（真车关系：atan(轴距×曲率)）", icon='DRIVER_ROTATIONAL_DIFFERENCE')
        box.prop(s, "traffic_steer_gain")
        box.prop(s, "traffic_steer_tau")


class RBP_PT_advanced(_SubPanel):
    """⑥ 高级：库/集合/种子/帧数/更新检查 —— 默认折叠，平时不用动。"""

    bl_label = "⑥ 高级（一般不用改）"
    bl_idname = "VIEW3D_PT_rb_advanced"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        s = context.scene.road_builder
        col = layout.column(align=True)

        col.prop(s, "traffic_lane")
        col.prop(s, "traffic_seed")
        col.prop(s, "traffic_frames")
        col.separator()
        col.prop(s, "traffic_coll")
        col.prop(s, "traffic_target")
        col.prop(s, "traffic_yaw")
        col.separator()
        col.operator("rb.check_update", text="检查更新（联网）", icon='FILE_REFRESH')
        if getattr(s, "rb_update_status", ""):
            box = col.box()
            box.label(text=s.rb_update_status, icon='INFO')
