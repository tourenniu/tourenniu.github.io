
import math
import os
import random

from .road_surface import _poly_area, _fan, _ear_clip
from .sidewalk import loops_of, loop_points, loop_area, offset_loop, flatten


def _inside(poly, p):
    x, y = p
    n = len(poly)
    c = False
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi + 1e-30) + xi):
            c = not c
        j = i
    return c


def block_polygons(verts, faces, inset=0.0, join_segments=3):
    out = []
    for loop in loops_of(verts, faces):
        P, _, _ = loop_points(verts, loop)
        if len(P) < 3 or loop_area(P) >= 0.0:
            continue
        poly = P
        if inset > 1e-9:
            groups, _ = offset_loop(verts, loop, inset, join_segments)
            poly = flatten(groups)
        if len(poly) < 3:
            continue
        if _poly_area(poly) < 0.0:
            poly = list(reversed(poly))
        out.append(poly)
    return out


def fill_faces(polys, z):
    fv = []
    ff = []
    cache = {}

    def vid(p):
        key = (round(p[0], 6), round(p[1], 6))
        i = cache.get(key)
        if i is None:
            i = len(fv)
            cache[key] = i
            fv.append((p[0], p[1], z))
        return i

    info = {'blocks': 0, 'tris': 0}
    for poly in polys:
        uniq = []
        for p in poly:
            i = vid(p)
            if not uniq or uniq[-1] != i:
                uniq.append(i)
        if len(uniq) > 1 and uniq[0] == uniq[-1]:
            uniq.pop()
        if len(uniq) < 3:
            continue
        cx = sum(fv[i][0] for i in uniq) / len(uniq)
        cy = sum(fv[i][1] for i in uniq) / len(uniq)
        ci = vid((cx, cy))
        pts = [q[:2] for q in fv]
        tris, ok = _fan(ci, uniq, pts)
        if not ok:
            tris = _ear_clip(uniq, pts)
            if tris:
                info['ear_clip'] = info.get('ear_clip', 0) + 1
        made = 0
        for (i0, i1, i2) in tris:
            a = _poly_area([pts[i0], pts[i1], pts[i2]])
            if abs(a) <= 1e-12:
                continue
            ff.append([i0, i1, i2] if a > 0 else [i0, i2, i1])
            made += 1
        if made:
            info['blocks'] += 1
            info['tris'] += made
    return fv, ff, info


def _zone_layout(x0, y0, x1, y1, count, rnd):
    count = max(1, int(count))
    W = max(x1 - x0, 1e-9)
    H = max(y1 - y0, 1e-9)
    best = None
    for cols in range(1, count + 1):
        rows = int(math.ceil(count / float(cols)))
        waste = cols * rows - count
        cw, ch = W / cols, H / rows
        pen = abs(math.log((cw / ch) / 1.0)) if cw > 0 and ch > 0 else 9.0
        score = waste * 1.0 + pen * 2.0
        if best is None or score < best[0]:
            best = (score, cols, rows)
    _, cols, rows = best
    jx = sorted(rnd.uniform(-0.12, 0.12) * (W / cols) for _ in range(cols - 1))
    jy = sorted(rnd.uniform(-0.12, 0.12) * (H / rows) for _ in range(rows - 1))
    xs = [x0] + [x0 + W * (c + 1) / cols + jx[c] for c in range(cols - 1)] + [x1]
    ys = [y0] + [y0 + H * (r + 1) / rows + jy[r] for r in range(rows - 1)] + [y1]

    def lerp_row(u):
        f = u * cols
        i0 = min(int(f), cols - 1)
        t = f - i0
        return xs[i0] * (1 - t) + xs[i0 + 1] * t

    zones = []
    for r in range(rows):
        n = cols if r < rows - 1 else count - (rows - 1) * cols
        if n <= 0:
            continue
        for c in range(n):
            zones.append((lerp_row(c / float(n)), ys[r], lerp_row((c + 1) / float(n)), ys[r + 1]))
    return zones


def plot_rects(polys, count=3, gap=2.0, seed=0, min_side=1.0):
    rnd = random.Random(seed)
    out = []
    for poly in polys:
        xs = [p[0] for p in poly]
        ys = [p[1] for p in poly]
        for (zx0, zy0, zx1, zy1) in _zone_layout(min(xs), min(ys), max(xs), max(ys), count, rnd):
            cxc, cyc = (zx0 + zx1) * 0.5, (zy0 + zy1) * 0.5
            bw = max((zx1 - zx0) - gap, min_side)
            bh = max((zy1 - zy0) - gap, min_side)
            k = 1.0
            ok = False
            for _ in range(28):
                w2, h2 = bw * k * 0.5, bh * k * 0.5
                if all(_inside(poly, q) for q in
                       ((cxc - w2, cyc - h2), (cxc + w2, cyc - h2),
                        (cxc + w2, cyc + h2), (cxc - w2, cyc + h2),
                        (cxc, cyc), (cxc - w2, cyc), (cxc + w2, cyc))):
                    ok = True
                    break
                k *= 0.86
            if ok:
                out.append((cxc, cyc, bw * k, bh * k))
    return out


def random_buildings(polys, z, count=3, height_min=8.0, height_max=30.0,
                     height_mode='RANGE', height_pct=0.15, _ignored=(),
                     gap=2.0, seed=0, min_side=1.0):
    rnd = random.Random(seed + 7777)
    bv = []
    bf = []
    info = {'buildings': 0}
    for (cx, cy, w, d) in plot_rects(polys, count, gap, seed, min_side):
        h = rnd.uniform(height_min, height_max)
        bx0, bx1 = cx - w / 2, cx + w / 2
        by0, by1 = cy - d / 2, cy + d / 2
        i0 = len(bv); bv.append((bx0, by0, z))
        i1 = len(bv); bv.append((bx1, by0, z))
        i2 = len(bv); bv.append((bx1, by1, z))
        i3 = len(bv); bv.append((bx0, by1, z))
        i4 = len(bv); bv.append((bx0, by0, z + h))
        i5 = len(bv); bv.append((bx1, by0, z + h))
        i6 = len(bv); bv.append((bx1, by1, z + h))
        i7 = len(bv); bv.append((bx0, by1, z + h))
        bf.append([i3, i2, i1, i0])
        bf.append([i4, i5, i6, i7])
        bf.append([i0, i1, i5, i4])
        bf.append([i1, i2, i6, i5])
        bf.append([i2, i3, i7, i6])
        bf.append([i3, i0, i4, i7])
        info['buildings'] += 1
    return bv, bf, info



BUILDING_TAG = "rb_building"


def load_assets(blend_path, coll_name):
    import bpy
    coll = bpy.data.collections.get(coll_name)
    if coll is not None:
        objs = [o for o in coll.objects if o.type == 'MESH']
        if objs:
            return objs, ""
    if not blend_path:
        return [], "没填资产 .blend 路径，且当前文件里也没有叫 %s 的集合" % coll_name
    if not os.path.exists(blend_path):
        return [], "资产文件不存在：%s" % blend_path
    try:
        with bpy.data.libraries.load(blend_path, link=True) as (src, dst):
            names = list(src.collections or [])
            pick = coll_name if coll_name in names else next(
                (n for n in names if n.lower() == coll_name.lower()), None)
            if pick is None:
                pick = next((n for n in names if coll_name.lower() in n.lower()), None)
            if pick is None:
                return [], "库里没有集合 %s；库里有：%s" % (coll_name, names)
            dst.collections = [pick]
            coll_name = pick
        coll = bpy.data.collections.get(coll_name)
        if coll is None and dst.collections:
            coll = dst.collections[0]
    except Exception as e:
        return [], "读资产库失败：%s" % e
    if coll is None:
        return [], "link 之后找不到集合 %s" % coll_name
    return [o for o in coll.objects if o.type == 'MESH'], ""


def asset_bbox(obj):
    me = obj.data
    if len(me.vertices) == 0:
        return (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    xs = [v.co.x for v in me.vertices]
    ys = [v.co.y for v in me.vertices]
    zs = [v.co.z for v in me.vertices]
    return (min(xs), min(ys), min(zs), max(xs), max(ys), max(zs))


def asset_world_bbox(obj):
    bb = obj.bound_box
    if bb is None or len(bb) == 0:
        return None
    mw = obj.matrix_world
    pts = [mw @ __import__("mathutils").Vector(c) for c in bb]
    xs = [p.x for p in pts]
    ys = [p.y for p in pts]
    zs = [p.z for p in pts]
    return (min(xs), min(ys), min(zs), max(xs), max(ys), max(zs))


def _bbox_under(bbox, scale, rot_deg):
    x0, y0, z0, x1, y1, z1 = bbox
    ca = math.cos(math.radians(rot_deg))
    sa = math.sin(math.radians(rot_deg))
    xs, ys, zs = [], [], []
    for i in range(8):
        x = x1 if (i & 1) else x0
        y = y1 if (i & 2) else y0
        z = z1 if (i & 4) else z0
        X = scale[0] * x
        Y = scale[1] * y
        xs.append(X * ca - Y * sa)
        ys.append(X * sa + Y * ca)
        zs.append(scale[2] * z)
    return min(xs), max(xs), min(ys), max(ys), min(zs), max(zs)


def place_asset_buildings(target_coll, polys, z, blend_path, coll_name,
                          count=3, height_min=8.0, height_max=30.0, gap=2.0,
                          height_mode='RANGE', height_pct=0.15,
                          seed=0, dirs=(0.0, 90.0, 180.0, 270.0),
                          name_prefix="RB_BLD_"):
    import bpy
    from mathutils import Euler
    from mathutils import Matrix, Vector
    assets, err = load_assets(blend_path, coll_name)
    if err or not assets:
        return {'buildings': 0}, err or "资产集合里没有网格对象"
    bboxes = {}
    for o in assets:
        bb = asset_world_bbox(o)
        if bb is None:
            bb = asset_bbox(o)
        bboxes[o.name] = bb
    rnd = random.Random(seed + 20240)
    info = {'buildings': 0, 'dirs': {}, 'assets': len(assets), 'used': {}}
    bag = []
    def pick():
        nonlocal bag
        if not bag:
            bag = list(assets)
            rnd.shuffle(bag)
        return bag.pop()
    for (cx, cy, w, d) in plot_rects(polys, count, gap, seed):
        obj = pick()
        bb = bboxes[obj.name]
        bx0, by0, bz0, bx1, by1, bz1 = bb
        if bx1 <= bx0 or by1 <= by0 or bz1 <= bz0:
            continue
        rot = rnd.choice(dirs) if dirs else 0.0
        ux0, ux1, uy0, uy1, uz0, uz1 = _bbox_under(bb, (1.0, 1.0, 1.0), rot)
        sx = w / max(ux1 - ux0, 1e-9)
        sy = d / max(uy1 - uy0, 1e-9)
        h0_asset = bz1 - bz0
        if height_mode == 'PERCENT':
            s_xy = math.sqrt(max(sx * sy, 1e-12))
            h = h0_asset * s_xy * (1.0 + rnd.uniform(-height_pct, height_pct))
            h = max(h, 0.5)
        else:
            h = rnd.uniform(height_min, height_max)
            h = min(h, h0_asset)
        sz = h / max(uz1 - uz0, 1e-9)
        ax0, ax1, ay0, ay1, az0, az1 = _bbox_under(bb, (sx, sy, sz), rot)
        new = obj.copy()
        new.data = obj.data
        new.name = name_prefix + obj.name
        new[BUILDING_TAG] = 1
        M = (Matrix.Translation(Vector((cx - (ax0 + ax1) * 0.5,
                                        cy - (ay0 + ay1) * 0.5,
                                        z - az0)))
             @ Matrix.Rotation(math.radians(rot), 4, 'Z')
             @ Matrix.Diagonal((sx, sy, sz, 1.0)).to_4x4()
             @ obj.matrix_world)
        new.matrix_world = M
        target_coll.objects.link(new)
        info['buildings'] += 1
        info['dirs'][rot] = info['dirs'].get(rot, 0) + 1
        info['used'][obj.name] = info['used'].get(obj.name, 0) + 1
    return info, ""


def clear_buildings(colls=None):
    import bpy
    n = 0
    for o in list(bpy.data.objects):
        if o.get(BUILDING_TAG) or o.get("rb_crosswalk") or o.get("rb_edgeline"):
            bpy.data.objects.remove(o, do_unlink=True)
            n += 1
    return n


def clear_roads():
    import bpy
    n = 0
    for o in list(bpy.data.objects):
        if o.get("rb_road"):
            bpy.data.objects.remove(o, do_unlink=True)
            n += 1
    return n