"""街区（block）+ 建筑：填街区地面、切地块、放方块 / 放外部资产。

流程：
  1. 从路面 mesh 找边界环（复用 sidewalk.loops_of）→ 有向面积为负的环 = 洞 = 街区。
  2. 把洞的边界沿「朝内的外法线」缩进一个距离（默认 = 人行道宽度）→ 街区可用区域。
  3. 填面：多边形三角化（先试「从质心扇形」，不合法就耳切）。
  4. 切地块 plot_rects()：把街区包围盒切成 count 块地（尽量接近正方 + 随机抖动），
     每块地再往回收缩到「四角+中心都在街区内」→ 得到最终矩形。
  5. 两种放法（用同一批地块，保证布局一致）：
       · random_buildings()       放长方体（尺寸 = 地块，高度随机）
       · place_asset_buildings()  放外部资产（.blend 库里的集合），按包围盒缩放到地块
"""

import math
import os
import random

from .road_surface import _poly_area, _fan, _ear_clip
from .sidewalk import loops_of, loop_points, loop_area, offset_loop, flatten


def _inside(poly, p):
    """点是否在多边形内（射线法）。"""
    x, y = p
    n = len(poly)
    c = False
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi + 1e-30) + xi):
            c = not c
        j = i
    return c


def block_polygons(verts, faces, inset=0.0, join_segments=3):
    """街区多边形（逆时针、已往里缩 inset）。inset 一般给人行道宽度。"""
    out = []
    for loop in loops_of(verts, faces):
        P, _, _ = loop_points(verts, loop)
        if len(P) < 3 or loop_area(P) >= 0.0:
            continue
        poly = P
        if inset > 1e-9:
            groups, _ = offset_loop(verts, loop, inset, join_segments)
            poly = flatten(groups)
        if len(poly) < 3:
            continue
        if _poly_area(poly) < 0.0:
            poly = list(reversed(poly))
        out.append(poly)
    return out


def fill_faces(polys, z):
    """把街区多边形填成面。返回 (fv, ff, info)，索引是局部的。"""
    fv = []
    ff = []
    cache = {}

    def vid(p):
        key = (round(p[0], 6), round(p[1], 6))
        i = cache.get(key)
        if i is None:
            i = len(fv)
            cache[key] = i
            fv.append((p[0], p[1], z))
        return i

    info = {'blocks': 0, 'tris': 0}
    for poly in polys:
        uniq = []
        for p in poly:
            i = vid(p)
            if not uniq or uniq[-1] != i:
                uniq.append(i)
        if len(uniq) > 1 and uniq[0] == uniq[-1]:
            uniq.pop()
        if len(uniq) < 3:
            continue
        cx = sum(fv[i][0] for i in uniq) / len(uniq)
        cy = sum(fv[i][1] for i in uniq) / len(uniq)
        ci = vid((cx, cy))
        pts = [q[:2] for q in fv]
        tris, ok = _fan(ci, uniq, pts)
        if not ok:
            tris = _ear_clip(uniq, pts)
            if tris:
                info['ear_clip'] = info.get('ear_clip', 0) + 1
        made = 0
        for (i0, i1, i2) in tris:
            a = _poly_area([pts[i0], pts[i1], pts[i2]])
            if abs(a) <= 1e-12:
                continue
            ff.append([i0, i1, i2] if a > 0 else [i0, i2, i1])
            made += 1
        if made:
            info['blocks'] += 1
            info['tris'] += made
    return fv, ff, info


def _zone_layout(x0, y0, x1, y1, count, rnd):
    """把矩形区域切成 count 块地（尽量接近正方，内部界线带随机抖动）。"""
    count = max(1, int(count))
    W = max(x1 - x0, 1e-9)
    H = max(y1 - y0, 1e-9)
    best = None
    for cols in range(1, count + 1):
        rows = int(math.ceil(count / float(cols)))
        waste = cols * rows - count
        cw, ch = W / cols, H / rows
        pen = abs(math.log((cw / ch) / 1.0)) if cw > 0 and ch > 0 else 9.0
        score = waste * 1.0 + pen * 2.0
        if best is None or score < best[0]:
            best = (score, cols, rows)
    _, cols, rows = best
    jx = sorted(rnd.uniform(-0.12, 0.12) * (W / cols) for _ in range(cols - 1))
    jy = sorted(rnd.uniform(-0.12, 0.12) * (H / rows) for _ in range(rows - 1))
    xs = [x0] + [x0 + W * (c + 1) / cols + jx[c] for c in range(cols - 1)] + [x1]
    ys = [y0] + [y0 + H * (r + 1) / rows + jy[r] for r in range(rows - 1)] + [y1]

    def lerp_row(u):
        f = u * cols
        i0 = min(int(f), cols - 1)
        t = f - i0
        return xs[i0] * (1 - t) + xs[i0 + 1] * t

    zones = []
    for r in range(rows):
        n = cols if r < rows - 1 else count - (rows - 1) * cols
        if n <= 0:
            continue
        for c in range(n):
            zones.append((lerp_row(c / float(n)), ys[r], lerp_row((c + 1) / float(n)), ys[r + 1]))
    return zones


def plot_rects(polys, count=3, gap=2.0, seed=0, min_side=1.0):
    """切地块并收缩到街区内部。返回 [(cx, cy, w, d), ...]（w/d 已扣掉 gap）。"""
    rnd = random.Random(seed)
    out = []
    for poly in polys:
        xs = [p[0] for p in poly]
        ys = [p[1] for p in poly]
        for (zx0, zy0, zx1, zy1) in _zone_layout(min(xs), min(ys), max(xs), max(ys), count, rnd):
            cxc, cyc = (zx0 + zx1) * 0.5, (zy0 + zy1) * 0.5
            bw = max((zx1 - zx0) - gap, min_side)
            bh = max((zy1 - zy0) - gap, min_side)
            k = 1.0
            ok = False
            for _ in range(28):
                w2, h2 = bw * k * 0.5, bh * k * 0.5
                if all(_inside(poly, q) for q in
                       ((cxc - w2, cyc - h2), (cxc + w2, cyc - h2),
                        (cxc + w2, cyc + h2), (cxc - w2, cyc + h2),
                        (cxc, cyc), (cxc - w2, cyc), (cxc + w2, cyc))):
                    ok = True
                    break
                k *= 0.86
            if ok:
                out.append((cxc, cyc, bw * k, bh * k))
    return out


def random_buildings(polys, z, count=3, height_min=8.0, height_max=30.0,
                     height_mode='RANGE', height_pct=0.15, _ignored=(),
                     gap=2.0, seed=0, min_side=1.0):
    """每块地放一个长方体（尺寸 = 地块，高度随机）。返回 (bv, bf, info)。"""
    rnd = random.Random(seed + 7777)
    bv = []
    bf = []
    info = {'buildings': 0}
    for (cx, cy, w, d) in plot_rects(polys, count, gap, seed, min_side):
        h = rnd.uniform(height_min, height_max)
        bx0, bx1 = cx - w / 2, cx + w / 2
        by0, by1 = cy - d / 2, cy + d / 2
        i0 = len(bv); bv.append((bx0, by0, z))
        i1 = len(bv); bv.append((bx1, by0, z))
        i2 = len(bv); bv.append((bx1, by1, z))
        i3 = len(bv); bv.append((bx0, by1, z))
        i4 = len(bv); bv.append((bx0, by0, z + h))
        i5 = len(bv); bv.append((bx1, by0, z + h))
        i6 = len(bv); bv.append((bx1, by1, z + h))
        i7 = len(bv); bv.append((bx0, by1, z + h))
        bf.append([i3, i2, i1, i0])
        bf.append([i4, i5, i6, i7])
        bf.append([i0, i1, i5, i4])
        bf.append([i1, i2, i6, i5])
        bf.append([i2, i3, i7, i6])
        bf.append([i3, i0, i4, i7])
        info['buildings'] += 1
    return bv, bf, info



BUILDING_TAG = "rb_building"


def load_assets(blend_path, coll_name):
    """拿到资产对象列表。

    优先用当前文件里同名的集合；没有就从 .blend 库 link 进来。
    返回 (对象列表, 错误信息)
    """
    import bpy
    coll = bpy.data.collections.get(coll_name)
    if coll is not None:
        objs = [o for o in coll.objects if o.type == 'MESH']
        if objs:
            return objs, ""
    if not blend_path:
        return [], "没填资产 .blend 路径，且当前文件里也没有叫 %s 的集合" % coll_name
    if not os.path.exists(blend_path):
        return [], "资产文件不存在：%s" % blend_path
    try:
        with bpy.data.libraries.load(blend_path, link=True) as (src, dst):
            names = list(src.collections or [])
            pick = coll_name if coll_name in names else next(
                (n for n in names if n.lower() == coll_name.lower()), None)
            if pick is None:
                pick = next((n for n in names if coll_name.lower() in n.lower()), None)
            if pick is None:
                return [], "库里没有集合 %s；库里有：%s" % (coll_name, names)
            dst.collections = [pick]
            coll_name = pick
        coll = bpy.data.collections.get(coll_name)
        if coll is None and dst.collections:
            coll = dst.collections[0]
    except Exception as e:
        return [], "读资产库失败：%s" % e
    if coll is None:
        return [], "link 之后找不到集合 %s" % coll_name
    return [o for o in coll.objects if o.type == 'MESH'], ""


def asset_bbox(obj):
    """资产「本地网格」的轴对齐包围盒（不含物体自身变换）→ (x0,y0,z0,x1,y1,z1)。"""
    me = obj.data
    if len(me.vertices) == 0:
        return (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    xs = [v.co.x for v in me.vertices]
    ys = [v.co.y for v in me.vertices]
    zs = [v.co.z for v in me.vertices]
    return (min(xs), min(ys), min(zs), max(xs), max(ys), max(zs))


def asset_world_bbox(obj):
    """资产「世界空间」的轴对齐包围盒（把物体自身 loc/rot/scale 也算进去）。
    用 bound_box 的 8 个角点算，很快；轴对齐的资产结果就是精确值。"""
    bb = obj.bound_box
    if bb is None or len(bb) == 0:
        return None
    mw = obj.matrix_world
    pts = [mw @ __import__("mathutils").Vector(c) for c in bb]
    xs = [p.x for p in pts]
    ys = [p.y for p in pts]
    zs = [p.z for p in pts]
    return (min(xs), min(ys), min(zs), max(xs), max(ys), max(zs))


def _bbox_under(bbox, scale, rot_deg):
    """把包围盒 8 个角按 scale + 绕 Z 旋转后，取世界范围。"""
    x0, y0, z0, x1, y1, z1 = bbox
    ca = math.cos(math.radians(rot_deg))
    sa = math.sin(math.radians(rot_deg))
    xs, ys, zs = [], [], []
    for i in range(8):
        x = x1 if (i & 1) else x0
        y = y1 if (i & 2) else y0
        z = z1 if (i & 4) else z0
        X = scale[0] * x
        Y = scale[1] * y
        xs.append(X * ca - Y * sa)
        ys.append(X * sa + Y * ca)
        zs.append(scale[2] * z)
    return min(xs), max(xs), min(ys), max(ys), min(zs), max(zs)


def place_asset_buildings(target_coll, polys, z, blend_path, coll_name,
                          count=3, height_min=8.0, height_max=30.0, gap=2.0,
                          height_mode='RANGE', height_pct=0.15,
                          seed=0, dirs=(0.0, 90.0, 180.0, 270.0),
                          name_prefix="RB_BLD_"):
    """把资产按地块摆上去（链接副本：共享网格 + 材质）。

    适配规则（方案 A）：包围盒 XY 各自缩放到地块矩形、Z 缩放到随机高度，
    包围盒中心对地块中心、底面贴地面。
    返回 (信息 dict, 错误信息)
    """
    import bpy
    from mathutils import Euler
    from mathutils import Matrix, Vector
    assets, err = load_assets(blend_path, coll_name)
    if err or not assets:
        return {'buildings': 0}, err or "资产集合里没有网格对象"
    bboxes = {}
    for o in assets:
        bb = asset_world_bbox(o)
        if bb is None:
            bb = asset_bbox(o)
        bboxes[o.name] = bb
    rnd = random.Random(seed + 20240)
    info = {'buildings': 0, 'dirs': {}, 'assets': len(assets), 'used': {}}
    bag = []
    def pick():
        nonlocal bag
        if not bag:
            bag = list(assets)
            rnd.shuffle(bag)
        return bag.pop()
    for (cx, cy, w, d) in plot_rects(polys, count, gap, seed):
        obj = pick()
        bb = bboxes[obj.name]
        bx0, by0, bz0, bx1, by1, bz1 = bb
        if bx1 <= bx0 or by1 <= by0 or bz1 <= bz0:
            continue
        rot = rnd.choice(dirs) if dirs else 0.0
        ux0, ux1, uy0, uy1, uz0, uz1 = _bbox_under(bb, (1.0, 1.0, 1.0), rot)
        sx = w / max(ux1 - ux0, 1e-9)
        sy = d / max(uy1 - uy0, 1e-9)
        h0_asset = bz1 - bz0
        if height_mode == 'PERCENT':
            s_xy = math.sqrt(max(sx * sy, 1e-12))
            h = h0_asset * s_xy * (1.0 + rnd.uniform(-height_pct, height_pct))
            h = max(h, 0.5)
        else:
            h = rnd.uniform(height_min, height_max)
            h = min(h, h0_asset)
        sz = h / max(uz1 - uz0, 1e-9)
        ax0, ax1, ay0, ay1, az0, az1 = _bbox_under(bb, (sx, sy, sz), rot)
        new = obj.copy()
        new.data = obj.data
        new.name = name_prefix + obj.name
        new[BUILDING_TAG] = 1
        M = (Matrix.Translation(Vector((cx - (ax0 + ax1) * 0.5,
                                        cy - (ay0 + ay1) * 0.5,
                                        z - az0)))
             @ Matrix.Rotation(math.radians(rot), 4, 'Z')
             @ Matrix.Diagonal((sx, sy, sz, 1.0)).to_4x4()
             @ obj.matrix_world)
        new.matrix_world = M
        target_coll.objects.link(new)
        info['buildings'] += 1
        info['dirs'][rot] = info['dirs'].get(rot, 0) + 1
        info['used'][obj.name] = info['used'].get(obj.name, 0) + 1
    return info, ""


def clear_buildings(colls=None):
    """清掉上次生成的建筑对象（带 BUILDING_TAG 的）。"""
    import bpy
    n = 0
    for o in list(bpy.data.objects):
        if o.get(BUILDING_TAG) or o.get("rb_crosswalk") or o.get("rb_edgeline"):
            bpy.data.objects.remove(o, do_unlink=True)
            n += 1
    return n


def clear_roads():
    """清掉上次生成的路面对象（避免重新生成时一层层叠起来）。"""
    import bpy
    n = 0
    for o in list(bpy.data.objects):
        if o.get("rb_road"):
            bpy.data.objects.remove(o, do_unlink=True)
            n += 1
    return n