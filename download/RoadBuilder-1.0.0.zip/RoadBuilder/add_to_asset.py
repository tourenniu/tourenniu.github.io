"""往资产文件里"并入"建筑资产（由插件在后台 Blender 里调用，不切用户场景）。

用法: blender --background 资产.blend --python add_to_asset.py -- 临时.blend 集合名
"""
import sys
import bpy

argv = sys.argv[sys.argv.index("--") + 1:]
tmpblend, collname = argv[0], argv[1]


def log(*a):
    print("[RB_ASSET]", *a, flush=True)


with bpy.data.libraries.load(tmpblend) as (src, dst):
    dst.objects = list(src.objects or [])
objs = [o for o in (dst.objects or []) if o is not None]
log("取到 %d 个物体：%s" % (len(objs), [o.name for o in objs]))

coll = bpy.data.collections.get(collname)
if coll is None:
    coll = bpy.data.collections.new(collname)
    bpy.context.scene.collection.children.link(coll)
    log("新建集合 %s" % collname)
else:
    log("已有集合 %s（原 %d 个物体）" % (collname, len(coll.objects)))

have = [x.name for x in coll.objects]
for o in objs:
    if o.name not in have:
        coll.objects.link(o)
        for c in list(o.users_collection):
            if c is not coll:
                c.objects.unlink(o)

log("并入后 %s 共 %d 个：%s" % (collname, len(coll.objects),
                             sorted(x.name for x in coll.objects)))
bpy.ops.wm.save_mainfile()
log("资产已保存 OK")