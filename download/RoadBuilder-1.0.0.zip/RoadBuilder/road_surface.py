
import math


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1])


def _add(a, b):
    return (a[0] + b[0], a[1] + b[1])


def _mul(a, s):
    return (a[0] * s, a[1] * s)


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def _cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def _perp_ccw(a):
    return (-a[1], a[0])


def _norm(a):
    l = math.hypot(a[0], a[1])
    if l < 1e-12:
        return (0.0, 0.0)
    return (a[0] / l, a[1] / l)


def _angle_ccw(a, b):
    ang = math.atan2(_cross(a, b), _dot(a, b))
    return ang if ang >= 0.0 else ang + 2.0 * math.pi


def _line_isect(p, d, q, e):
    den = _cross(d, e)
    if abs(den) < 1e-12:
        return None
    dpq = _sub(q, p)
    return _cross(dpq, e) / den, _cross(dpq, d) / den


def _poly_area(pts):
    s = 0.0
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        s += x1 * y2 - x2 * y1
    return s * 0.5


def _point_in_tri(p, a, b, c, eps=1e-9):
    d1 = _cross(_sub(b, a), _sub(p, a))
    d2 = _cross(_sub(c, b), _sub(p, b))
    d3 = _cross(_sub(a, c), _sub(p, c))
    return ((d1 >= -eps and d2 >= -eps and d3 >= -eps) or
            (d1 <= eps and d2 <= eps and d3 <= eps))


def _arc_center(ui, ni, wi, uj, nj, wj, r):
    c = _dot(ni, nj)
    s = _dot(ui, nj)
    if abs(s) < 1e-12:
        s = 1e-12
    x = (-(wj * 0.5 + r) - (wi * 0.5 + r) * c) / s
    return _add(_mul(ui, x), _mul(ni, wi * 0.5 + r))


def _tangent_pt(o, u, n, off):
    t = _dot(o, u)
    return (u[0] * t + n[0] * off, u[1] * t + n[1] * off)


def _fit_radius(ui, ni, wi, uj, nj, wj, r, max_i, max_j):
    for _ in range(10):
        o = _arc_center(ui, ni, wi, uj, nj, wj, r)
        di = _dot(_tangent_pt(o, ui, ni, wi * 0.5), ui)
        dj = _dot(_tangent_pt(o, uj, nj, -wj * 0.5), uj)
        over = 1.0
        if max_i > 0.0 and abs(di) > max_i:
            over = min(over, max_i / abs(di))
        if max_j > 0.0 and abs(dj) > max_j:
            over = min(over, max_j / abs(dj))
        if over >= 1.0 - 1e-9:
            return r
        r *= over
    return r


def _arc_pts(o, r, t_from, t_to, segments):
    a0 = math.atan2(t_from[1] - o[1], t_from[0] - o[0])
    a1 = math.atan2(t_to[1] - o[1], t_to[0] - o[0])
    da = a1 - a0
    while da <= -math.pi:
        da += 2.0 * math.pi
    while da > math.pi:
        da -= 2.0 * math.pi
    n = max(1, int(segments))
    pts = []
    for k in range(n + 1):
        a = a0 + da * (k / float(n))
        pts.append((o[0] + abs(r) * math.cos(a), o[1] + abs(r) * math.sin(a)))
    pts[0] = t_from
    pts[-1] = t_to
    return pts


def _corner_join(ui, wi, uj, wj, radius_ratio, max_i, max_j, arc_segments):
    ni = _perp_ccw(ui)
    nj = _perp_ccw(uj)
    theta = _angle_ccw(ui, uj)
    foot_i = _mul(ni, wi * 0.5)
    foot_j = _mul(nj, -wj * 0.5)

    if abs(theta - math.pi) <= 1e-6:
        return [foot_i, foot_j]

    if theta > math.pi:
        hit = _line_isect(foot_i, ui, foot_j, uj)
        if hit is None:
            return [foot_i, foot_j]
        return [_add(foot_i, _mul(ui, hit[0]))]

    r = _fit_radius(ui, ni, wi, uj, nj, wj, radius_ratio * min(wi, wj), max_i, max_j)
    if abs(r) <= 1e-9:
        hit = _line_isect(foot_i, ui, foot_j, uj)
        if hit is None:
            return [foot_i, foot_j]
        return [_add(foot_i, _mul(ui, hit[0]))]
    o = _arc_center(ui, ni, wi, uj, nj, wj, r)
    ti = _tangent_pt(o, ui, ni, wi * 0.5)
    tj = _tangent_pt(o, uj, nj, -wj * 0.5)
    return _arc_pts(o, r, ti, tj, arc_segments)


def _deg2_ring(ui, wi, uj, wj, radius_ratio, max_i, max_j, segments):
    theta = _angle_ccw(ui, uj)
    if not (1e-6 < theta < math.pi - 1e-6):
        return None
    ni = _perp_ccw(ui)
    nj = _perp_ccw(uj)
    tan_h = math.tan(theta * 0.5)
    if tan_h < 1e-9:
        return None
    w = min(wi, wj)
    r_in = radius_ratio * w
    t = (w * 0.5 + r_in) / tan_h
    lim = min([x for x in (max_i, max_j) if x > 0] or [1e9])
    if t > lim:
        r_in = max(0.0, lim * tan_h - w * 0.5)
    if r_in <= 1e-9:
        return None
    o = _arc_center(ui, ni, wi, uj, nj, wj, r_in)
    ti = _tangent_pt(o, ui, ni, wi * 0.5)
    tj = _tangent_pt(o, uj, nj, -wj * 0.5)
    r_out = r_in + w
    di = _norm(_sub(ti, o))
    dj = _norm(_sub(tj, o))
    a0 = math.atan2(di[1], di[0])
    a1 = math.atan2(dj[1], dj[0])
    da = a1 - a0
    while da <= -math.pi:
        da += 2.0 * math.pi
    while da > math.pi:
        da -= 2.0 * math.pi
    n = max(2, int(segments))
    inner, outer = [], []
    for k in range(n + 1):
        a = a0 + da * (k / float(n))
        vec = (math.cos(a), math.sin(a))
        inner.append(_add(o, _mul(vec, r_in)))
        outer.append(_add(o, _mul(vec, r_out)))
    inner[0], inner[-1] = ti, tj
    outer[0] = _add(o, _mul(di, r_out))
    outer[-1] = _add(o, _mul(dj, r_out))
    return inner, outer


def _fan(ci, idxs, pts):
    tris = []
    total = 0.0
    for k in range(len(idxs)):
        i1, i2 = idxs[k], idxs[(k + 1) % len(idxs)]
        if i1 == ci or i2 == ci or i1 == i2:
            continue
        a = _poly_area([pts[ci], pts[i1], pts[i2]])
        if a <= 1e-12:
            return [], False
        total += a
        tris.append((ci, i1, i2))
    return tris, True


def _clean_collinear(idxs, pts, eps=1e-9):
    out = list(idxs)
    changed = True
    while changed and len(out) > 3:
        changed = False
        n = len(out)
        for k in range(n):
            a, b, c = pts[out[(k - 1) % n]], pts[out[k]], pts[out[(k + 1) % n]]
            if abs(_cross(_sub(b, a), _sub(c, b))) <= eps:
                out.pop(k)
                changed = True
                break
    return out


def _ear_clip(idxs, pts):
    idxs = _clean_collinear(idxs, pts)
    order = list(range(len(idxs)))
    tris = []
    guard = 0
    while len(order) > 3 and guard < 20000:
        guard += 1
        m = len(order)
        clipped = False
        for k in range(m):
            i0, i1, i2 = order[(k - 1) % m], order[k], order[(k + 1) % m]
            p0, p1, p2 = pts[idxs[i0]], pts[idxs[i1]], pts[idxs[i2]]
            if _poly_area([p0, p1, p2]) <= 1e-10:
                continue
            hit = False
            for j in order:
                if j in (i0, i1, i2):
                    continue
                if _point_in_tri(pts[idxs[j]], p0, p1, p2, eps=-1e-10):
                    hit = True
                    break
            if hit:
                continue
            tris.append((idxs[i0], idxs[i1], idxs[i2]))
            order.pop(k)
            clipped = True
            break
        if not clipped:
            break
    if len(order) == 3:
        tris.append((idxs[order[0]], idxs[order[1]], idxs[order[2]]))
    return tris


def build_road_surface(points, edges, width, radius_ratio=0.5, arc_segments=8, z=None):
    nv = len(points)
    adj = [[] for _ in range(nv)]
    for (a, b) in edges:
        if a == b:
            continue
        adj[a].append(b)
        adj[b].append(a)

    half = width * 0.5

    def arm_dir(v, n):
        d = _sub(points[n], points[v])
        return _norm(d), math.hypot(d[0], d[1])

    side_pt = {}
    side_z = {}
    corner_loops = {}
    rings = {}
    xwalk_inters = []
    xwalk_slot_ids = []
    xwalk_inters_ids = []
    xwalk_slots = []

    for v in range(nv):
        nb = adj[v]
        deg = len(nb)
        if deg == 0:
            continue
        c = points[v]
        zv = z[v] if z else None

        if deg == 1:
            u, _ = arm_dir(v, nb[0])
            n = _perp_ccw(u)
            side_pt[(v, nb[0])] = (_add(c, _mul(n, half)),
                                   _add(c, _mul(n, -half)))
            side_z[(v, nb[0])] = zv
            continue

        arms = []
        for m_i in nb:
            u, ln = arm_dir(v, m_i)
            arms.append((math.atan2(u[1], u[0]), m_i, u, ln))
        arms.sort(key=lambda t: t[0])
        m = len(arms)

        if deg == 2:
            theta0 = _angle_ccw(arms[0][2], arms[1][2])
            if abs(theta0 - math.pi) <= 1e-6:
                for k in range(2):
                    n = _perp_ccw(arms[k][2])
                    side_pt[(v, arms[k][1])] = (_add(c, _mul(n, half)),
                                                _add(c, _mul(n, -half)))
                    side_z[(v, arms[k][1])] = zv
                continue
            ik = 0 if theta0 < math.pi else 1
            nk = (ik + 1) % 2
            res = _deg2_ring(arms[ik][2], width, arms[nk][2], width,
                             radius_ratio,
                             arms[ik][3] * 0.45, arms[nk][3] * 0.45,
                             arc_segments)
            if res is not None:
                inner, outer = res
                rings[v] = (inner, outer)
                side_pt[(v, arms[ik][1])] = (_add(inner[0], c), _add(outer[0], c))
                side_pt[(v, arms[nk][1])] = (_add(outer[-1], c), _add(inner[-1], c))
                side_z[(v, arms[ik][1])] = zv
                side_z[(v, arms[nk][1])] = zv
                continue

        joins = []
        _ds_x = []
        for k in range(m):
            _, _, ui, li = arms[k]
            _, _, uj, lj = arms[(k + 1) % m]
            joins.append(_corner_join(ui, width, uj, width, radius_ratio,
                                      li * 0.45, lj * 0.45,
                                      arc_segments))
        for k in range(m):
            _, n_k, _, _ = arms[k]
            side_pt[(v, n_k)] = (_add(joins[k][0], c),
                                 _add(joins[(k - 1) % m][-1], c))
            side_z[(v, n_k)] = zv
            u_k = arms[k][2]
            th_a = _angle_ccw(arms[(k - 1) % m][2], u_k)
            th_b = _angle_ccw(u_k, arms[(k + 1) % m][2])
            r_x = radius_ratio * width
            d_a = (width * 0.5 + r_x) / math.tan(th_a * 0.5) if th_a < math.pi - 1e-9 else 0.0
            d_b = (width * 0.5 + r_x) / math.tan(th_b * 0.5) if th_b < math.pi - 1e-9 else 0.0
            d_x = min(max(max(d_a, d_b), 0.0), 0.45 * arms[k][3])
            xwalk_slots.append((_add(c, _mul(u_k, d_x)), u_k, width, zv))
            xwalk_slot_ids.append((v, arms[k][1]))
            _ds_x.append(d_x)

        xwalk_inters.append((c[0], c[1], max(_ds_x) if _ds_x else 0.0))
        xwalk_inters_ids.append(v)
        loop = []
        for k in range(m):
            _, n_k, _, _ = arms[k]
            p_ccw, p_cw = side_pt[(v, n_k)]
            loop.append(p_cw)
            loop.append(p_ccw)
            loop.extend([_add(p, c) for p in joins[k][1:-1]])
        clean = []
        for p in loop:
            if not clean or math.hypot(p[0] - clean[-1][0], p[1] - clean[-1][1]) > 1e-7:
                clean.append(p)
        if len(clean) > 2 and math.hypot(clean[0][0] - clean[-1][0],
                                        clean[0][1] - clean[-1][1]) <= 1e-7:
            clean.pop()
        corner_loops[v] = clean

    verts = []
    vidx = {}

    def vid(p, zv):
        key = (round(p[0], 6), round(p[1], 6))
        i = vidx.get(key)
        if i is None:
            i = len(verts)
            vidx[key] = i
            verts.append(p if zv is None else (p[0], p[1], zv))
        return i

    faces = []
    stats = {'degenerate': 0, 'strips': 0, 'patches': 0, 'patches_clipped': 0,
             'ring_quads': 0}

    for (a, b) in edges:
        if a == b or (a, b) not in side_pt or (b, a) not in side_pt:
            continue
        a_ccw, a_cw = side_pt[(a, b)]
        b_ccw, b_cw = side_pt[(b, a)]
        za = side_z[(a, b)]
        zb = side_z[(b, a)]
        quad = [vid(a_ccw, za), vid(a_cw, za), vid(b_ccw, zb), vid(b_cw, zb)]
        area = _poly_area([verts[i][:2] for i in quad])
        if len(set(quad)) < 3 or abs(area) <= 1e-9:
            stats['degenerate'] += 1
            continue
        if area < 0:
            quad = quad[::-1]
        faces.append(quad)
        stats['strips'] += 1

    for v, (inner, outer) in rings.items():
        c = points[v]
        zv = z[v] if z else None
        for k in range(len(inner) - 1):
            quad = [vid(_add(inner[k], c), zv), vid(_add(inner[k + 1], c), zv),
                    vid(_add(outer[k + 1], c), zv), vid(_add(outer[k], c), zv)]
            area = _poly_area([verts[i][:2] for i in quad])
            if len(set(quad)) < 3 or abs(area) <= 1e-9:
                stats['degenerate'] += 1
                continue
            if area < 0:
                quad = quad[::-1]
            faces.append(quad)
            stats['ring_quads'] += 1

    for v, loop in corner_loops.items():
        if len(loop) < 3:
            continue
        a = _poly_area(loop)
        if abs(a) <= 1e-9:
            stats['degenerate'] += 1
            continue
        if a < 0:
            loop = list(reversed(loop))
            a = -a
        c = points[v]
        zv = z[v] if z else None
        ci = vid(c, zv)
        uniq = []
        for p in loop:
            i = vid(p, zv)
            if not uniq or uniq[-1] != i:
                uniq.append(i)
        if len(uniq) > 1 and uniq[0] == uniq[-1]:
            uniq.pop()
        if len(uniq) < 3:
            continue
        pts2 = [p[:2] for p in verts]
        tris, ok = _fan(ci, uniq, pts2)
        if not ok or abs(sum(_poly_area([pts2[t[0]], pts2[t[1]], pts2[t[2]]])
                             for t in tris) - a) > max(1e-6, 1e-6 * a):
            tris = _ear_clip(uniq, pts2)
            if tris:
                stats['patches_clipped'] += 1
        made = 0
        for (i0, i1, i2) in tris:
            if i0 == i1 or i1 == i2 or i0 == i2:
                continue
            ar = _poly_area([pts2[i0], pts2[i1], pts2[i2]])
            if abs(ar) <= 1e-12:
                stats['degenerate'] += 1
                continue
            faces.append([i0, i1, i2] if ar > 0 else [i0, i2, i1])
            made += 1
        if made:
            stats['patches'] += 1

    info = {'verts': len(verts), 'faces': len(faces)}
    info.update(stats)
    info['crosswalk_slots'] = xwalk_slots
    info['intersections'] = xwalk_inters
    info['slot_ids'] = xwalk_slot_ids
    info['intersection_ids'] = xwalk_inters_ids
    return verts, faces, info


def poly_area(pts):
    return _poly_area(pts)