import bpy
from bpy.props import PointerProperty

from .properties import RoadBuilderSettings
from .operators import (RefreshLineMats, StartUseRoadBuilder, ReloadAssetMats, SaveDefaultMat,
                         AddBuildingAsset,
                         BuildRoadOperator, BuildRoadSurfaceOperator)
from .panels import (RoadBuilderPanel, RBP_PT_intersection, RBP_PT_marking,
                     RBP_PT_tlight, RBP_PT_traffic, RBP_PT_wheel, RBP_PT_advanced)
from .traffic import ExportTrafficOperator
from .trafficsim import BuildTrafficOperator
from . import updater

bl_info = {
    "name": "Road Builder",
    "author": "",
    "blender": (4, 0, 0),
    "version": (1, 0, 0),
    "description": "道路生成：网格边 → 道路（几何节点 / 补片法交叉口圆角）",
    "category": "Add Mesh",
}

class RoadBuilderPrefs(bpy.types.AddonPreferences):
    bl_idname = __package__

    started: bpy.props.BoolProperty(name="已开始使用", default=False)
    line_white: bpy.props.StringProperty(name="默认白线材质", default="Road_Builder_Whiteline")
    line_center: bpy.props.StringProperty(name="默认黄线材质", default="Road_Builder_Yellowline")
    line_lane: bpy.props.StringProperty(name="默认虚线材质", default="Road_Builder_Whiteline")
    road_mat: bpy.props.StringProperty(name="默认路面材质", default="Road_Builder_Aspha01")
    side_mat: bpy.props.StringProperty(name="默认人行道材质", default="Road_Builder_Sidewalk")

    def draw(self, context):
        c = self.layout.column()
        c.label(text="点击 3D 视图右侧「道路生成」里的【开始使用】即可初始化", icon='INFO')
        c.prop(self, "started")
        c.prop(self, "line_white")
        c.prop(self, "line_center")
        c.prop(self, "line_lane")
        c.prop(self, "road_mat")
        c.prop(self, "side_mat")


_classes = (
    RoadBuilderPrefs,
    RoadBuilderSettings,
    BuildRoadOperator,
    BuildRoadSurfaceOperator,
    RefreshLineMats,
    AddBuildingAsset,
    StartUseRoadBuilder,
    ReloadAssetMats,
    SaveDefaultMat,
    RoadBuilderPanel,
    RBP_PT_intersection,
    RBP_PT_marking,
    RBP_PT_tlight,
    RBP_PT_traffic,
    RBP_PT_wheel,
    RBP_PT_advanced,
    ExportTrafficOperator,
    BuildTrafficOperator,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.road_builder = PointerProperty(type=RoadBuilderSettings)
    updater.register()


def unregister():
    updater.unregister()
    del bpy.types.Scene.road_builder
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
