"""
RoadBuilder 更新检查
====================
后台请求 https://eletriceye.com/version.json，与本地版本比较；
有新版本时弹窗提示，点 OK 打开下载页。

设计原则
--------
- 不阻塞界面：网络请求放后台线程
- 静默失败：断网 / 服务器不可用 / 返回格式错误都不弹报错
- 每天最多检查一次
- 手动检查：bpy.ops.rb.check_update()
"""

import json
import threading
import time
import urllib.request
import webbrowser

import bpy

UPDATE_URL = "https://eletriceye.com/version.json"
CHECK_INTERVAL_SECONDS = 24 * 60 * 60

_state = {
    "info": None,
    "error": None,
    "checking": False,
    "last_check": 0.0,
}


def local_version():
    """读取 bl_info 里的版本号，如 '1.0.0'"""
    from . import bl_info
    v = bl_info.get("version", (0, 0, 0))
    return ".".join(str(x) for x in v)


def _parse_version(text):
    parts = []
    for piece in str(text).strip().split("."):
        try:
            parts.append(int(piece))
        except (TypeError, ValueError):
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def is_newer(remote, local):
    return _parse_version(remote) > _parse_version(local)


def _fetch_manifest(timeout=8):
    url = "%s?t=%d" % (UPDATE_URL, int(time.time()))
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "RoadBuilder-Updater/1.0"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _worker():
    try:
        _state["info"] = _fetch_manifest()
        _state["error"] = None
    except Exception as exc:
        _state["error"] = str(exc)
    finally:
        _state["checking"] = False
        _state["last_check"] = time.time()
        try:
            bpy.app.timers.register(_after_check, first_interval=0.2)
        except Exception:
            pass


def _set_status(text):
    """把状态写到场景设置里（面板显示用）。只在主线程调用 ✓"""
    try:
        st = bpy.context.scene.road_builder
        st.rb_update_status = str(text)
    except Exception:
        pass


def _after_check():
    """回到主线程后再操作 UI：无论成功失败都写一行状态 ✓"""
    stamp = time.strftime("%m-%d %H:%M")
    info = _state.get("info")
    err = _state.get("error")
    if info:
        remote = str(info.get("version", "?"))
        if is_newer(remote, local_version()):
            _set_status("发现新版本 %s（当前 %s）· 点上面的按钮查看 · %s"
                        % (remote, local_version(), stamp))
            try:
                bpy.ops.rb.update_notice("INVOKE_DEFAULT")
            except Exception:
                pass
        else:
            _set_status("已是最新版 %s · %s 检查" % (local_version(), stamp))
    elif err:
        _set_status("检查失败（网络不通或服务器无响应）· %s" % stamp)
    else:
        _set_status("检查没有拿到结果 · %s" % stamp)
    return None


def check_async():
    if _state["checking"]:
        _set_status("正在检查…（已有一个检查在进行）")
        return
    _state["checking"] = True
    _set_status("正在检查…（后台请求 eletriceye.com/version.json）")
    threading.Thread(target=_worker, daemon=True).start()


def check_on_startup():
    if time.time() - _state["last_check"] < CHECK_INTERVAL_SECONDS:
        return None
    check_async()
    return None


class RB_OT_update_notice(bpy.types.Operator):
    """发现新版本"""
    bl_idname = "rb.update_notice"
    bl_label = "RoadBuilder 有新版本"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=480)

    def draw(self, context):
        info = _state.get("info") or {}
        layout = self.layout

        row = layout.row()
        row.label(text="本地版本：" + local_version())
        row.label(text="最新版本：" + str(info.get("version", "?")), icon="INFO")

        notes = info.get("notes") or ""
        if notes:
            layout.separator()
            box = layout.box()
            box.label(text="更新内容", icon="TEXT")
            for line in notes.split("\n"):
                box.label(text=line)

        layout.separator()
        layout.label(text="日期：" + str(info.get("date", "")), icon="TIME")
        layout.label(text="点 OK 打开下载页，按 Esc 稍后再说", icon="URL")

    def execute(self, context):
        info = _state.get("info") or {}
        url = info.get("download") or "https://eletriceye.com/"
        try:
            webbrowser.open(url)
        except Exception:
            pass
        return {"FINISHED"}


class RB_OT_check_update(bpy.types.Operator):
    """立即检查更新"""
    bl_idname = "rb.check_update"
    bl_label = "检查更新"

    def execute(self, context):
        check_async()
        self.report({"INFO"}, "正在检查更新，稍后会提示结果…")
        return {"FINISHED"}


_classes = (
    RB_OT_update_notice,
    RB_OT_check_update,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    if not bpy.app.timers.is_registered(check_on_startup):
        bpy.app.timers.register(check_on_startup, first_interval=3.0)


def unregister():
    if bpy.app.timers.is_registered(check_on_startup):
        bpy.app.timers.unregister(check_on_startup)
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)