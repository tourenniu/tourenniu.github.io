"""斑马线：在「度数 >= 3 的路口」的每条臂上，贴着切线（路被截断的那条横截面）外侧放一条斑马线。

资产 Road_Builder_Crosswalk 的本地轴向约定（实测）：
    X 方向长 4.0  → 沿路方向（斑马线的进深）
    Y 方向长 6.0  → 横过马路（5 条白条沿这个方向排，要缩放到路宽）
所以摆放时：local X → 臂方向 u（背离路口），local Y → ẑ × u（横跨路面），Z 朝上。
"""

import math
import os

from .blocks import asset_bbox


def load_object(blend_path, name):
    """从库里取一个对象（link）。返回 (对象, 错误)。"""
    import bpy
    o = bpy.data.objects.get(name)
    if o is not None:
        return o, ""
    if not blend_path:
        return None, "没填资产库路径"
    if not os.path.exists(blend_path):
        return None, "资产文件不存在：%s" % blend_path
    try:
        with bpy.data.libraries.load(blend_path, link=True) as (src, dst):
            if name not in (src.objects or []):
                return None, "库里没有对象 %s（库里有的：%s）" % (name, list(src.objects)[:12])
            dst.objects = [name]
        o = bpy.data.objects.get(name)
        if o is None and dst.objects:
            o = dst.objects[0]
    except Exception as e:
        return None, "读资产库失败：%s" % e
    return (o, "") if o is not None else (None, "link 之后找不到对象 %s" % name)


def _aabb_under(bb, mat):
    """把本地包围盒 bb=(x0,y0,z0,x1,y1,z1) 的 8 个角点按矩阵 mat 变换后，取世界范围。"""
    from mathutils import Vector
    x0, y0, z0, x1, y1, z1 = bb
    pts = [mat @ Vector((x1 if i & 1 else x0, y1 if i & 2 else y0, z1 if i & 4 else z0))
           for i in range(8)]
    xs = [p.x for p in pts]
    ys = [p.y for p in pts]
    zs = [p.z for p in pts]
    return (min(xs), max(xs), min(ys), max(ys), min(zs), max(zs))


def place_crosswalks(target_coll, slots, blend_path, obj_name,
                     gap=0.3, scale=1.0, lift=0.01, name_prefix="RB_CW_"):
    """slots = [(切线点, 臂方向, 路宽, z), ...]：每个路口每条臂一组（切点两点 + 臂方向 + 高度）。

    摆放：中心 = 切线点沿臂方向外移 (gap + 进深/2)；
          横向缩放到「这条路的实际路宽」；底面抬 lift 避免与路面 z-fighting。
    返回 (info, 错误)
    """
    import bpy
    from mathutils import Matrix, Vector
    obj, err = load_object(blend_path, obj_name)
    if err or obj is None:
        return {'crosswalks': 0}, err or "没取到斑马线资产"
    bb = asset_bbox(obj)
    x0, y0, z0, x1, y1, z1 = bb
    across0 = max(y1 - y0, 1e-9)
    depth0 = max(x1 - x0, 1e-9)
    base = obj.matrix_world.copy()
    info = {'crosswalks': 0, 'slots': len(slots)}
    for (pt, u, road_w, z) in slots:
        cx, cy = pt[0], pt[1]
        if road_w < 1e-6:
            continue
        s = (road_w / across0) * scale
        depth = depth0 * s
        ax, ay = -u[1], u[0]
        R = Matrix(((u[0], ax, 0.0), (u[1], ay, 0.0), (0.0, 0.0, 1.0))).to_4x4()
        S = Matrix.Diagonal((s, s, 1.0)).to_4x4()
        M0 = R @ S @ base
        tx = cx + u[0] * (gap + depth * 0.5)
        ty = cy + u[1] * (gap + depth * 0.5)
        bx0, bx1, by0, by1, bz0, bz1 = _aabb_under(bb, M0)
        new = obj.copy()
        new.data = obj.data
        new.name = name_prefix + obj.name
        new["rb_crosswalk"] = 1
        new.matrix_world = Matrix.Translation(Vector((tx - (bx0 + bx1) * 0.5,
                                                      ty - (by0 + by1) * 0.5,
                                                      z + lift - bz0))) @ M0
        target_coll.objects.link(new)
        info['crosswalks'] += 1
    return info, ""