"""交通流数据导出（JSON）——给 UE 侧插件 Road_Builder_Traffic 用。

纯导出：只读现有的 pts / edges / info，不参与任何生成逻辑 → 对现有功能零影响。
坐标系：Blender 用米，UE 用厘米 → 输出前统一乘 100。
"""

import json
import math
import os

import bpy


def _u(dx, dy):
    L = math.hypot(dx, dy)
    return None if L < 1e-9 else (dx / L, dy / L)


def _kind(deg, is_bend):
    if deg >= 3:
        return "intersection"
    if deg == 2:
        return "bend" if is_bend else "through"
    if deg == 1:
        return "deadend"
    return "isolated"


def build_traffic_dict(pts, edges, zs, info, settings, scale=100.0, obj_name=""):
    """把插件已经算出来的东西整理成交通流用的结构。"""
    adj = {}
    for (a, b) in edges:
        adj.setdefault(a, []).append(b)
        adj.setdefault(b, []).append(a)

    def Z(v):
        return (zs[v] if v < len(zs) else 0.0) * scale

    def XY(v):
        return [pts[v][0] * scale, pts[v][1] * scale, Z(v)]

    verts_out = []
    for v in range(len(pts)):
        nb = adj.get(v, [])
        deg = len(nb)
        is_bend = False
        if deg == 2:
            u1 = _u(pts[nb[0]][0] - pts[v][0], pts[nb[0]][1] - pts[v][1])
            u2 = _u(pts[nb[1]][0] - pts[v][0], pts[nb[1]][1] - pts[v][1])
            if u1 and u2:
                is_bend = (u1[0] * u2[0] + u1[1] * u2[1]) < math.cos(math.radians(1.0))
        verts_out.append({"id": v, "pos": XY(v), "degree": deg,
                          "kind": _kind(deg, is_bend), "neighbors": list(nb)})

    edges_out = []
    for i, (a, b) in enumerate(edges):
        L = math.hypot(pts[b][0] - pts[a][0], pts[b][1] - pts[a][1])
        edges_out.append({"id": i, "a": a, "b": b, "length": L * scale})

    edge_id = {}
    for e in edges_out:
        edge_id[(e["a"], e["b"])] = e["id"]
        edge_id[(e["b"], e["a"])] = e["id"]

    inters = info.get('intersections', [])
    iids = info.get('intersection_ids', [])
    slots = info.get('crosswalk_slots', [])
    sids = info.get('slot_ids', [])
    inters_out = []
    for k, it in enumerate(inters):
        x, y, tau = it[-3:]
        vid = iids[k] if k < len(iids) else -1
        arms = []
        for j, s in enumerate(slots):
            pt, u, rw, z = s[:4]
            sid = sids[j] if j < len(sids) else (-1, -1)
            if sid[0] != vid:
                continue
            arms.append({
                "vertex": sid[1],
                "edge": edge_id.get((vid, sid[1]), -1),
                "dir": [u[0], u[1]],
                "stop_line_dist": math.hypot(pt[0] - x, pt[1] - y) * scale,
                "stop_line_pos": [pt[0] * scale, pt[1] * scale, z * scale],
                "road_width": rw * scale,
            })
        inters_out.append({
            "vertex": vid,
            "pos": [x * scale, y * scale, Z(vid) if 0 <= vid < len(pts) else 0.0],
            "core_radius": tau * scale,
            "arms": arms,
        })

    bends_out = []
    for item in info.get('bends', []):
        v, O, Rm, ui, uj, ni, nj, vx, vy, z = item
        bends_out.append({
            "vertex": v,
            "pos": [vx * scale, vy * scale, z * scale],
            "center": [O[0] * scale, O[1] * scale, z * scale],
            "radius_mid": Rm * scale,
            "arm_in": [ui[0], ui[1]],
            "arm_out": [uj[0], uj[1]],
        })

    road_w = settings.road_width
    lane_off = road_w * 0.5 * getattr(settings, "laneline_ratio", 0.5)
    tail = settings.crosswalk_gap + 4.0 * (road_w / 6.0) * settings.crosswalk_scale
    cut = info.get('bend_cuts', [])
    lanes_out = []
    for i, (a, b) in enumerate(edges):
        ux, uy = _u(pts[b][0] - pts[a][0], pts[b][1] - pts[a][1]) or (1.0, 0.0)
        L = math.hypot(pts[b][0] - pts[a][0], pts[b][1] - pts[a][1])
        t0, t1 = 0.0, L
        for _it in inters:
            vx, vy, tau = _it[-3:]
            if math.hypot(pts[a][0] - vx, pts[a][1] - vy) < 1e-6:
                t0 = max(t0, tau + tail)
            if math.hypot(pts[b][0] - vx, pts[b][1] - vy) < 1e-6:
                t1 = min(t1, L - tau - tail)
        for (cx, cy, dtan) in cut:
            if math.hypot(pts[a][0] - cx, pts[a][1] - cy) < 1e-6:
                t0 = max(t0, dtan)
            if math.hypot(pts[b][0] - cx, pts[b][1] - cy) < 1e-6:
                t1 = min(t1, L - dtan)
        if t1 - t0 < 0.05:
            continue
        for sgn in (+1.0, -1.0):
            def Q(t):
                px = pts[a][0] + (pts[b][0] - pts[a][0]) * (t / L) - uy * lane_off * sgn
                py = pts[a][1] + (pts[b][1] - pts[a][1]) * (t / L) + ux * lane_off * sgn
                z = (zs[a] if a < len(zs) else 0.0) + \
                    ((zs[b] if b < len(zs) else 0.0) - (zs[a] if a < len(zs) else 0.0)) * (t / L)
                return [px * scale, py * scale, z * scale]
            lanes_out.append({
                "edge": i, "from_vertex": a, "to_vertex": b,
                "lateral": lane_off * sgn * scale, "width": road_w * scale,
                "trim_start": t0 * scale, "trim_end": t1 * scale,
                "points": [Q(t0), Q(t1)],
            })

    return {
        "format": "RoadBuilderTraffic",
        "version": 1,
        "unit": "cm",
        "scale_from_blender": scale,
        "source": {"blender_obj": obj_name, "matrix_world_applied": True},
        "road": {
            "width": road_w * scale,
            "lane_count_per_dir": 2 if getattr(settings, "gen_laneline", False) else 1,
            "lane_offset": lane_off * scale,
            "corner_radius_ratio": settings.corner_radius_ratio,
            "corner_segments": settings.corner_segments,
            "crosswalk_gap": settings.crosswalk_gap * scale,
            "crosswalk_depth": (4.0 * (road_w / 6.0) * settings.crosswalk_scale) * scale,
        },
        "vertices": verts_out,
        "edges": edges_out,
        "intersections": inters_out,
        "bends": bends_out,
        "lanes": lanes_out,
    }


class ExportTrafficOperator(bpy.types.Operator):
    bl_idname = "road_builder.export_traffic"
    bl_label = "导出交通数据 (JSON)"
    bl_description = "把当前网格的路网 / 路口 / 停车线 / 转弯 / 车道导成 JSON，给 UE 插件用"
    bl_options = {'REGISTER'}

    def execute(self, context):
        from .road_surface import build_road_surface
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "先选中一个网格物体")
            return {'CANCELLED'}
        s = context.scene.road_builder
        mw = obj.matrix_world
        co = [mw @ v.co for v in obj.data.vertices]
        pts = [(c.x, c.y) for c in co]
        zs = [c.z for c in co]
        edges = [tuple(e.vertices) for e in obj.data.edges]
        if not edges:
            self.report({'ERROR'}, "这个网格没有边")
            return {'CANCELLED'}
        verts, faces, info = build_road_surface(
            pts, edges, s.road_width,
            radius_ratio=s.corner_radius_ratio,
            arc_segments=s.corner_segments, z=zs)
        co3 = [(c.x, c.y, c.z) for c in co]
        try:
            from .edgeline import build_center_lines
            _, _, _, cinfo = build_center_lines(
                co3, edges, info.get('intersections', []),
                info.get('crosswalk_slots', []), s.crosswalk_gap,
                4.0 * (s.road_width / 6.0) * s.crosswalk_scale,
                0.15, 0.03, 0.01, 2.0, s.road_width,
                s.corner_radius_ratio, s.corner_segments)
            if cinfo.get('bends'):
                info['bends'] = cinfo['bends']
            if cinfo.get('bend_cuts'):
                info['bend_cuts'] = cinfo['bend_cuts']
        except Exception as e:
            self.report({'WARNING'}, "转弯数据没拿到：%s" % e)
        data = build_traffic_dict(pts, edges, zs, info, s, 100.0, obj.name)
        path = bpy.path.abspath(s.traffic_json_path)
        d = os.path.dirname(path)
        if d and not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        with open(path, "w", encoding="utf-8") as fp:
            json.dump(data, fp, ensure_ascii=False, indent=1)
        self.report({'INFO'}, "已导出：%s（顶点 %d / 边 %d / 路口 %d / 转弯 %d / 车道段 %d）"
                    % (path, len(data['vertices']), len(data['edges']),
                       len(data['intersections']), len(data['bends']), len(data['lanes'])))
        return {'FINISHED'}


def register():
    bpy.utils.register_class(ExportTrafficOperator)


def unregister():
    bpy.utils.unregister_class(ExportTrafficOperator)