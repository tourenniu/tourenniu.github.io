"""交通灯：相位真源 + 摆放 + 材质动画生成。

★ 相位真源（本模块最重要的事）
────────────────────────────────────────────────────────────────
本模块里的「相位表」是整条链路上【唯一】的红绿灯时序定义，
材质的红/绿动画由它【生成】出来。

历史教训：之前仿真自己硬编码 45%/5%/45%/5%，而材质动画是手工 K 的
（绿在 900~1646、周期 1862），两边差 900 帧 → 89% 的时间是反的。

灯的分组（哪条街先绿）
────────────────────────────────────────────────────────────────
用【一根全局参考轴】把所有进口道分成两组：
  · 方向与参考轴「同轴」（夹角 mod 180° 差 < 45°）→ 方向组 0
  · 垂直的那条街                                  → 方向组 1
同一条街的两个方向必然同组（因为方向相反、mod 180° 后相同），
垂直的两条街必然异组 ⇒ 路口不会冲突。

材质动画怎么改（已验证可行且安全）
────────────────────────────────────────────────────────────────
动画挂在【材质节点树】上：mat.node_tree.animation_data.action
驱动 ShaderNodeValue("值") 的输出 → 原理化 BSDF 的 Emission Strength。约定 0=亮、-1=灭。
资产以 link=False 追加，材质是本文件里的本地副本，改它不会污染资产库（实测 md5 不变）。
原始动作会在第一次接触时快照缓存，之后每次都以快照为基准重写 ⇒ 幂等。
"""

import math

import bpy

from .crosswalk import load_object

TAG = "rb_tlight"

ON = 0.0
OFF = -1.0

_PRISTINE = {}



_PHASE_GREEN = 300
_PHASE_BLINK = 90
_PHASE_LEN = _PHASE_GREEN + _PHASE_BLINK
_QUARTER = 4

_ASSET_SHAPE = None

_GROUP_KEY = (('left', 'left'), ('right', 'straight'), ('straight', 'straight'))


def color_group_of(name):
    """从材质名解析出 (方向组, 灯色)。

    方向组：'left'（左转专用）/ 'straight'（直行 + 右转共用）
    灯色  ：'red' / 'green'
    解析不出来（比如旧的 yellow、金属材质）→ (None, None)
    """
    if not name:
        return (None, None)
    low = name.lower()
    col = None
    for k in ('red', 'green'):
        if k in low:
            col = k
            break
    if col is None:
        return (None, None)
    grp = None
    for key, g in _GROUP_KEY:
        if key in low:
            grp = g
            break
    return (grp, col)


def role_of_color(name):
    """材质名 → 该灯管的『转向角色』：'left'（左转）/ 'rite'（直行 + 右转）。

    'rite' 是「直行 + 右转」的统一角色（红灯时不能右转，所以右转灯跟直行灯同时序）。
    解析不出 → None。
    """
    if not name:
        return None
    low = name.lower()
    if 'left' in low:
        return 'left'
    if ('straight' in low) or ('right' in low):
        return 'rite'
    return None


def _default_asset_path():
    try:
        return getattr(bpy.context.scene.road_builder, 'asset_lib', '') or ''
    except Exception:
        return ''


def _probe_asset_phase_shape(blend_path=None, obj_name="traffic_light_straghtandleft"):
    """从资产量出「绿灯常亮段 + 闪烁亮格」的相位内相对区间。

    返回 [(相对起, 相对止), ...]（相对相位起点 0，闭区间）。
    资产里 Left_Green 画的就是这套形态；直行的形态与它同长。
    """
    global _ASSET_SHAPE
    import os
    p = blend_path or _default_asset_path()
    key = (p or '', obj_name)
    if _ASSET_SHAPE is not None and _ASSET_SHAPE[0] == key:
        return _ASSET_SHAPE[1]
    shape = [(0, _PHASE_GREEN - 1)]
    try:
        if p and os.path.isfile(p):
            with bpy.data.libraries.load(p, link=False) as (src, dst):
                dst.materials = [m for m in list(src.materials)
                                 if 'trafficlight' in m.lower()
                                 and 'left' in m.lower() and 'green' in m.lower()]
            m = bpy.data.materials.get("Road_builder_trafficlight_Left_Green")
            nt = getattr(m, 'node_tree', None) if m else None
            ad = nt.animation_data if nt else None
            act = ad.action if ad else None
            if act and act.fcurves:
                fc = act.fcurves[0]
                rel = [f for f in range(0, _PHASE_LEN)
                       if fc.evaluate(f) > -0.5]
                if rel:
                    runs, st = [], rel[0]
                    pv = rel[0]
                    for t in rel[1:]:
                        if t != pv + 1:
                            runs.append((st, pv)); st = t
                        pv = t
                    runs.append((st, pv))
                    shape = runs
    except Exception:
        pass
    _ASSET_SHAPE = (key, shape)
    return shape


def build_four_phase_plan(cycle=0, blink_len=15, blink_count=3,
                          left_protect=True, tail=None, asset_path=None):
    """四相位计划（唯一真源）。

    四条互斥相位：南北左转 · 东西左转 · 南北直行 · 东西直行。
    每条相位 = 绿灯常亮 + 预警闪烁，周期 = 4 × 每条相位。

    ★ 灯的**具体形态**不是在这里写死的，而是从资产
      traffic_light_straghtandleft 的 Left_Green 关键帧**量**出来的
      （见 _probe_asset_phase_shape）。这样画面里的灯和资产逐帧一致。
    """
    global _PHASE_GREEN, _PHASE_BLINK, _PHASE_LEN
    shape = _probe_asset_phase_shape(asset_path)
    if shape:
        _PHASE_GREEN = shape[0][1] - shape[0][0] + 1
        last = max(b for (_a, b) in shape)
        _PHASE_BLINK = max(3 * 15, last + 1 - _PHASE_GREEN)
    _PHASE_LEN = _PHASE_GREEN + _PHASE_BLINK

    chk = build_cycle(None)
    return {
        'cycle': chk['cycle'], 'per': chk['per'],
        'green': _PHASE_GREEN, 'blink': _PHASE_BLINK, 'blink_dur': _PHASE_BLINK,
        'blink_len': 15, 'blink_count': 3, 'yellow': 0, 'all_red': 0,
        'left_protect': bool(left_protect),
        'green_shape': shape,
        'phase_start': chk['phase_start'],
        'phase_of': chk['phase_of'],
    }


def build_cycle(plan=None):
    """★ 四相位时间表（唯一真源）。

    相位 0 南北左转 · 相位 1 东西左转 · 相位 2 南北直行 · 相位 3 东西直行

    每条相位 390 帧 = 绿灯常亮 300 + 预警闪烁 90（与资产同形态：
    闪 3 次、每格 15 帧、先灭后亮）。周期 = 4 × 390 = **1560 帧**（65 秒）。

    ★ 为什么周期不是资产的 1290：
      资产里闪烁是**溢出**到下一相位的时间里的（左转闪到 390，而直行从 690 开始）。
      四相位均分时若仍用 1290，闪烁就会串进下一条相位 —— 实测有 45 帧重叠。
      把每条相位设计成「常亮 + 自己的闪烁」，四条正好铺满周期，零重叠。
    """
    cyc = _PHASE_LEN * _QUARTER
    start = {i: 1 + i * _PHASE_LEN for i in range(_QUARTER)}
    shape = None
    if isinstance(plan, dict):
        shape = plan.get('green_shape')
    if not shape:
        shape = _probe_asset_phase_shape()
    return {
        'cycle': cyc, 'per': _PHASE_LEN, 'phase_start': start,
        'green': _PHASE_GREEN, 'blink': _PHASE_BLINK,
        'green_shape': shape,
        'phase_of': {
            (0, 'left'): 0, (1, 'left'): 1,
            (0, 'rite'): 2, (1, 'rite'): 3,
        },
    }


def phase_window(plan, group, role):
    """(方向组, 灯位) → 该相位的起始帧。"""
    tb = build_cycle(plan)
    ph = tb['phase_of'][(int(group), 'left' if role == 'left' else 'rite')]
    return tb['phase_start'][ph]


def _phase_timeline(plan, group, role):
    """★ 一根灯位在周期内的显式状态序列：[(起帧, 止帧, 状态), ...]。

    状态 ∈ {'green', 'red'}：
        · 资产形态里「亮」的格子            → 'green'（常亮段 + 闪烁里亮起的那几格）
        · 其余所有时间（含闪烁的「灭」格）   → 'red'

    ★ 为什么闪烁的「灭」格也算红灯：资产那里两盏都不亮，但真实路口
      绝不允许出现「无灯」。算作红灯只会让车更早停 —— 更保守，不影响通行判定。
    """
    tb = build_cycle(plan)
    cyc = tb['cycle']
    f0 = phase_window(plan, group, role)
    shape = tb['green_shape'] or [(0, _PHASE_GREEN - 1)]

    on = sorted((f0 + a, f0 + b) for (a, b) in shape)
    p_start = f0
    p_end = f0 + tb['per'] - 1
    block_end = max(b for (_a, b) in on) if on else (p_start - 1)
    seq = []
    cur = p_start
    for (a, b) in on:
        if a > cur:
            seq.append((cur, a - 1, 'dark'))
        seq.append((a, b, 'green'))
        cur = b + 1
    if cur <= block_end:
        seq.append((cur, block_end, 'dark'))
    _tail_off = (shape[0][1] + 1) if shape else 0
    _tail_len = ((shape[-1][1] + 1) - _tail_off) if shape else 0
    _tail_runs = [(a - _tail_off, b - _tail_off) for (a, b) in shape[1:]] if shape else []
    if _tail_runs and _tail_len > 0:
        _w0 = p_start - _tail_len
        _cur = 0
        for (_a, _b) in _tail_runs:
            if _cur < _a:
                seq.append((_w0 + _cur, _w0 + _a - 1, 'dark'))
            _cur = _b + 1
        if _cur < _tail_len:
            seq.append((_w0 + _cur, _w0 + _tail_len - 1, 'dark'))
    out = []
    for (a, b, st) in seq:
        a2 = (a - 1) % cyc + 1
        b2 = (b - 1) % cyc + 1
        if a2 <= b2:
            out.append((a2, b2, st))
        else:
            out.append((a2, cyc, st))
            out.append((1, b2, st))
    return _dedupe(sorted(out))


def _dedupe(seq):
    """把相邻且状态相同的段合并（折回周期末时可能产生重复段）。"""
    out = []
    for (a, b, st) in seq:
        if not out or out[-1][2] != st or a > out[-1][1] + 1:
            out.append([a, b, st])
        else:
            out[-1][1] = max(out[-1][1], b)
    return [tuple(x) for x in out]


def _state_at(plan, group, role, f):
    for (a, b, st) in _phase_timeline(plan, group, role):
        if a <= f <= b:
            return st
    return 'red'


def _green_runs(plan, group, role):
    """该灯位的绿灯区间。"""
    return [(a, b) for (a, b, st) in _phase_timeline(plan, group, role)
            if st == 'green']


def _red_runs(plan, group, role):
    """该灯位的红灯区间。"""
    return [(a, b) for (a, b, st) in _phase_timeline(plan, group, role)
            if st == 'red']


def _in_runs(runs, f):
    for (a, b) in runs:
        if a <= f <= b:
            return True
    return False


def _loc_frame(plan, loc):
    """周期内位置 loc → 帧号 f（loc 0 ↔ 帧 1）。"""
    return (loc % plan['cycle']) + 1


def lamp_state_g(plan, loc, group, role, color):
    """★ 灯态查询：第 group 组（0=南北街, 1=东西街）的
    『role』灯（'left' 左转 / 'rite' 直行+右转）此刻亮不亮。
    """
    if not plan:
        return False
    want = 'green' if color == 'green' else 'red'
    return _state_at(plan, group, role, _loc_frame(plan, loc)) == want


def can_go(plan, loc, group, role):
    """★车流用：此刻这组、这个灯位【能不能通行】。

    绿灯块 = 相位起点 → 最后一个亮格的末帧（含闪烁的"灭格"）。
    闪烁只是"要变红了"的警示 ⇒ 绝不能让车在闪烁里刹车；
    红灯段（含末尾那 3 次红闪，那些帧灯是灭的但逻辑仍然是红）不能走。
    """
    if not plan:
        return True
    tb = build_cycle(plan)
    cyc = tb['cycle']
    f = _loc_frame(plan, loc)
    shape = tb['green_shape'] or [(0, _PHASE_GREEN - 1)]
    f0 = phase_window(plan, group, role)
    blk = f0 + max(b for (_a, b) in shape)
    if blk > cyc:
        return (f >= f0) or (f <= blk - cyc)
    return f0 <= f <= blk


def phase_state(plan, loc, group, role):
    """逻辑状态：'green'（绿灯块内，含闪烁灭格）/ 'red'（含红末尾那几次闪灭）。"""
    return 'green' if can_go(plan, loc, group, role) else 'red'


def build_lamp_runs4(plan=None):
    """(组, 灯位, 灯色) → 亮区间，供自检打印用。"""
    out = {}
    for g in (0, 1):
        for role in ('left', 'rite'):
            out[(g, role, 'green')] = list(_green_runs(plan, g, role))
            out[(g, role, 'red')] = list(_red_runs(plan, g, role))
    return out


def plan_from_settings(s):
    """从场景设置里取相位表。

    用「四相位」模型（左转保护 + 直行含右转），灯形态从资产量出来。
    """
    return build_four_phase_plan(
        cycle=getattr(s, 'tlight_cycle', 0),
        blink_len=getattr(s, 'tlight_blink_len', 15),
        blink_count=getattr(s, 'tlight_blink_n', 3),
        left_protect=bool(getattr(s, 'tlight_left', True)),
        asset_path=getattr(s, 'asset_lib', '') or None,
    )



def global_ref_axis(xwalk_slots):
    """★ 从所有斑马线槽位里求出**一根全局参考轴**。

    之前是「每个路口各自取自己第一条进口道当参考」→ 不同路口参考轴不同 →
    同一条街在 A 路口算方向组 0、到 B 路口算方向组 1 → 整条街灯态自相矛盾。
    改成全局唯一参考轴后，同一条街在任意路口都得到同一个组。
    """
    if not xwalk_slots:
        return (1.0, 0.0)
    best = None
    for s in xwalk_slots:
        try:
            u = s[1]
        except Exception:
            continue
        if not u:
            continue
        ux, uy = float(u[0]), float(u[1])
        L = math.hypot(ux, uy)
        if L < 1e-9:
            continue
        ux, uy = ux / L, uy / L
        score = abs(ux)
        if best is None or score > best[0]:
            best = (score, (ux, uy))
    return best[1] if best else (1.0, 0.0)


def arm_group(u, ref):
    """进口道方向 u 属于哪个方向组（0/1）。用 mod 180° 判断同轴/垂直。"""
    if not u or not ref:
        return 0
    ux, uy = float(u[0]), float(u[1])
    L = math.hypot(ux, uy)
    if L < 1e-9:
        return 0
    ux, uy = ux / L, uy / L
    rx, ry = float(ref[0]), float(ref[1])
    R = math.hypot(rx, ry)
    if R < 1e-9:
        return 0
    rx, ry = rx / R, ry / R
    d = abs(ux * rx + uy * ry)
    return 0 if d >= math.cos(math.radians(45.0)) else 1


def arm_groups(xwalk_slots, ref=None):
    """所有进口道的方向组列表。"""
    if ref is None:
        ref = global_ref_axis(xwalk_slots)
    return [arm_group(s[1] if len(s) > 1 else None, ref) for s in xwalk_slots]


def check_conflicts(xwalk_slots, slot_ids, groups, limit=15):
    """自检：同一路口里，夹角 >= 60° 的两条进口道不能同组。"""
    by_int = {}
    for i, s in enumerate(xwalk_slots):
        sid = slot_ids[i] if i < len(slot_ids) else None
        by_int.setdefault(sid, []).append(i)
    bad = []
    for sid, idxs in by_int.items():
        for a in range(len(idxs)):
            for b in range(a + 1, len(idxs)):
                ia, ib = idxs[a], idxs[b]
                ua = xwalk_slots[ia][1] if len(xwalk_slots[ia]) > 1 else None
                ub = xwalk_slots[ib][1] if len(xwalk_slots[ib]) > 1 else None
                if not ua or not ub:
                    continue
                La = math.hypot(ua[0], ua[1]) or 1.0
                Lb = math.hypot(ub[0], ub[1]) or 1.0
                d = abs((ua[0] / La) * (ub[0] / Lb) + (ua[1] / La) * (ub[1] / Lb))
                ang = math.degrees(math.acos(max(-1.0, min(1.0, d))))
                if ang >= 60.0 and groups[ia] == groups[ib]:
                    bad.append((sid, ia, ib, round(ang, 1)))
    return bad[:limit], {'intersections': len(by_int), 'slots': len(xwalk_slots)}



def _snapshot_materials(obj):
    """把资产原始动画快照下来（首次接触时）。"""
    name = obj.name
    if name in _PRISTINE:
        return _PRISTINE[name]
    snap = {}
    for m in obj.data.materials:
        if not m or getattr(m, 'node_tree', None) is None:
            continue
        nt = m.node_tree
        ad = nt.animation_data
        act = ad.action if ad else None
        if not act:
            snap[m.name] = []
            continue
        rows = []
        for fc in act.fcurves:
            kps = [(float(k.co[0]), float(k.co[1]), k.interpolation)
                   for k in fc.keyframe_points]
            rows.append((fc.data_path, fc.array_index, fc.extrapolation, kps))
        snap[m.name] = rows
    _PRISTINE[name] = snap
    return snap


def _mat_ok(m):
    """★ 材质还活着吗？（Ctrl+Z 会回收生成时追加/复制的材质 ✗，
    那时拿它去取 node_tree 会直接崩 Blender ✗）"""
    import bpy
    try:
        return (m is not None) and (m.name in bpy.data.materials)
    except (ReferenceError, RuntimeError):
        return False


def _fresh_action(mat, force_new=False):
    """给材质节点树准备一个动作：复用（并清空）或新建。"""
    if not _mat_ok(mat):
        return None
    nt = mat.node_tree
    if nt.animation_data is None:
        nt.animation_data_create()
    ad = nt.animation_data
    act = ad.action
    if act is not None:
        try:
            if act.name not in bpy.data.actions:
                act = None
        except (ReferenceError, RuntimeError):
            act = None
        if act is None:
            try:
                ad.action = None
            except Exception:
                pass
    if act is None or force_new:
        act = bpy.data.actions.new(mat.name + ("_Blink" if force_new else ""))
        ad.action = act
    else:
        try:
            act.fcurves.clear()
        except Exception:
            for fc in list(act.fcurves):
                try:
                    act.fcurves.remove(fc)
                except Exception:
                    break
    try:
        if hasattr(act, 'slots'):
            if len(act.slots) == 0:
                act.slots.new(id_type='NODETREE', name=mat.name)
            if (hasattr(ad, 'action_slot') and getattr(ad, 'action_slot', None) is None
                    and len(act.slots) >= 1):
                ad.action_slot = act.slots[0]
    except Exception:
        pass
    return act


def _write_keyframes(fc, keys):
    """把 [(帧,值,插值,首点?,末点?), ...] 写进曲线（同帧后者覆盖前者）。"""
    uniq = {}
    for (t, v, ip, _f, _l) in keys:
        uniq[round(float(t), 4)] = (float(t), float(v), ip)
    ks = [uniq[t] for t in sorted(uniq)]
    while len(fc.keyframe_points):
        try:
            fc.keyframe_points.remove(fc.keyframe_points[0], fast=True)
        except Exception:
            break
    if not ks:
        return
    fc.keyframe_points.add(len(ks))
    for i, (t, v, ip) in enumerate(ks):
        kp = fc.keyframe_points[i]
        kp.co = (t, v)
        kp.interpolation = ip
        kp.handle_left_type = 'AUTO_CLAMPED'
        kp.handle_right_type = 'AUTO_CLAMPED'
    fc.extrapolation = 'CONSTANT'
    fc.update()


def _group_keys(plan, group, role, color):
    """生成「某方向组某灯位某灯色」的关键帧：逐帧采样 lamp_state_g，
    只在状态变化处落键（硬跳变）。

    帧号与 Blender 帧一致（loc = f − 1）。
    """
    cyc = int(plan['cycle'])
    lit = []
    for f in range(1, cyc + 1):
        try:
            v = ON if lamp_state_g(plan, f - 1, group, role, color) else OFF
        except Exception:
            v = OFF
        lit.append(v)
    ks = []
    for i, v in enumerate(lit):
        if i == 0 or v != lit[i - 1]:
            ks.append((float(i + 1), float(v), 'CONSTANT'))
    if ks and lit:
        ks.append((float(cyc), float(lit[0]), 'CONSTANT'))
    if not ks:
        ks = [(1.0, OFF, 'CONSTANT')]
    return [(t, v, ip, i == 0, i == len(ks) - 1)
            for i, (t, v, ip) in enumerate(ks)]


def _write_color_action(mat, plan, group=0, force_new=False):
    """按相位表重写单个材质的灯色动画。"""
    role = role_of_color(mat.name)
    col = color_group_of(mat.name)[1]
    if role is None or col is None or getattr(mat, 'node_tree', None) is None:
        return False
    nt = mat.node_tree
    if nt.animation_data is None:
        nt.animation_data_create()
    act = _fresh_action(mat, force_new=force_new)
    nt.animation_data.action = act
    try:
        if (hasattr(nt.animation_data, 'action_slot')
                and getattr(nt.animation_data, 'action_slot', None) is None
                and len(getattr(act, 'slots', [])) >= 1):
            nt.animation_data.action_slot = act.slots[0]
    except Exception:
        pass
    fc = None
    for f in act.fcurves:
        if 'nodes["值"]' in f.data_path and f.array_index == 0:
            fc = f
            break
    if fc is None:
        try:
            fc = act.fcurves.new('nodes["值"].outputs[0].default_value', index=0)
        except Exception:
            return False
    _write_keyframes(fc, _group_keys(plan, group, role, col))
    return True


def _restore_from_snapshot(obj, snap):
    """先恢复到原始动画（快照），让后续生成永远以资产原始动画为基准。"""
    for m in obj.data.materials:
        if not _mat_ok(m):
            continue
        try:
            if not getattr(m, 'node_tree', None) or m.name not in snap:
                continue
        except (ReferenceError, RuntimeError):
            continue
        nt = m.node_tree
        if nt.animation_data is None:
            nt.animation_data_create()
        act = _fresh_action(m)
        nt.animation_data.action = act
        for (path, idx, ext, kps) in snap[m.name]:
            try:
                fc = act.fcurves.new(path, index=idx)
            except Exception:
                continue
            fc.extrapolation = ext
            _write_keyframes(fc, [(t, v, ip, False, False) for (t, v, ip) in kps])


def make_phase_materials(obj, plan, need_phase2=True, groups=(0, 1)):
    """★ 按相位表重写灯材质动画。

    返回 {原材质名: 副本材质}。

    第 1 套材质写「方向组 0」（南北街），第 2 套写「方向组 1」（东西街）。
    每盏灯（Left_* / Straight_* / Right_*）都各自按自己的灯位写。

    幂等性：每次都以「资产原始动作快照」为基准重写，重新生成 100 次结果一致。
    """
    snap = _snapshot_materials(obj)
    _restore_from_snapshot(obj, snap)
    g1, g2 = (list(groups) + [0, 1])[:2]
    for m in obj.data.materials:
        if _mat_ok(m):
            _write_color_action(m, plan, g1)

    mats2 = {}
    if need_phase2:
        for m in list(obj.data.materials):
            if not _mat_ok(m):
                continue
            m2 = m.copy()
            m2.name = m.name + "_组2"
            _write_color_action(m2, plan, g2, force_new=True)
            mats2[m.name] = m2
    return mats2



def clear_lights(asset_name=""):
    """清掉上次生成的灯。

    顺手清「资产模板残留」：没有 rb_tlight 标记、但名字前缀就是资产灯对象名的那盏
    （load_object 追加进来的，老版本没收走 → 会一直站在原点用旧动画）。
    """
    kill = [o for o in bpy.data.objects if o.get(TAG)]
    if asset_name:
        base = asset_name.split(".")[0]
        kill += [o for o in bpy.data.objects
                 if (not o.get(TAG)) and o.name.split(".")[0] == base]
    for o in kill:
        try:
            bpy.data.objects.remove(o, do_unlink=True)
        except Exception:
            pass
    for me in list(bpy.data.meshes):
        if '_组2' in me.name and me.users == 0:
            try:
                bpy.data.meshes.remove(me)
            except Exception:
                pass
    for m in list(bpy.data.materials):
        if '_组2' in m.name and m.users == 0:
            try:
                bpy.data.materials.remove(m)
            except Exception:
                pass
    for a in list(bpy.data.actions):
        try:
            if not a.users and '_Blink' in a.name:
                bpy.data.actions.remove(a)
        except Exception:
            pass


def place_traffic_lights(target_coll, xwalk_slots, blend_path, obj_name,
                         right_side=True, lateral=0.9, along=0.6,
                         rot_offset=0.0, scale=1.0, lift=0.0,
                         intersections=(), slot_ids=(),
                         phase_mode=True, cycle=1560, shift=0.0,
                         phase_plan=None, name_prefix="RB_TL_",
                         set_frame_range=True):
    """每条斑马线放一个交通灯。

    · 分组：用【全局参考轴】算，保证同一条街在各路口同组、垂直街异组
    · 时序：材质动画由相位表生成（方向组 0 / 方向组 1 各一套）
    """
    plan = phase_plan or build_four_phase_plan(cycle=cycle)
    info = {'count': 0, 'group0': 0, 'group1': 0, 'material': [],
            'cycle': plan['cycle'] if plan else cycle, 'shift': float(shift or 0.0),
            'conflicts': [], 'phase_plan': plan}
    if not xwalk_slots or plan is None:
        return info, ""

    o, err = load_object(blend_path, obj_name)
    if err or o is None:
        return info, err or "没取到交通灯资产：%s" % obj_name

    clear_lights()

    groups = arm_groups(xwalk_slots) if phase_mode else [0] * len(xwalk_slots)

    bad, cstat = check_conflicts(xwalk_slots, slot_ids, groups)
    info['conflict_stat'] = cstat
    info['conflicts'] = bad

    need2 = bool(phase_mode and (1 in groups))
    mats2 = make_phase_materials(o, plan, need_phase2=need2)
    mesh2 = None
    if need2 and mats2:
        mesh2 = o.data.copy()
        mesh2.name = o.data.name + "_组2"
        for i, ms in enumerate(mesh2.materials):
            if ms and ms.name in mats2:
                mesh2.materials[i] = mats2[ms.name]
    info['phase2_mats'] = sorted(mats2.keys())

    side = 1.0 if right_side else -1.0
    for i, s in enumerate(xwalk_slots):
        pt, u, rw, z = s[:4]
        n = (-u[1] * side, u[0] * side)
        base_x = pt[0] + u[0] * along + n[0] * (rw * 0.5 + lateral)
        base_y = pt[1] + u[1] * along + n[1] * (rw * 0.5 + lateral)
        arm = (-n[0], -n[1])
        ang = math.atan2(arm[1], arm[0]) - math.pi * 0.5 + float(rot_offset)
        new = o.copy()
        gp = groups[i]
        new.data = mesh2 if (gp == 1 and mesh2 is not None) else o.data
        new.name = name_prefix + o.name
        new.location = (base_x, base_y, z + lift)
        new.rotation_euler = (0.0, 0.0, ang)
        if scale != 1.0:
            new.scale = (scale, scale, scale)
        new[TAG] = 1
        new['rb_phase'] = int(gp)
        target_coll.objects.link(new)
        if gp == 1:
            info['group1'] += 1
        else:
            info['group0'] += 1
        info['count'] += 1
        info['material'].append(new.name)

    try:
        for _c in list(o.users_collection):
            _c.objects.unlink(o)
        if not o.users_collection:
            bpy.data.objects.remove(o, do_unlink=True)
    except Exception:
        try:
            o.hide_viewport = True
            o.hide_render = True
        except Exception:
            pass

    try:
        lamps, with_keys, g2, no_keys, unbound = 0, 0, 0, [], []
        for m in bpy.data.materials:
            if 'trafficlight' not in m.name or 'yellow' in m.name.lower():
                continue
            if '_组2' in m.name:
                g2 += 1
            nt = getattr(m, 'node_tree', None)
            ad = nt.animation_data if nt else None
            act = ad.action if ad else None
            lamps += 1
            if act and act.fcurves:
                with_keys += 1
            else:
                no_keys.append(m.name)
            if ad is not None and hasattr(ad, 'action_slot'):
                if act is not None and getattr(ad, 'action_slot', None) is None:
                    unbound.append(m.name)
        print("[RB_TL] 灯珠材质自检：共 %d 个（组2 副本 %d 个），有动画 %d 个%s%s"
              % (lamps, g2, with_keys,
                 ("；★没有动画：%s" % no_keys[:6]) if no_keys else "",
                 ("；★动作没绑槽位：%s" % unbound[:6]) if unbound else ""))
    except Exception as _e:
        print("[RB_TL] 材质自检跳过:", _e)

    if set_frame_range:
        try:
            bpy.context.scene.frame_start = 1
            bpy.context.scene.frame_end = int(plan['cycle'])
        except Exception:
            pass
    return info, ""


def scene_light_phases():
    """场景里各灯的方向组。"""
    out = {}
    for o in bpy.data.objects:
        if o.get(TAG):
            out[o.name] = int(o.get('rb_phase', 0))
    return out
