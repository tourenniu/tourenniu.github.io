import bpy
from bpy.props import PointerProperty
from bpy.props import FloatProperty, IntProperty, BoolProperty, StringProperty, EnumProperty
from bpy.types import PropertyGroup


class RoadBuilderSettings(PropertyGroup):

    road_width: FloatProperty(
        name="道路宽度",
        default=15.0,
        min=0.1,
        description="道路总宽度（中心线两侧各一半）",
    )

    corner_radius_ratio: FloatProperty(
        name="圆角半径(×路宽)",
        default=0.5,
        min=0.01,
        max=2.0,
        description="交叉口转角圆弧半径 = 路宽 × 该系数（iCity 实测为 0.5）",
    )

    corner_segments: IntProperty(
        name="圆角分段",
        default=8,
        min=2,
        max=64,
        description="每段圆角圆弧的分段数",
    )
    gen_sidewalk: BoolProperty(
        name="生成人行道",
        default=False,
        description="沿路面边界往外挤出一条带子（人行道），左右两侧都会生成",
    )

    sidewalk_width: FloatProperty(
        name="人行道宽度",
        default=1.0,
        min=0.05,
        description="人行道沿外法线往外挤出多少（建议小于 半个路宽，否则拐角圆弧会被吃掉）",
    )

    sidewalk_height: FloatProperty(
        name="人行道高度(Z)",
        default=0.15,
        description="人行道抬高多少（路缘高度）",
    )
    gen_blocks: BoolProperty(
        name="填充街区地面",
        default=False,
        description="把「人行道内侧围出的闭合区域」填成一个面（街区地面）",
    )

    gen_buildings: BoolProperty(
        name="随机建筑",
        default=False,
        description="在街区地面上随机撒长方体（临时当建筑物）",
    )

    bld_count: IntProperty(
        name="每街区个数",
        default=3, min=1, max=60,
        description="每个街区最多生成几个建筑",
    )

    bld_h_min: FloatProperty(
        name="最小高度", default=8.0, min=0.5,
        description="随机建筑的最小高度",
    )

    bld_h_max: FloatProperty(
        name="最大高度", default=30.0, min=0.5,
        description="随机建筑的最大高度",
    )

    bld_gap: FloatProperty(
        name="建筑最小间距", default=2.0, min=0.0,
        description="两个建筑之间至少留多少空隙",
    )

    bld_seed: IntProperty(
        name="随机种子", default=0, min=0,
        description="同样的种子 → 同样的布局；改一下就是另一座城",
    )

    use_asset: BoolProperty(
        name="用建筑资产替换方块",
        default=False,
        description="开启后不放长方体，改成从资产库摆模型（链接副本，材质保留）",
    )

    rb_update_status: StringProperty(
        name="更新状态",
        default="",
        description="最近一次检查更新的结果（只用于面板显示）")

    rb_started: BoolProperty(
        name="已开始使用（本文件）", default=False,
        description="点过【开始使用】后为真；每个新 .blend 都要点一次") 

    asset_lib: StringProperty(
        name="资产库 .blend（合集/材质/模型都从这里找）",
        default="",
        subtype="FILE_PATH",
        description="建筑资产所在的 .blend 文件（会以 link 方式引用，改资产能同步）",
    )

    asset_coll: StringProperty(
        name="资产集合名",
        default="Road_Builder_buildings",
        description="资产 .blend 里装建筑的那个集合名",
    )

    asset_random_dir: BoolProperty(
        name="随机朝向(90°倍数)",
        default=True,
        description="每栋随机转 0/90/180/270°（地块仍会被铺满）",
    )


    use_road_mat: BoolProperty(
        name="路面用资产材质",
        default=True,
        description="给路面单独分配一个材质槽（从资产库里取），其余部分用浅灰占位材质",
    )

    road_mat_lib: StringProperty(
        name="(已合并到资产库)",
        default="",
        description="已废弃：路面材质统一从「资产库 .blend」里找")

    road_mat_name: PointerProperty(
        type=bpy.types.Material, name="路面材质",
        description="路面用的材质（点「开始使用」会从资产库导入默认材质）")

    sidewalk_mat_name: PointerProperty(
        type=bpy.types.Material, name="人行道材质",
        description="人行道和街区地面用的材质")

    road_mat_uv_scale: FloatProperty(
        name="贴图平铺尺度",
        default=4.0,
        min=0.05,
        description="一个贴图平铺多少世界单位（越小贴图越密）",
    )


    gen_crosswalk: BoolProperty(
        name="路口斑马线",
        default=True,
        description="在度数 >= 3 的路口，每条臂贴着切线外侧放一条斑马线",
    )

    crosswalk_obj: StringProperty(
        name="斑马线资产名",
        default="Road_Builder_Crosswalk",
        description="资产 .blend 里的对象名（默认和建筑资产同一个文件，用 asset_lib 的路径）",
    )

    crosswalk_gap: FloatProperty(
        name="离切线距离",
        default=0.3, min=0.0,
        description="斑马线内边缘离路口切线（路被截断处）多远",
    )

    crosswalk_scale: FloatProperty(
        name="尺寸倍数",
        default=1.0, min=0.05,
        description="斑马线整体缩放倍数（横向仍然铺满路宽）",
    )

    crosswalk_lift: FloatProperty(
        name="抬高(防重叠闪烁)",
        default=0.01, min=0.0,
        description="斑马线抬离路面一点点，避免和路面共面闪烁",
    )


    gen_edgeline: BoolProperty(
        name="道路边线",
        default=True,
        description="沿路缘（非路口区域）铺一条白色边线，路口/斑马线处自动让开",
    )

    edgeline_obj: PointerProperty(
        type=bpy.types.Material, name="道路边线材质",
        description="白边线用的材质（点「开始使用」会从资产库导入默认材质）")

    edgeline_inset: FloatProperty(
        name="离路缘距离",
        default=0.2, min=0.0,
        description="边线内边缘离路缘多远",
    )

    edgeline_width: FloatProperty(
        name="线宽",
        default=0.15, min=0.01,
        description="边线宽度",
    )

    edgeline_lift: FloatProperty(
        name="抬高(防闪烁)",
        default=0.01, min=0.0,
        description="边线抬离路面一点点",
    )


    gen_centerline: BoolProperty(name="双黄线", default=True,
                                 description="沿路段中心线铺两条黄线（路口/斑马线处让开）")
    centerline_obj: PointerProperty(
        type=bpy.types.Material, name="双黄线材质",
        description="双黄线用的材质")
    centerline_sep: FloatProperty(name="双线间隙", default=0.03, min=0.0,
                                  description="两条黄线之间的空隙")
    centerline_width: FloatProperty(name="单线宽", default=0.15, min=0.01)
    centerline_lift: FloatProperty(name="抬高(防闪烁)", default=0.01, min=0.0)


    gen_laneline: BoolProperty(name="车道虚线", default=True,
                               description="在黄线与白边线之间的车道中线上，铺一段段白色虚线")
    laneline_obj: PointerProperty(
        type=bpy.types.Material, name="车道虚线材质",
        description="车道虚线用的材质")
    laneline_ratio: FloatProperty(name="车道线位置", default=0.5, min=0.05, max=0.95,
                                  description="占半边路宽的比例（0.5 = 车道中间；0.33/0.67 可做三车道）")
    laneline_dash: FloatProperty(name="线段长", default=2.0, min=0.1)
    laneline_gap: FloatProperty(name="段间距", default=4.0, min=0.0)
    laneline_width: FloatProperty(name="线宽", default=0.15, min=0.01)
    laneline_lift: FloatProperty(name="抬高(防闪烁)", default=0.01, min=0.0)


    line_xwalk_gap: FloatProperty(
        name="标线离斑马线",
        default=-6.0, min=-20.0, max=30.0,
        description="白边线/双黄线/车道虚线的起点离「斑马线外缘」的距离：0 = 紧贴，负值 = 压进斑马线",
    )


    traffic_json_path: StringProperty(
        name="交通数据 JSON",
        default="F:\\pythoncode\\blender_develop\\_icity_ref\\traffic.json",
        description="导出交通流数据的路径",
    )


    bld_height_mode: EnumProperty(
        name="高度模式",
        items=[
            ('RANGE', "区间随机", "在最小/最大高度之间随机取值（可能拉伸建筑比例）"),
            ('PERCENT', "保比例±百分比", "先按街区自适应缩放，高度只在该高度上下浮动这个百分比（保持原本样貌）"),
        ],
        default='RANGE',
        description="建筑高度怎么定",
    )
    bld_height_pct: FloatProperty(
        name="高度浮动",
        default=0.15, min=0.0, max=1.0,
        description="保比例模式下，高度最多比「自适应缩放后的自然高度」高/低这么多",
    )


    gen_tlight: BoolProperty(name="路口交通灯", default=True,
                             description="在每条斑马线旁边摆一个交通灯（立杆在路缘，横臂伸向路面）")
    tlight_obj: StringProperty(name="交通灯资产名",
                              default="traffic_light_straghtandleft",
                              description="带左转灯的资产（左转 + 直行/右转 两组灯）")
    tlight_right: BoolProperty(name="放在右侧", default=True,
                               description="按你所在方向的行车右侧（取消勾选则放左侧）")
    tlight_lateral: FloatProperty(name="杆离路缘", default=0.9, min=-5.0,
                                  description="立杆在路缘外侧多远")
    tlight_along: FloatProperty(name="沿路退让", default=3.2, min=-10.0,
                                description="沿路方向往斑马线外侧退多少")
    tlight_rot: FloatProperty(name="朝向微调", default=0.0, subtype='ANGLE',
                              description="灯面朝向不对时，用这个补一个角度")
    tlight_scale: FloatProperty(name="整体缩放", default=1.0, min=0.05)
    tlight_lift: FloatProperty(name="抬高", default=0.0)


    tlight_phase: BoolProperty(name="对向反相位", default=True,
                               description="同一路口里，垂直方向那组灯用反相位材质（他红我绿）")

    tlight_left: BoolProperty(
        name="左转专用相位", default=True,
        description="勾选：左转单独放行（需要资产带左转灯）；"
                    "取消：左转并入直行一起走，通行能力更高但左转会与对向直行交叉")
    tlight_cycle: IntProperty(
        name="信号周期(帧)", default=1560, min=48,
        description="一个完整红绿灯周期多少帧（24 帧 = 1 秒）。"
                    "默认 1560 帧 = 65 秒：四条相位各 390 帧（300 实绿 + 90 闪烁），"
                    "由资产形态自动推出；本项只作显示，实际周期以资产为准")
    tlight_blink_n: IntProperty(
        name="闪烁次数", default=3, min=0, max=20,
        description="绿灯结束前闪几下（代替黄灯预警）")
    tlight_blink_len: IntProperty(
        name="单次闪烁(帧)", default=15, min=2,
        description="一下闪烁占多少帧（亮 15、灭 15）")

    gen_traffic: BoolProperty(
        name="生成车流", default=False,
        description="按车道生成车辆并烘焙动画；车辆遵守红绿灯（信号来自上面的相位表）")
    traffic_count: IntProperty(
        name="车辆数", default=50, min=1, max=2000,
        description="生成多少辆车（按路线轮流分配）")
    traffic_speed: FloatProperty(
        name="车速(m/s)", default=10.0, min=1.0, max=40.0,
        description="自由流期望车速（36 km/h ≈ 10 m/s）")
    traffic_wheel_anim: BoolProperty(
        name="车轮动画", default=True,
        description="自动生成车轮滚动 + 前轮转向（转弯时渐入渐出）")
    traffic_wheel_rate: FloatProperty(
        name="车轮滚动动画速率",
        default=1.0, min=0.1, max=5.0,
        description="1.0 = 标准（按真实轮半径滚，不滑）；2.0 = 转快一倍；0.5 = 转慢一半")

    traffic_wheel_r: FloatProperty(
        name="车轮半径(m)", default=0.0, min=0.0, max=2.0,
        description="0 = 自动（从骨骼读，约0.36）。轮子转太快就调大、太慢就调小")
    traffic_steer_gain: FloatProperty(
        name="拐弯时前轮转动幅度", default=1.0, min=0.0, max=3.0,
        description="1.0 = 几何真值（12m 弯 ≈14.6°）；想更夸张就 1.5~2.0")
    traffic_steer_tau: FloatProperty(
        name="转向柔和度(秒)", default=0.35, min=0.05, max=2.0,
        description="转向角渐入渐出的时间常数：小=打方向快，大=更柔更慢")
    traffic_stop_back: FloatProperty(
        name="停车线退让(m)", default=0.0, min=-3.0, max=8.0,
        description="额外退让：默认 0 = 自动停在斑马线内侧（灯位+0.5m）。正值=再往外退，负值=往斑马线里压")
    traffic_lane_shift: FloatProperty(
        name="车道内横向微调(m)", default=-0.3, min=-2.0, max=2.0,
        description="车体在车道里左右微调：负 = 往黄线侧（左）挪。"
                    "看着偏右就调负一点（-0.3~-0.6）；看着正中就把它设成 0")
    traffic_turn_seg: IntProperty(
        name="转弯分段数", default=72, min=4, max=128,
        description="转弯圆弧切成几段。小 = 一顿一顿（8 段时每段转 11.25°），"
                    "大 = 更丝滑（16 段 → 每段 5.6°；想更顺可 24/32）")
    traffic_turn_radius: FloatProperty(
        name="转弯半径(m)", default=12.0, min=0.0, max=60.0,
        description="转弯圆弧半径。0 = 自动（路宽的一半 = 7.5m）。"
                    "两个对向左转的净间距随它变大：7.5m→0.9m(车身会重叠) / 10m→3.0m / "
                    "12m→4.6m ⇒ 建议 10~12")
    traffic_left_ratio: FloatProperty(
        name="左转车比例", default=0.5, min=0.0, max=1.0,
        description="多大比例的车走左转专用（内侧靠黄线车道、每个路口优先左转）；"
                    "其余走外侧车道（优先直行，没有直行就右转）")
    traffic_lane: IntProperty(
        name="车道序号", default=0, min=0, max=3,
        description="0=内侧车道，1=外侧车道（路线使用的车道中心线）")
    traffic_seed: IntProperty(name="随机种子", default=0, min=0, max=999999)
    traffic_frames: IntProperty(
        name="帧数(0=用场景)", default=0, min=0,
        description="烘焙多少帧；0 = 用场景帧范围（生成灯之后通常是 1560）")
    traffic_target: StringProperty(
        name="输出集合", default="RB_Traffic",
        description="车辆放进的集合（会自动创建）")
    traffic_coll: StringProperty(
        name="车辆库前缀", default="Cars",
        description="资产里 CarNN 所在集合的前缀（Cars 1 / Cars 2 …；空集合 Cars 会被排除）")
    traffic_yaw: FloatProperty(
        name="车头朝向修正", default=0.0, subtype='ANGLE',
        description="车头方向不对时，用这个补一个角度（默认 0）")
