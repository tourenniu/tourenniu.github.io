"""道路边线 + 双黄线。

统一思路：全部从「已经算好的路面几何 / 输入网格」反推，路口核心区和
斑马线覆盖的区间一律不画。

  · 边线  ：沿路面边界（路缘，含转弯圆弧）内侧铺白线
  · 双黄线：沿每条网格边（= 路段中心轴）铺两条黄线
"""

import math
import os

from .crosswalk import load_object
from .sidewalk import loops_of, loop_points


OBJ_EDGE = "Road_Builder_Whiteline"
OBJ_CENTER = "Road_Builder_Yellowline"
OBJ_LANE = "Road_Builder_Whiteline"

LINE_MAT_DEFAULT = {
    "edgeline_obj": "Road_Builder_Whiteline",
    "centerline_obj": "Road_Builder_Yellowline",
    "laneline_obj": "Road_Builder_Whiteline",
}


MAT_COLL_NAME = "traffic_material"
KNOWN_LINE_MATS = ["Road_Builder_Whiteline", "Road_Builder_Yellowline",
                   "Road_Builder_Aspha01", "Road_Builder_Sidewalk"]
_traffic_mat_cache = []


def traffic_mat_names(force=False):
    """【纯函数，可被下拉回调调用】返回候选材质名：缓存 -> 保底常量。绝不加载库。"""
    if _traffic_mat_cache:
        return list(_traffic_mat_cache)
    return list(KNOWN_LINE_MATS)


def refresh_traffic_mats():
    """【会加载库】从资产库 traffic_material 集合重新读材质名并缓存。只在按钮/生成时调用。"""
    import bpy
    names = []
    lib = ""
    try:
        lib = getattr(bpy.context.scene.road_builder, "asset_lib", "") or ""
    except Exception:
        lib = ""
    if lib and os.path.exists(lib):
        coll = None
        try:
            with bpy.data.libraries.load(lib, link=True) as (src, dst):
                allc = list(src.collections or [])
                pick = MAT_COLL_NAME if MAT_COLL_NAME in allc else next(
                    (n for n in allc if MAT_COLL_NAME.lower() in n.lower()), None)
                if pick:
                    dst.collections = [pick]
                    coll = dst.collections[0] if dst.collections else None
            if coll is not None:
                for o in coll.objects:
                    if o.type == "MESH" and o.data:
                        for m in o.data.materials:
                            if m and m.name not in names:
                                names.append(m.name)
        except Exception:
            names = []
        finally:
            try:
                if coll is not None:
                    bpy.data.collections.remove(coll)
            except Exception:
                pass
    for n in KNOWN_LINE_MATS:
        if n not in names:
            names.append(n)
    _traffic_mat_cache[:] = names
    return list(names)


def _mat_ok(m):
    """★ 材质还活着吗（Ctrl+Z 会回收材质 ⇒ 失效引用喂给 Blender 会崩）"""
    import bpy
    try:
        return (m is not None) and (m.name in bpy.data.materials)
    except (ReferenceError, RuntimeError):
        return False


def import_asset_materials(settings, prefs=None):
    """点「开始使用」/「重新导入」时：把资产里的默认材质 append 进当前文件。返回导入的名字。"""
    import bpy
    lib = getattr(settings, "asset_lib", "") or ""
    want = []
    if prefs is not None:
        want = [prefs.line_white, prefs.line_center, prefs.line_lane, prefs.road_mat, prefs.side_mat]
    want += ["Road_Builder_Whiteline", "Road_Builder_Yellowline",
             "Road_Builder_Aspha01", "Road_Builder_Sidewalk"]
    got = []
    for name in want:
        if not name:
            continue
        if bpy.data.materials.get(name) is not None:
            if name not in got:
                got.append(name)
            continue
        if lib and os.path.exists(lib):
            try:
                with bpy.data.libraries.load(lib, link=False) as (src, dst):
                    dst.materials = [name]
                if dst.materials:
                    got.append(name)
            except Exception:
                pass
    return got


def ensure_line_materials(settings, prefs=None):
    """把三个材质框填上（指针版；用前验证，失效就重填）。"""
    import bpy
    pairs = []
    if prefs is not None:
        pairs = [(settings, "edgeline_obj", prefs.line_white),
                 (settings, "centerline_obj", prefs.line_center),
                 (settings, "laneline_obj", prefs.line_lane),
                 (settings, "road_mat_name", prefs.road_mat),
                 (settings, "sidewalk_mat_name", prefs.side_mat)]
    else:
        pairs = [(settings, "edgeline_obj", "Road_Builder_Whiteline"),
                 (settings, "centerline_obj", "Road_Builder_Yellowline"),
                 (settings, "laneline_obj", "Road_Builder_Whiteline"),
                 (settings, "road_mat_name", "Road_Builder_Aspha01"),
                 (settings, "sidewalk_mat_name", "Road_Builder_Sidewalk")]
    changed = False
    for obj, attr, name in pairs:
        cur = None
        try:
            cur = getattr(obj, attr, None)
        except (ReferenceError, RuntimeError):
            cur = None
        if _mat_ok(cur):
            continue
        if cur is not None:
            try:
                setattr(obj, attr, None)
            except Exception:
                pass
        m = bpy.data.materials.get(name)
        if m is None:
            lib = getattr(settings, "asset_lib", "") or ""
            if lib and os.path.exists(lib):
                try:
                    with bpy.data.libraries.load(lib, link=False) as (src, dst):
                        dst.materials = [name]
                    m = dst.materials[0] if dst.materials else None
                except Exception:
                    m = None
        if m is not None:
            try:
                setattr(obj, attr, m)
                changed = True
            except Exception:
                pass
    return changed


def _seg_dist2(px, py, ax, ay, bx, by):
    """点到线段的距离平方（用于加速筛选）"""
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    if L2 < 1e-12:
        return (px - ax) ** 2 + (py - ay) ** 2
    t = ((px - ax) * dx + (py - ay) * dy) / L2
    t = 0.0 if t < 0.0 else (1.0 if t > 1.0 else t)
    qx, qy = ax + dx * t, ay + dy * t
    return (px - qx) ** 2 + (py - qy) ** 2


def _relevant(ax, ay, bx, by, xwalk_slots, intersections, gap, depth):
    """★加速：只保留「有可能影响这条边」的斑马线槽/路口。

    纯【保守】筛选（reach 给得足够大）——被丢掉的项对这条边上任何点
    都不可能命中，所以结果与全量遍历【逐位一致】。
    """
    sl, il = [], []
    for s in xwalk_slots:
        pt, u, rw, z = s[:4]
        reach = max(rw, depth, gap, 4.0) + 15.0
        if _seg_dist2(pt[0], pt[1], ax, ay, bx, by) <= reach * reach:
            sl.append(s)
    for it in intersections:
        vx, vy, tau = it[-3:]
        reach = tau + 20.0
        if _seg_dist2(vx, vy, ax, ay, bx, by) <= reach * reach:
            il.append(it)
    return sl, il


def _near_intersection(mx, my, inters, eps=0.05):
    """点是否在路口「核心区」里（离路口顶点 tau 以内 = 交叉口圆角那圈）"""
    for _it in inters:
        vx, vy, tau = _it[-3:]
        if math.hypot(mx - vx, my - vy) <= tau + eps:
            return True
    return False


def _xwalk_lo(pt, u, inters, pad=0.02):
    """这条斑马线往「路口方向」该让开多远：用对应路口顶点的 tau（找不到就退回 pad）"""
    if not inters:
        return -pad
    best = None
    for _it in inters:
        vx, vy, tau = _it[-3:]
        dx, dy = pt[0] - vx, pt[1] - vy
        along = dx * u[0] + dy * u[1]
        across = abs(dx * -u[1] + dy * u[0])
        if across < 1.0 and along > 0:
            if best is None or abs(along - tau) < abs(best - tau):
                best = along
    return -(best if best is not None else pad)


def _in_xwalk_band(mx, my, xwalk_slots, gap, depth, pad=0.02, inters=()):
    """点是否落在「路口核心 + 斑马线」覆盖的路段区间内（从路口顶点一直算到斑马线外侧）

    下界用对应路口的 tau —— 这样路口核心圆盘与斑马线之间那条缝也会被盖住，
    不会残留一小段边线（那正是「斑马线两边多出两小段白线」的原因）。
    """
    for _s in xwalk_slots:
        pt, u, rw, z = _s[:4]
        dx, dy = mx - pt[0], my - pt[1]
        d_along = dx * u[0] + dy * u[1]
        d_across = abs(dx * -u[1] + dy * u[0])
        lo = _xwalk_lo(pt, u, inters, pad)
        if lo - 1e-9 <= d_along <= gap + depth + pad and d_across <= rw * 1.05:
            return True
    return False


def build_edge_lines(verts, faces, inset=0.2, width=0.15, lift=0.01,
                     xwalk_slots=(), xwalk_gap=0.3, xwalk_depth=5.333,
                     intersections=(), tile=2.0):
    """白线几何。返回 (lv, lf, luv, info)

    · 沿边界累积弧长做 UV → 整条线连续（转弯处不断开）
    · 路口核心区整条边跳过
    · 斑马线区间按采样切断
    """
    lv, lf, luv = [], [], []
    info = {'quads': 0, 'runs': 0, 'length': 0.0, 'skip_inter_edges': 0, 'skip_xwalk_seg': 0}
    hw = width * 0.5
    off = inset + hw

    for loop in loops_of(verts, faces):
        P, Nin, Nout = loop_points(verts, loop)
        m = len(P)
        if m < 3:
            continue
        N, Q = [], []
        for k in range(m):
            n = (Nin[k][0] + Nout[k][0], Nin[k][1] + Nout[k][1])
            L = math.hypot(n[0], n[1])
            n = Nin[k] if L < 1e-9 else (n[0] / L, n[1] / L)
            N.append(n)
            Q.append((P[k][0] - n[0] * off, P[k][1] - n[1] * off))
        s = [0.0]
        for k in range(m):
            k2 = (k + 1) % m
            s.append(s[-1] + math.hypot(P[k2][0] - P[k][0], P[k2][1] - P[k][1]))
        za = [verts[loop[k][0]][2] if len(verts[loop[k][0]]) > 2 else 0.0 for k in range(m)]

        for k in range(m):
            k2 = (k + 1) % m
            L = s[k + 1] - s[k]
            if L < 1e-6:
                continue
            mx = (P[k][0] + P[k2][0]) * 0.5
            my = (P[k][1] + P[k2][1]) * 0.5
            if _near_intersection(mx, my, intersections):
                info['skip_inter_edges'] += 1
                continue

            def pt(t, sgn):
                qx = Q[k][0] + (Q[k2][0] - Q[k][0]) * t
                qy = Q[k][1] + (Q[k2][1] - Q[k][1]) * t
                nx = N[k][0] + (N[k2][0] - N[k][0]) * t
                ny = N[k][1] + (N[k2][1] - N[k][1]) * t
                nl = math.hypot(nx, ny) or 1.0
                nx, ny = nx / nl, ny / nl
                z = za[k] + (za[k2] - za[k]) * t + lift
                return (qx + nx * hw * sgn, qy + ny * hw * sgn, z)

            _sl, _il = _relevant(P[k][0], P[k][1], P[k2][0], P[k2][1],
                                  xwalk_slots, intersections, xwalk_gap, xwalk_depth)
            ns = max(2, int(L / 0.04) + 1)
            segs, prev = [], None
            for i in range(ns + 1):
                t = i / float(ns)
                px = P[k][0] + (P[k2][0] - P[k][0]) * t
                py = P[k][1] + (P[k2][1] - P[k][1]) * t
                ok = not _in_xwalk_band(px, py, _sl, xwalk_gap, xwalk_depth,
                                    0.02, _il)
                if ok and prev is None:
                    prev = t
                elif not ok and prev is not None:
                    segs.append((prev, t))
                    prev = None
            if prev is not None:
                segs.append((prev, 1.0))
            if not segs:
                info['skip_xwalk_seg'] += 1
                continue
            info['runs'] += 1
            for (ta, tb) in segs:
                if (tb - ta) * L < 0.02:
                    continue
                a1, a2, a3, a4 = pt(ta, +1), pt(tb, +1), pt(tb, -1), pt(ta, -1)
                i0 = len(lv); lv.append(a1)
                i1 = len(lv); lv.append(a2)
                i2 = len(lv); lv.append(a3)
                i3 = len(lv); lv.append(a4)
                quad = [i0, i1, i2, i3]
                a2s = 0.0
                for t2 in range(4):
                    x1, y1 = lv[quad[t2]][:2]
                    x2, y2 = lv[quad[(t2 + 1) % 4]][:2]
                    a2s += x1 * y2 - x2 * y1
                if a2s < 0:
                    quad = [i3, i2, i1, i0]
                lf.append(quad)
                ua, ub = (s[k] + ta * L) / tile, (s[k] + tb * L) / tile
                luv.append([(ua, 1.0), (ub, 1.0), (ub, 0.0), (ua, 0.0)])
                info['quads'] += 1
                info['length'] += (tb - ta) * L
    return lv, lf, luv, info


def build_center_lines(verts, edges, intersections=(), xwalk_slots=(),
                       xwalk_gap=0.3, xwalk_depth=5.333, width=0.15, sep=0.03,
                       lift=0.01, tile=2.0, road_w=8.0, radius_ratio=0.5,
                       arc_segments=8):
    """双黄线几何（沿网格边 = 路段中心线，左右各一条）。返回 (lv, lf, luv, info)"""
    lv, lf, luv = [], [], []
    info = {'quads': 0, 'length': 0.0, 'skip_inter': 0, 'skip_xwalk': 0}
    hw = width * 0.5
    off = (width + sep) * 0.5
    tail = xwalk_gap + xwalk_depth

    adj = {}
    for (ia0, ib0) in edges:
        adj.setdefault(ia0, []).append(ib0)
        adj.setdefault(ib0, []).append(ia0)
    r_in = radius_ratio * road_w
    r_mid = r_in + road_w * 0.5
    bends, bend_cuts = [], []
    bend_ids = []
    for v, nb in adj.items():
        if len(nb) != 2:
            continue
        vx, vy = verts[v][0], verts[v][1]
        u1 = _unit(verts[nb[0]][0] - vx, verts[nb[0]][1] - vy)
        u2 = _unit(verts[nb[1]][0] - vx, verts[nb[1]][1] - vy)
        if u1 is None or u2 is None:
            continue
        cr = u1[0] * u2[1] - u1[1] * u2[0]
        dt = u1[0] * u2[0] + u1[1] * u2[1]
        a_ccw = math.atan2(cr, dt)
        if a_ccw < 0:
            a_ccw += 2 * math.pi
        if a_ccw > math.pi:
            ui, uj, theta = u2, u1, 2 * math.pi - a_ccw
        else:
            ui, uj, theta = u1, u2, a_ccw
        if theta < 1e-6 or theta > math.pi - 1e-6:
            continue
        cot = math.cos(theta * 0.5) / math.sin(theta * 0.5)
        rad = road_w * 0.5 + r_in
        ni = (-ui[1], ui[0])
        nj = (-uj[1], uj[0])
        O = (vx + rad * (cot * ui[0] + ni[0]), vy + rad * (cot * ui[1] + ni[1]))
        z = verts[v][2] if len(verts[v]) > 2 else 0.0
        bends.append((O, r_mid, ui, uj, ni, nj, vx, vy, z))
        bend_ids.append(v)
        bend_cuts.append((vx, vy, rad * cot))

    for (ia, ib) in edges:
        va, vb = verts[ia], verts[ib]
        ax, ay = va[0], va[1]
        bx, by = vb[0], vb[1]
        za = va[2] if len(va) > 2 else 0.0
        zb = vb[2] if len(vb) > 2 else 0.0
        L = math.hypot(bx - ax, by - ay)
        if L < 1e-6:
            continue
        ux, uy = (bx - ax) / L, (by - ay) / L
        t0, t1 = 0.0, L
        for (vx, vy, tau) in intersections:
            if math.hypot(ax - vx, ay - vy) < 1e-6:
                t0 = max(t0, tau + tail)
            if math.hypot(bx - vx, by - vy) < 1e-6:
                t1 = min(t1, L - tau - tail)
        for (vx, vy, dtan) in bend_cuts:
            if math.hypot(ax - vx, ay - vy) < 1e-6:
                t0 = max(t0, dtan)
            if math.hypot(bx - vx, by - vy) < 1e-6:
                t1 = min(t1, L - dtan)
        if t1 - t0 < 0.05:
            info['skip_inter'] += 1
            continue
        _sl, _il = _relevant(ax, ay, bx, by, xwalk_slots, intersections,
                              xwalk_gap, xwalk_depth)
        ns = max(2, int(L / 0.04) + 1)
        segs, prev = [], None
        for i in range(ns + 1):
            t = i / float(ns)
            if t < t0 / L - 1e-9 or t > t1 / L + 1e-9:
                if prev is not None:
                    segs.append((prev, t))
                    prev = None
                continue
            px, py = ax + (bx - ax) * t, ay + (by - ay) * t
            ok = (not _in_xwalk_band(px, py, _sl, xwalk_gap, xwalk_depth,
                                     0.02, _il)
                  and not _near_intersection(px, py, _il))
            if ok and prev is None:
                prev = t
            elif not ok and prev is not None:
                segs.append((prev, t))
                prev = None
        if prev is not None:
            segs.append((prev, 1.0))
        if not segs:
            info['skip_xwalk'] += 1
            continue
        for (ta, tb) in segs:
            if (tb - ta) * L < 0.02:
                continue
            for sgn in (+1.0, -1.0):
                def corner(t, ss):
                    cx = ax + (bx - ax) * t - uy * off * ss
                    cy = ay + (by - ay) * t + ux * off * ss
                    z = za + (zb - za) * t + lift
                    nx, ny = -uy * ss, ux * ss
                    return ((cx + nx * hw, cy + ny * hw, z), (cx - nx * hw, cy - ny * hw, z))
                c1, c2 = corner(ta, sgn), corner(tb, sgn)
                i0 = len(lv); lv.append(c1[0])
                i1 = len(lv); lv.append(c2[0])
                i2 = len(lv); lv.append(c2[1])
                i3 = len(lv); lv.append(c1[1])
                quad = [i0, i1, i2, i3]
                a2 = 0.0
                for t2 in range(4):
                    x1, y1 = lv[quad[t2]][:2]
                    x2, y2 = lv[quad[(t2 + 1) % 4]][:2]
                    a2 += x1 * y2 - x2 * y1
                if a2 < 0:
                    quad = [i3, i2, i1, i0]
                lf.append(quad)
                ua, ub = (ta * L) / tile, (tb * L) / tile
                luv.append([(ua, 1.0), (ub, 1.0), (ub, 0.0), (ua, 0.0)])
                info['quads'] += 1
                info['length'] += (tb - ta) * L
    for (O, Rm, ui, uj, ni, nj, vx, vy, z) in bends:
        for (si, sj) in ((+1.0, -1.0), (-1.0, +1.0)):
            R = Rm - off if si > 0 else Rm + off
            Pi = (vx + si * off * ni[0], vy + si * off * ni[1])
            Pj = (vx + sj * off * nj[0], vy + sj * off * nj[1])
            t_i = (O[0] - Pi[0]) * ui[0] + (O[1] - Pi[1]) * ui[1]
            Ti = (Pi[0] + ui[0] * t_i, Pi[1] + ui[1] * t_i)
            t_j = (O[0] - Pj[0]) * uj[0] + (O[1] - Pj[1]) * uj[1]
            Tj = (Pj[0] + uj[0] * t_j, Pj[1] + uj[1] * t_j)
            a1 = math.atan2(Ti[1] - O[1], Ti[0] - O[0])
            a2 = math.atan2(Tj[1] - O[1], Tj[0] - O[0])
            da = a2 - a1
            while da > math.pi:
                da -= 2 * math.pi
            while da < -math.pi:
                da += 2 * math.pi
            n = max(3, int(abs(da) / (math.pi / 2.0) * arc_segments) + 1)
            arc_len = abs(da) * R
            for k in range(n):
                aA = a1 + da * k / float(n)
                aB = a1 + da * (k + 1) / float(n)
                ca, sa = math.cos(aA), math.sin(aA)
                cb, sb = math.cos(aB), math.sin(aB)
                p1 = (O[0] + (R + hw) * ca, O[1] + (R + hw) * sa, z + lift)
                p2 = (O[0] + (R + hw) * cb, O[1] + (R + hw) * sb, z + lift)
                p3 = (O[0] + (R - hw) * cb, O[1] + (R - hw) * sb, z + lift)
                p4 = (O[0] + (R - hw) * ca, O[1] + (R - hw) * sa, z + lift)
                i0 = len(lv); lv.append(p1)
                i1 = len(lv); lv.append(p2)
                i2 = len(lv); lv.append(p3)
                i3 = len(lv); lv.append(p4)
                quad = [i0, i1, i2, i3]
                a2s = 0.0
                for t2 in range(4):
                    x1, y1 = lv[quad[t2]][:2]
                    x2, y2 = lv[quad[(t2 + 1) % 4]][:2]
                    a2s += x1 * y2 - x2 * y1
                if a2s < 0:
                    quad = [i3, i2, i1, i0]
                lf.append(quad)
                ua = (k * arc_len / n) / tile
                ub = ((k + 1) * arc_len / n) / tile
                luv.append([(ua, 1.0), (ub, 1.0), (ub, 0.0), (ua, 0.0)])
                info['quads'] += 1
                info['bend_arcs'] = info.get('bend_arcs', 0) + 1
    info['bends'] = [(bend_ids[i],) + bends[i] for i in range(len(bends))]
    info['bend_cuts'] = list(bend_cuts)
    return lv, lf, luv, info


def _make_line_object(target_coll, lv, lf, luv, blend_path, asset_name,
                      name, tag="rb_edgeline"):
    """按资产材质建一个线物体。返回 (材质名列表, 错误)"""
    import bpy
    o, err = load_object(blend_path, asset_name)
    if err or o is None:
        return [], err or "没取到线资产 %s" % asset_name
    me = bpy.data.meshes.new(name)
    me.from_pydata([tuple(v) for v in lv], [], [list(f) for f in lf])
    me.validate(verbose=False)
    me.update()
    uv = me.uv_layers.new(name="UVMap")
    for i, poly in enumerate(me.polygons):
        for j, li in enumerate(poly.loop_indices):
            uv.data[li].uv = luv[i][j % 4]
    mats = [m for m in (o.data.materials or []) if m]
    for m in mats:
        me.materials.append(m)
    new = bpy.data.objects.new(name, me)
    new[tag] = 1
    target_coll.objects.link(new)
    return [m.name for m in mats], ""


def place_edge_lines(target_coll, verts, faces, xwalk_slots, blend_path, obj_name,
                     inset=0.2, width=0.15, lift=0.01, tile=2.0,
                     xwalk_gap=0.3, xwalk_depth=5.333, intersections=(),
                     name="RB_EdgeLine"):
    lv, lf, luv, info = build_edge_lines(verts, faces, inset, width, lift,
                                         xwalk_slots, xwalk_gap, xwalk_depth,
                                         intersections, tile)
    if not lf:
        return info, ""
    mats, err = _make_line_object(target_coll, lv, lf, luv, blend_path, obj_name, name)
    info['material'] = mats
    return info, err


def place_center_lines(target_coll, verts, edges, xwalk_slots, intersections,
                       blend_path, obj_name, width=0.15, sep=0.03, lift=0.01,
                       xwalk_gap=0.3, xwalk_depth=5.333, tile=2.0,
                       road_w=8.0, radius_ratio=0.5, arc_segments=8,
                       name="RB_CenterLine", **ignored):
    lv, lf, luv, info = build_center_lines(verts, edges, intersections, xwalk_slots,
                                           xwalk_gap, xwalk_depth, width, sep, lift, tile,
                                           road_w, radius_ratio, arc_segments)
    if not lf:
        return info, ""
    mats, err = _make_line_object(target_coll, lv, lf, luv, blend_path, obj_name, name)
    info['material'] = mats
    return info, err

def _unit(dx, dy):
    L = math.hypot(dx, dy)
    return None if L < 1e-9 else (dx / L, dy / L)


def build_lane_lines(verts, edges, intersections=(), xwalk_slots=(),
                     xwalk_gap=0.3, xwalk_depth=5.333, width=0.15,
                     lane_ratio=0.5, dash=2.0, gap_len=4.0, lift=0.01,
                     road_w=8.0, radius_ratio=0.5, arc_segments=8, tile=2.0):
    """车道虚线：在半边路（黄线与白边线之间）的中线上，一段段地铺白线。

    和双黄线同样的让开规则（路口核心 + 斑马线），但输出是「一段段」的：
    每段长 dash、间隔 gap_len，沿路连续排下去；转弯处沿圆弧排虚线。
    返回 (lv, lf, luv, info)
    """
    lv, lf, luv = [], [], []
    info = {'quads': 0, 'length': 0.0, 'dashes': 0, 'skip_inter': 0, 'skip_xwalk': 0, 'bend_dashes': 0}
    hw = width * 0.5
    lane_off = road_w * 0.5 * lane_ratio
    tail = xwalk_gap + xwalk_depth
    r_in = radius_ratio * road_w
    r_mid = r_in + road_w * 0.5
    stride = dash + gap_len

    adj = {}
    for (ia0, ib0) in edges:
        adj.setdefault(ia0, []).append(ib0)
        adj.setdefault(ib0, []).append(ia0)
    bends, bend_cuts = [], []
    for v, nb in adj.items():
        if len(nb) != 2:
            continue
        vx, vy = verts[v][0], verts[v][1]
        u1 = _unit(verts[nb[0]][0] - vx, verts[nb[0]][1] - vy)
        u2 = _unit(verts[nb[1]][0] - vx, verts[nb[1]][1] - vy)
        if u1 is None or u2 is None:
            continue
        cr = u1[0] * u2[1] - u1[1] * u2[0]
        dt = u1[0] * u2[0] + u1[1] * u2[1]
        a_ccw = math.atan2(cr, dt)
        if a_ccw < 0:
            a_ccw += 2 * math.pi
        if a_ccw > math.pi:
            ui, uj, theta = u2, u1, 2 * math.pi - a_ccw
        else:
            ui, uj, theta = u1, u2, a_ccw
        if theta < 1e-6 or theta > math.pi - 1e-6:
            continue
        cot = math.cos(theta * 0.5) / math.sin(theta * 0.5)
        rad = road_w * 0.5 + r_in
        ni = (-ui[1], ui[0])
        nj = (-uj[1], uj[0])
        O = (vx + rad * (cot * ui[0] + ni[0]), vy + rad * (cot * ui[1] + ni[1]))
        z = verts[v][2] if len(verts[v]) > 2 else 0.0
        bends.append((O, r_mid, ui, uj, ni, nj, vx, vy, z))
        bend_cuts.append((vx, vy, rad * cot))

    def _emit(p0, p1, n0, n1, za, zb, u0, u1):
        """两点之间（含横向宽）输出一个四边形；u0/u1 是沿线的 UV"""
        a1 = (p0[0] + n0[0] * hw, p0[1] + n0[1] * hw, za)
        a2 = (p1[0] + n1[0] * hw, p1[1] + n1[1] * hw, zb)
        a3 = (p1[0] - n1[0] * hw, p1[1] - n1[1] * hw, zb)
        a4 = (p0[0] - n0[0] * hw, p0[1] - n0[1] * hw, za)
        i0 = len(lv); lv.append(a1)
        i1 = len(lv); lv.append(a2)
        i2 = len(lv); lv.append(a3)
        i3 = len(lv); lv.append(a4)
        quad = [i0, i1, i2, i3]
        s = 0.0
        for t in range(4):
            x1, y1 = lv[quad[t]][:2]
            x2, y2 = lv[quad[(t + 1) % 4]][:2]
            s += x1 * y2 - x2 * y1
        if s < 0:
            quad = [i3, i2, i1, i0]
        lf.append(quad)
        luv.append([(u0, 1.0), (u1, 1.0), (u1, 0.0), (u0, 0.0)])
        info['quads'] += 1

    for (ia, ib) in edges:
        va, vb = verts[ia], verts[ib]
        ax, ay, bx, by = va[0], va[1], vb[0], vb[1]
        za0 = va[2] if len(va) > 2 else 0.0
        zb0 = vb[2] if len(vb) > 2 else 0.0
        L = math.hypot(bx - ax, by - ay)
        if L < 1e-6:
            continue
        ux, uy = (bx - ax) / L, (by - ay) / L
        t0, t1 = 0.0, L
        for (vx, vy, tau) in intersections:
            if math.hypot(ax - vx, ay - vy) < 1e-6:
                t0 = max(t0, tau + tail)
            if math.hypot(bx - vx, by - vy) < 1e-6:
                t1 = min(t1, L - tau - tail)
        for (vx, vy, dtan) in bend_cuts:
            if math.hypot(ax - vx, ay - vy) < 1e-6:
                t0 = max(t0, dtan)
            if math.hypot(bx - vx, by - vy) < 1e-6:
                t1 = min(t1, L - dtan)
        if t1 - t0 < 0.05:
            info['skip_inter'] += 1
            continue
        _sl, _il = _relevant(ax, ay, bx, by, xwalk_slots, intersections,
                              xwalk_gap, xwalk_depth)
        ns = max(2, int(L / 0.04) + 1)
        segs, prev = [], None
        for i in range(ns + 1):
            t = i / float(ns)
            if t < t0 / L - 1e-9 or t > t1 / L + 1e-9:
                if prev is not None:
                    segs.append((prev, t)); prev = None
                continue
            px, py = ax + (bx - ax) * t, ay + (by - ay) * t
            ok = not _in_xwalk_band(px, py, _sl, xwalk_gap, xwalk_depth,
                                    0.02, _il)
            if ok and prev is None:
                prev = t
            elif not ok and prev is not None:
                segs.append((prev, t)); prev = None
        if prev is not None:
            segs.append((prev, 1.0))
        if not segs:
            info['skip_xwalk'] += 1
            continue
        for (ta, tb) in segs:
            s0, s1 = ta * L, tb * L
            x = s0
            while x < s1 - 1e-6:
                d = min(dash, s1 - x)
                if d < 0.35 * dash and x > s0 + 1e-6:
                    break
                for sgn in (+1.0, -1.0):
                    p0 = (ax + ux * x - uy * lane_off * sgn, ay + uy * x + ux * lane_off * sgn)
                    p1 = (ax + ux * (x + d) - uy * lane_off * sgn, ay + uy * (x + d) + ux * lane_off * sgn)
                    nvec = (-uy * sgn, ux * sgn)
                    za = za0 + (zb0 - za0) * (x / L) + lift
                    zb = za0 + (zb0 - za0) * ((x + d) / L) + lift
                    _emit(p0, p1, nvec, nvec, za, zb, 0.0, d / max(tile, 1e-6))
                    info['dashes'] += 1
                    info['length'] += d
                x += stride

    for (O, Rm, ui, uj, ni, nj, vx, vy, z) in bends:
        for (si, sj) in ((+1.0, -1.0), (-1.0, +1.0)):
            R = Rm - lane_off if si > 0 else Rm + lane_off
            Pi = (vx + si * lane_off * ni[0], vy + si * lane_off * ni[1])
            Pj = (vx + sj * lane_off * nj[0], vy + sj * lane_off * nj[1])
            t_i = (O[0] - Pi[0]) * ui[0] + (O[1] - Pi[1]) * ui[1]
            Ti = (Pi[0] + ui[0] * t_i, Pi[1] + ui[1] * t_i)
            t_j = (O[0] - Pj[0]) * uj[0] + (O[1] - Pj[1]) * uj[1]
            Tj = (Pj[0] + uj[0] * t_j, Pj[1] + uj[1] * t_j)
            a1 = math.atan2(Ti[1] - O[1], Ti[0] - O[0])
            a2 = math.atan2(Tj[1] - O[1], Tj[0] - O[0])
            da = a2 - a1
            while da > math.pi:
                da -= 2 * math.pi
            while da < -math.pi:
                da += 2 * math.pi
            arc_len = abs(da) * R
            x = 0.0
            while x < arc_len - 1e-6:
                d = min(dash, arc_len - x)
                if d < 0.35 * dash and x > 1e-6:
                    break
                ka = x / R
                kb = (x + d) / R
                aa = a1 + da * (ka / abs(da))
                ab = a1 + da * (kb / abs(da))
                ca, sa = math.cos(aa), math.sin(aa)
                cb, sb = math.cos(ab), math.sin(ab)
                p0 = (O[0] + R * ca, O[1] + R * sa)
                p1 = (O[0] + R * cb, O[1] + R * sb)
                n0 = (ca, sa)
                n1 = (cb, sb)
                _emit(p0, p1, n0, n1, z + lift, z + lift, 0.0, d / max(tile, 1e-6))
                info['dashes'] += 1
                info['bend_dashes'] += 1
                info['length'] += d
                x += stride
    return lv, lf, luv, info


def place_lane_lines(target_coll, verts, edges, xwalk_slots, intersections,
                     blend_path, obj_name, width=0.15, lane_ratio=0.5,
                     dash=2.0, gap_len=4.0, lift=0.01, road_w=8.0,
                     radius_ratio=0.5, arc_segments=8, xwalk_gap=0.3,
                     xwalk_depth=5.333, tile=2.0, name="RB_LaneLine", **ignored):
    lv, lf, luv, info = build_lane_lines(verts, edges, intersections, xwalk_slots,
                                         xwalk_gap, xwalk_depth, width, lane_ratio,
                                         dash, gap_len, lift, road_w, radius_ratio,
                                         arc_segments, tile)
    if not lf:
        return info, ""
    mats, err = _make_line_object(target_coll, lv, lf, luv, blend_path, obj_name, name)
    info['material'] = mats
    return info, err