
import math
import os


def get_material(blend_path, mat_name):
    import bpy
    mat = bpy.data.materials.get(mat_name)
    if mat is not None:
        return mat, ""
    if not blend_path or not os.path.exists(blend_path):
        return None, "找不到材质 %s，且资产库路径不可用" % mat_name
    try:
        with bpy.data.libraries.load(blend_path, link=True) as (src, dst):
            if mat_name not in (src.materials or []):
                return None, "库里没有材质 %s（库里有的：%s）" % (mat_name, list(src.materials)[:12])
            dst.materials = [mat_name]
        mat = bpy.data.materials.get(mat_name)
        if mat is None and dst.materials:
            mat = dst.materials[0]
    except Exception as e:
        return None, "读材质库失败：%s" % e
    return (mat, "") if mat else (None, "link 之后找不到材质 %s" % mat_name)


def make_other_material(name="RB_default"):
    import bpy
    mat = bpy.data.materials.get(name)
    if mat is not None:
        return mat
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (0.62, 0.62, 0.60, 1.0)
        if "Roughness" in bsdf.inputs:
            bsdf.inputs["Roughness"].default_value = 0.85
    mat.diffuse_color = (0.62, 0.62, 0.60, 1.0)
    return mat


def assign_materials(me, n_road, n_side, n_block, road_mat, side_mat=None,
                     other_mat=None, uv_scale=4.0):
    if other_mat is None:
        other_mat = make_other_material()
    if side_mat is None:
        side_mat = make_other_material("RB_side_default")
    me.materials.clear()
    me.materials.append(road_mat if road_mat else other_mat)
    me.materials.append(side_mat)
    me.materials.append(other_mat)
    i0 = max(0, int(n_road))
    i1 = i0 + max(0, int(n_side)) + max(0, int(n_block))
    n = len(me.polygons)
    for i, p in enumerate(me.polygons):
        p.material_index = 0 if i < i0 else (1 if i < i1 else 2)

    uv = me.uv_layers.get("UVMap") or me.uv_layers.new(name="UVMap")
    data = uv.data
    s = uv_scale if uv_scale and uv_scale > 1e-6 else 4.0
    for p in me.polygons:
        nx, ny, nz = p.normal
        ax = max(range(3), key=lambda k: abs((nx, ny, nz)[k]))
        for li in p.loop_indices:
            co = me.vertices[me.loops[li].vertex_index].co
            if ax == 0:
                u, v = co.y / s, co.z / s
            elif ax == 1:
                u, v = co.x / s, co.z / s
            else:
                u, v = co.x / s, co.y / s
            data[li].uv = (u, v)
    return {'road_faces': i0, 'side_faces': i1 - i0, 'other_faces': max(0, n - i1)}


def assign_road_material(me, n_road_faces, road_mat, other_mat=None, uv_scale=4.0):
    return assign_materials(me, n_road_faces, 0, 0, road_mat, None, other_mat, uv_scale)

    if other_mat is None:
        other_mat = make_other_material()
    me.materials.clear()
    me.materials.append(road_mat)
    me.materials.append(other_mat)
    n = len(me.polygons)
    for i, p in enumerate(me.polygons):
        p.material_index = 0 if i < n_road_faces else 1

    uv = me.uv_layers.get("UVMap") or me.uv_layers.new(name="UVMap")
    data = uv.data
    s = uv_scale if uv_scale and uv_scale > 1e-6 else 4.0
    for p in me.polygons:
        nx, ny, nz = p.normal
        ax = max(range(3), key=lambda k: abs((nx, ny, nz)[k]))
        for li in p.loop_indices:
            co = me.vertices[me.loops[li].vertex_index].co
            if ax == 0:
                u, v = co.y / s, co.z / s
            elif ax == 1:
                u, v = co.x / s, co.z / s
            else:
                u, v = co.x / s, co.y / s
            data[li].uv = (u, v)
    return {'road_faces': min(n_road_faces, n), 'other_faces': max(0, n - n_road_faces)}