import bpy
import os
import shutil

from .road_surface import build_road_surface



def _node_group_name():
    return "RoadBuilder"


def _inp(node, name):
    for s in node.inputs:
        if s.name == name:
            return s
    raise KeyError(f"{node.bl_idname} 无输入 socket {name!r}")


def _out(node, name):
    for s in node.outputs:
        if s.name == name:
            return s
    raise KeyError(f"{node.bl_idname} 无输出 socket {name!r}")


def create_road_node_group():
    """创建道路生成节点图（网格边 → 道路路面）。

    原理：道路 = 网格的边（边 = 道路中心线，顶点 = 交叉口）。
    1. Mesh to Curve：把网格的边变成曲线（挤出顶点 = 新增边 = 新路）。
    2. Fillet Curve：在拐角自动圆角（半径 = 路宽，内圈也圆角）。
    3. Curve to Mesh：用剖面沿法线扫掠成路面（宽度 = 路宽）。
    """
    ng = bpy.data.node_groups.new(_node_group_name(), type='GeometryNodeTree')

    ng.interface.new_socket("Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    ng.interface.new_socket("Road Width", in_out='INPUT', socket_type='NodeSocketFloat')
    ng.interface.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')

    nodes = ng.nodes
    links = ng.links

    group_in = nodes.new('NodeGroupInput')
    group_out = nodes.new('NodeGroupOutput')

    mesh_to_curve = nodes.new('GeometryNodeMeshToCurve')

    fillet = nodes.new('GeometryNodeFilletCurve')
    fillet.mode = 'POLY'
    _inp(fillet, 'Count').default_value = 8

    math_half = nodes.new('ShaderNodeMath')
    math_half.operation = 'DIVIDE'
    math_half.inputs[1].default_value = 2.0

    profile = nodes.new('GeometryNodeCurvePrimitiveLine')
    _inp(profile, 'Start').default_value = (-1.0, 0.0, 0.0)
    _inp(profile, 'End').default_value = (1.0, 0.0, 0.0)

    curve_to_mesh = nodes.new('GeometryNodeCurveToMesh')

    links.new(_out(group_in, 'Geometry'), _inp(mesh_to_curve, 'Mesh'))
    links.new(_out(mesh_to_curve, 'Curve'), _inp(fillet, 'Curve'))
    links.new(_out(group_in, 'Road Width'), _inp(fillet, 'Radius'))
    links.new(_out(fillet, 'Curve'), _inp(curve_to_mesh, 'Curve'))
    links.new(_out(profile, 'Curve'), _inp(curve_to_mesh, 'Profile Curve'))
    links.new(_out(math_half, 'Value'), _inp(curve_to_mesh, 'Scale'))
    links.new(_out(group_in, 'Road Width'), math_half.inputs[0])
    links.new(_out(curve_to_mesh, 'Mesh'), _inp(group_out, 'Geometry'))

    return ng


def _set_gn_input(mod, socket_name, value):
    item = mod.node_group.interface.items_tree.get(socket_name)
    if item is not None:
        mod[item.identifier] = value


def build_road(mesh_obj, settings):
    """给网格加 Geometry Nodes，把它的边生成道路。"""
    ng = bpy.data.node_groups.get(_node_group_name())
    if ng is None:
        ng = create_road_node_group()

    mod = mesh_obj.modifiers.get("RoadBuilder")
    if mod is None:
        mod = mesh_obj.modifiers.new("RoadBuilder", type='NODES')
    mod.node_group = ng

    _set_gn_input(mod, 'Road Width', settings.road_width)



def _line_mat(settings, attr):
    """取"线材质指针"（用前验证，失效就返回 None ⇒ 绝不把失效引用交给 Blender）"""
    from .edgeline import _mat_ok
    try:
        m = getattr(settings, attr, None)
    except Exception:
        m = None
    return m if _mat_ok(m) else None


class AddBuildingAsset(bpy.types.Operator):
    """把选中的模型加入建筑资产：后台并进资产文件的集合里（自动备份+校验）"""

    bl_idname = "road_builder.add_building_asset"
    bl_label = "把我的模型加入建筑资产"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        import subprocess
        import tempfile
        s = context.scene.road_builder
        ensure_asset_lib(s)
        lib = s.asset_lib or ""
        collname = s.asset_coll or "Road_Builder_buildings"
        if not (lib and os.path.exists(lib)):
            self.report({'ERROR'}, "资产库路径不可用")
            return {'CANCELLED'}
        objs = [o for o in context.selected_objects if o.type == 'MESH']
        if not objs:
            self.report({'ERROR'}, "请先选中要加入的模型（可多选）")
            return {'CANCELLED'}
        try:
            bak = lib + ".bak_before_addasset"
            if not os.path.exists(bak):
                shutil.copy2(lib, bak)
        except Exception:
            pass
        tmp_dir = tempfile.mkdtemp(prefix="rb_asset_")
        tmp_blend = os.path.join(tmp_dir, "mine.blend")
        try:
            mats = set()
            for o in objs:
                if o.data is not None:
                    for m in o.data.materials:
                        if m:
                            mats.add(m)
            bpy.data.libraries.write(tmp_blend, set(objs) | mats, fake_user=True)
        except Exception as e:
            self.report({'ERROR'}, "写临时文件失败：%s" % e)
            return {'CANCELLED'}
        helper = os.path.join(os.path.dirname(os.path.abspath(__file__)), "add_to_asset.py")
        try:
            kw = {}
            if hasattr(subprocess, "CREATE_NO_WINDOW"):
                kw["creationflags"] = subprocess.CREATE_NO_WINDOW
            r = subprocess.run([bpy.app.binary_path, "--background", lib, "--python", helper,
                                "--", tmp_blend, collname],
                               capture_output=True, text=True, timeout=600, **kw)
        except Exception as e:
            self.report({'ERROR'}, "后台写入失败：%s" % e)
            return {'CANCELLED'}
        out = (r.stdout or "")
        last = [ln for ln in out.splitlines() if ln.startswith("[RB_ASSET]")]
        if r.returncode != 0 or not any("OK" in ln for ln in last):
            self.report({'ERROR'}, "写入资产失败（返回码 %s）" % r.returncode)
            return {'CANCELLED'}
        self.report({'INFO'}, "已加入 %d 个模型到 %s ｜ %s" %
                    (len(objs), collname, last[-2].replace("[RB_ASSET] ", "") if len(last) >= 2 else ""))
        return {'FINISHED'}


def ensure_asset_lib(settings):
    """资产库路径：为空 / 文件不存在时，自动定位到【插件目录旁边的 Road_Builder_ASSET】✓

    这样"资产随插件打包"发到任何电脑、任何路径都能用 ✓
    """
    cur = (getattr(settings, "asset_lib", "") or "").strip()
    if cur and os.path.exists(cur):
        return cur
    here = os.path.dirname(os.path.abspath(__file__))
    cand = os.path.join(here, "Road_Builder_ASSET", "Road_Builder.blend")
    if os.path.exists(cand):
        try:
            settings.asset_lib = cand
        except Exception:
            pass
        return cand
    return cur


def _rb_prefs(context):
    try:
        return context.preferences.addons[__package__.split(".")[0]].preferences
    except Exception:
        return None


class StartUseRoadBuilder(bpy.types.Operator):
    """开始使用：把资产库里的默认材质导入当前文件，并注册资产库"""

    bl_idname = "road_builder.start_use"
    bl_label = "开始使用"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        s = context.scene.road_builder
        ensure_asset_lib(s)
        p = _rb_prefs(context)
        from .edgeline import import_asset_materials, ensure_line_materials
        got = import_asset_materials(s, p)
        ensure_line_materials(s, p)
        try:
            lib = s.asset_lib or ""
            folder = os.path.dirname(lib)
            if folder and os.path.isdir(folder):
                fp = context.preferences.filepaths
                exist = [a.path for a in fp.asset_libraries]
                if folder not in exist:
                    a = fp.asset_libraries.new(name="RoadBuilder 资产", path=folder)
                    self.report({'INFO'}, "已注册资产库：%s" % folder)
        except Exception as e:
            self.report({'WARNING'}, "资产库注册跳过：%s" % e)
        s.rb_started = True
        self.report({'INFO'}, "已导入材质：%s" % "、".join(got))
        return {'FINISHED'}


class ReloadAssetMats(bpy.types.Operator):
    """重新导入资产材质（换了资产或加了新材质时点一下）"""

    bl_idname = "road_builder.reload_asset_mats"
    bl_label = "重新导入资产材质"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        s = context.scene.road_builder
        ensure_asset_lib(s)
        p = _rb_prefs(context)
        from .edgeline import import_asset_materials, ensure_line_materials
        got = import_asset_materials(s, p)
        ensure_line_materials(s, p)
        self.report({'INFO'}, "已导入：%s" % "、".join(got))
        return {'FINISHED'}


class SaveDefaultMat(bpy.types.Operator):
    """把当前材质设为默认：复制进资产文件，并写进插件偏好（重启后依然生效）"""

    bl_idname = "road_builder.save_default_mat"
    bl_label = "设为默认材质"
    bl_options = {'INTERNAL'}

    which: bpy.props.EnumProperty(items=[("WHITE", "道路边线", ""), ("CENTER", "双黄线", ""),
                                         ("LANE", "车道虚线", "")], default="WHITE")

    def execute(self, context):
        s = context.scene.road_builder
        ensure_asset_lib(s)
        p = _rb_prefs(context)
        if p is None:
            self.report({'ERROR'}, "读不到插件偏好设置")
            return {'CANCELLED'}
        attr = {"WHITE": "edgeline_obj", "CENTER": "centerline_obj", "LANE": "laneline_obj"}[self.which]
        from .edgeline import _mat_ok
        try:
            mat = getattr(s, attr, None)
        except Exception:
            mat = None
        if not _mat_ok(mat):
            self.report({'ERROR'}, "这个框里没有有效材质")
            return {'CANCELLED'}
        lib = s.asset_lib or ""
        if not (lib and os.path.exists(lib)):
            self.report({'ERROR'}, "资产库路径不可用")
            return {'CANCELLED'}
        newname = mat.name + "_user"
        try:
            bak = lib + ".bak_before_setdefault"
            if not os.path.exists(bak):
                shutil.copy2(lib, bak)
        except Exception:
            pass
        try:
            tmp_mat = mat.copy()
            tmp_mat.name = newname
            bpy.data.libraries.write(lib, {tmp_mat}, fake_user=True)
            bpy.data.materials.remove(tmp_mat)
        except Exception as e:
            self.report({'ERROR'}, "写入资产失败：%s" % e)
            return {'CANCELLED'}
        if self.which == "WHITE":
            p.line_white = newname; s.edgeline_obj = mat
        elif self.which == "CENTER":
            p.line_center = newname; s.centerline_obj = mat
        else:
            p.line_lane = newname; s.laneline_obj = mat
        self.report({'INFO'}, "已把 %s 设为默认（资产里名为 %s，重启后依然生效）" % (mat.name, newname))
        return {'FINISHED'}


def _apply_line_mat(before, mat):
    """把"刚生成的这批线对象"的材质换成 mat（mat 为空则保持原样）。"""
    import bpy
    if mat is None:
        return
    try:
        if mat.name not in bpy.data.materials:
            return
    except (ReferenceError, RuntimeError):
        return
    for o in bpy.data.objects:
        if o in before or o.type != "MESH" or o.data is None:
            continue
        try:
            if len(o.data.materials) == 0:
                o.data.materials.append(mat)
            else:
                for i in range(len(o.data.materials)):
                    o.data.materials[i] = mat
        except Exception:
            pass


class RefreshLineMats(bpy.types.Operator):
    """重新从资产库读取材质列表（换了资产路径或加了新材质后点一下）"""

    bl_idname = "road_builder.refresh_mats"
    bl_label = "刷新材质列表"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        try:
            from .edgeline import refresh_traffic_mats
            names = refresh_traffic_mats()
            self.report({'INFO'}, "材质列表已刷新：%s" % ", ".join(names[:8]))
        except Exception as e:
            self.report({'ERROR'}, "刷新失败：%s" % e)
        return {'FINISHED'}


class BuildRoadOperator(bpy.types.Operator):
    """根据选中的网格（边 = 道路中心线）生成道路"""
    bl_idname = "road_builder.build_road"
    bl_label = "生成道路"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.road_builder
        mesh = context.active_object

        if mesh is None:
            self.report({'ERROR'}, "请先选中一个网格（边 = 道路）")
            return {'CANCELLED'}
        if mesh.type != 'MESH':
            self.report({'ERROR'}, f"请选中网格物体（当前是 {mesh.type}）")
            return {'CANCELLED'}

        build_road(mesh, settings)
        self.report({'INFO'}, f"已生成道路（宽 {settings.road_width}）")
        return {'FINISHED'}


class BuildRoadSurfaceOperator(bpy.types.Operator):
    """按补片法生成路面：交叉口做圆弧倒角（对标 iCity 几何）

    与几何节点版本的区别：
      · 交叉口不再靠"几条矩形叠在一起"，而是单独算一块补片
        （2×路宽的正方形 + 四角 半径路宽/2 的圆弧，切点距中心 1 个路宽）。
      · 每条路段的端头在距顶点 1 个路宽处截断，所以不会重叠/留缝。
      · 路的拐弯处：内侧半径 路宽/2、外侧半径 1.5×路宽 的同心圆弧。
    代价：一次性算好（不是实时），生成的是新物体。
    """
    bl_idname = "road_builder.build_road_surface"
    bl_label = "生成道路"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.road_builder
        from .blocks import clear_buildings, clear_roads
        from .trafficlight import clear_lights
        clear_buildings()
        clear_roads()
        clear_lights(getattr(settings, "tlight_obj", ""))
        obj = context.active_object

        if obj is None:
            self.report({'ERROR'}, "请先选中一个网格（边 = 道路）")
            return {'CANCELLED'}
        if obj.type != 'MESH':
            self.report({'ERROR'}, f"请选中网格物体（当前是 {obj.type}）")
            return {'CANCELLED'}

        me = obj.data
        if len(me.edges) == 0:
            self.report({'ERROR'}, "网格没有边（边 = 道路中心线）")
            return {'CANCELLED'}

        pts = [(v.co.x, v.co.y) for v in me.vertices]
        zs = [v.co.z for v in me.vertices]
        edges = [(e.vertices[0], e.vertices[1]) for e in me.edges]

        w = settings.road_width
        verts, faces, info = build_road_surface(
            pts, edges, w,
            radius_ratio=settings.corner_radius_ratio,
            arc_segments=settings.corner_segments,
            z=zs,
        )
        pav_verts, pav_faces = verts, faces

        sw_max = max(0.05, settings.road_width)
        sw_w = min(settings.sidewalk_width, sw_max)
        if settings.gen_sidewalk and settings.sidewalk_width > sw_max + 1e-9:
            self.report({'WARNING'}, "人行道宽度 %.2f 超过上限 %.2f（= 路宽），已按 %.2f 生成"
                        % (settings.sidewalk_width, sw_max, sw_w))

        n_road_faces = len(faces)
        n_side_faces = 0
        n_block_faces = 0

        if settings.gen_sidewalk:
            from .sidewalk import build_sidewalk
            base = len(verts)
            sv, svf, sinfo = build_sidewalk(verts, faces, sw_w,
                                            settings.sidewalk_height)
            if sv:
                verts = verts + sv
                faces = faces + [[i + base for i in f] for f in svf]
                info['sidewalk'] = sinfo
                n_side_faces = len(svf)

        from .edgeline import (ensure_line_materials, OBJ_EDGE, OBJ_CENTER, OBJ_LANE)
        ensure_asset_lib(settings)
        ensure_line_materials(settings, _rb_prefs(context))

        if settings.gen_edgeline:
            from .edgeline import place_edge_lines
            col0 = obj.users_collection[0] if obj.users_collection else context.scene.collection
            _before = set(bpy.data.objects)
            einfo, eerr = place_edge_lines(
                col0, pav_verts, pav_faces, info.get('crosswalk_slots', []),
                settings.asset_lib, OBJ_EDGE,
                inset=settings.edgeline_inset, width=settings.edgeline_width,
                lift=settings.edgeline_lift, tile=2.0,
                xwalk_gap=settings.crosswalk_gap,
                xwalk_depth=(4.0 * (settings.road_width / 6.0) * settings.crosswalk_scale
                              + settings.line_xwalk_gap),
                intersections=info.get('intersections', []))
            info['edgeline'] = einfo
            _apply_line_mat(_before, _line_mat(settings, "edgeline_obj"))
            if eerr:
                self.report({'ERROR'}, eerr)

        if settings.gen_tlight:
            from .trafficlight import place_traffic_lights, plan_from_settings
            col0 = obj.users_collection[0] if obj.users_collection else context.scene.collection
            _plan = plan_from_settings(settings)
            tinfo, terr = place_traffic_lights(
                col0, info.get('crosswalk_slots', []), settings.asset_lib,
                settings.tlight_obj, right_side=settings.tlight_right,
                lateral=settings.tlight_lateral, along=settings.tlight_along,
                rot_offset=settings.tlight_rot, scale=settings.tlight_scale,
                lift=settings.tlight_lift,
                intersections=info.get('intersections', []),
                slot_ids=info.get('slot_ids', []),
                phase_mode=settings.tlight_phase,
                cycle=float(settings.tlight_cycle),
                shift=0.0,
                phase_plan=_plan)
            info['tlight'] = tinfo
            info['phase_plan'] = _plan
            if terr:
                self.report({'ERROR'}, terr)
            elif tinfo.get('conflicts'):
                self.report({'WARNING'},
                            "路口相位自检发现 %d 处可能冲突（夹角≥60°的两条进口道同组）"
                            % len(tinfo['conflicts']))

        if settings.gen_laneline:
            from .edgeline import place_lane_lines
            col0 = obj.users_collection[0] if obj.users_collection else context.scene.collection
            _mw = obj.matrix_world
            _vs = [tuple(_mw @ v.co) for v in obj.data.vertices]
            _es = [tuple(e.vertices) for e in obj.data.edges]
            _before = set(bpy.data.objects)
            linfo, lerr = place_lane_lines(
                col0, _vs, _es, info.get('crosswalk_slots', []),
                info.get('intersections', []), settings.asset_lib,
                OBJ_LANE, width=settings.laneline_width,
                lane_ratio=settings.laneline_ratio, dash=settings.laneline_dash,
                gap_len=settings.laneline_gap, lift=settings.laneline_lift,
                road_w=settings.road_width, radius_ratio=settings.corner_radius_ratio,
                arc_segments=settings.corner_segments,
                xwalk_gap=settings.crosswalk_gap,
                xwalk_depth=(4.0 * (settings.road_width / 6.0) * settings.crosswalk_scale
                              + settings.line_xwalk_gap))
            info['laneline'] = linfo
            _apply_line_mat(_before, _line_mat(settings, "laneline_obj"))
            if lerr:
                self.report({'ERROR'}, lerr)

        if settings.gen_centerline:
            from .edgeline import place_center_lines
            col0 = obj.users_collection[0] if obj.users_collection else context.scene.collection
            _mw = obj.matrix_world
            _vs = [tuple(_mw @ v.co) for v in obj.data.vertices]
            _es = [tuple(e.vertices) for e in obj.data.edges]
            _before = set(bpy.data.objects)
            cinfo, cerr = place_center_lines(
                col0, _vs, _es, info.get('crosswalk_slots', []),
                info.get('intersections', []), settings.asset_lib,
                OBJ_CENTER, width=settings.centerline_width,
                sep=settings.centerline_sep, lift=settings.centerline_lift,
                xwalk_gap=settings.crosswalk_gap,
                xwalk_depth=(4.0 * (settings.road_width / 6.0) * settings.crosswalk_scale
                              + settings.line_xwalk_gap),
                road_w=settings.road_width,
                radius_ratio=settings.corner_radius_ratio,
                arc_segments=settings.corner_segments)
            info['centerline'] = cinfo
            _apply_line_mat(_before, _line_mat(settings, "centerline_obj"))
            if cerr:
                self.report({'ERROR'}, cerr)

        if settings.gen_crosswalk:
            from .crosswalk import place_crosswalks
            col0 = obj.users_collection[0] if obj.users_collection else context.scene.collection
            cinfo, cerr = place_crosswalks(col0, info.get('crosswalk_slots', []),
                                           settings.asset_lib, settings.crosswalk_obj,
                                           gap=settings.crosswalk_gap,
                                           scale=settings.crosswalk_scale,
                                           lift=settings.crosswalk_lift)
            info['crosswalk'] = cinfo
            if cerr:
                self.report({'ERROR'}, cerr)

        if settings.gen_blocks or settings.gen_buildings:
            from .blocks import block_polygons, fill_faces, random_buildings
            inset = sw_w if settings.gen_sidewalk else 0.0
            zg = settings.sidewalk_height if settings.gen_sidewalk else 0.0
            polys = block_polygons(pav_verts, pav_faces, inset)
            if settings.gen_blocks:
                fv, ffc, finfo = fill_faces(polys, zg)
                base = len(verts)
                verts = verts + fv
                faces = faces + [[i + base for i in f] for f in ffc]
                info['blocks'] = finfo
                n_block_faces = len(ffc)
            if settings.gen_buildings:
                if settings.use_asset:
                    from .blocks import place_asset_buildings
                    col0 = obj.users_collection[0] if obj.users_collection else context.scene.collection
                    ainfo, aerr = place_asset_buildings(
                        col0, polys, zg, settings.asset_lib, settings.asset_coll,
                        count=settings.bld_count,
                        height_min=settings.bld_h_min, height_max=settings.bld_h_max,
                        height_mode=settings.bld_height_mode,
                        height_pct=settings.bld_height_pct,
                        gap=settings.bld_gap, seed=settings.bld_seed,
                        dirs=((0.0, 90.0, 180.0, 270.0) if settings.asset_random_dir else (0.0,)))
                    info['asset_buildings'] = ainfo
                    if aerr:
                        self.report({'ERROR'}, aerr)
                else:
                    bv, bfc, binfo = random_buildings(
                        polys, zg, count=settings.bld_count,
                        height_min=settings.bld_h_min, height_max=settings.bld_h_max,
                        height_mode=settings.bld_height_mode,
                        height_pct=settings.bld_height_pct,
                        gap=settings.bld_gap, seed=settings.bld_seed)
                    base = len(verts)
                    verts = verts + bv
                    faces = faces + [[i + base for i in f] for f in bfc]
                    info['buildings'] = binfo

        if not faces:
            self.report({'ERROR'}, "没算出路面（检查网格是否有孤立的边）")
            return {'CANCELLED'}

        new_me = bpy.data.meshes.new(obj.name + "_Road")
        new_me.from_pydata(verts, [], faces)
        new_me.validate(verbose=False)
        if settings.use_road_mat:
            from .materials import get_material, assign_materials
            rmat = _line_mat(settings, "road_mat_name")
            smat = _line_mat(settings, "sidewalk_mat_name")
            rerr = serr = ""
            if rmat is None:
                rmat, rerr = get_material(settings.asset_lib, "Road_Builder_Aspha01")
            if smat is None:
                smat, serr = get_material(settings.asset_lib, "Road_Builder_Sidewalk")
            if rmat is None:
                self.report({'ERROR'}, rerr)
            else:
                if smat is None:
                    self.report({'WARNING'}, serr)
                minfo = assign_materials(new_me, n_road_faces, n_side_faces, n_block_faces,
                                         rmat, smat, None,
                                         uv_scale=settings.road_mat_uv_scale)
                info['material'] = minfo
        new_me.update()

        new_obj = bpy.data.objects.new(obj.name + "_Road", new_me)
        new_obj["rb_road"] = 1
        col = obj.users_collection[0] if obj.users_collection else context.scene.collection
        col.objects.link(new_obj)
        new_obj.matrix_world = obj.matrix_world.copy()

        for m in obj.modifiers:
            g = getattr(m, "node_group", None)
            if g is not None and g.name == _node_group_name():
                m.show_viewport = False
                m.show_render = False

        self.report(
            {'INFO'},
            "已生成路面 %s：面 %d，顶点 %d（路段 %d + 交叉口补片 %d，退化面 %d）"
            % (new_obj.name, info['faces'], info['verts'],
               info['strips'], info['patches'], info['degenerate'])
        )
        return {'FINISHED'}
