
import math

from .road_surface import _sub, _add, _mul, _dot, _cross, _line_isect


def boundary_edges(verts, faces):
    use = {}
    for f in faces:
        n = len(f)
        for k in range(n):
            a, b = f[k], f[(k + 1) % n]
            key = (a, b) if a < b else (b, a)
            use.setdefault(key, []).append((a, b))
    out = []
    for key, lst in use.items():
        if len(lst) != 1:
            continue
        a, b = lst[0]
        d = _sub(verts[b][:2], verts[a][:2])
        L = math.hypot(d[0], d[1])
        if L < 1e-12:
            continue
        u = (d[0] / L, d[1] / L)
        out.append((a, b, (u[1], -u[0])))
    return out


def chains(edges):
    head = {}
    for k, (a, b, n) in enumerate(edges):
        head.setdefault(a, []).append(k)
    used = [False] * len(edges)
    loops = []
    for k0 in range(len(edges)):
        if used[k0]:
            continue
        loop, k = [], k0
        while not used[k]:
            a, b, n = edges[k]
            used[k] = True
            loop.append([a, b, n])
            cand = [kk for kk in head.get(b, []) if not used[kk]]
            if not cand:
                break
            k = cand[0]
        if len(loop) >= 3:
            loops.append(loop)
    return loops


def loops_of(verts, faces):
    return chains(boundary_edges(verts, faces))


def loop_points(verts, loop):
    m = len(loop)
    P = [verts[loop[k][0]][:2] for k in range(m)]
    Nin = [loop[(k - 1) % m][2] for k in range(m)]
    Nout = [loop[k][2] for k in range(m)]
    return P, Nin, Nout


def loop_area(P):
    s = 0.0
    n = len(P)
    for k in range(n):
        x1, y1 = P[k]
        x2, y2 = P[(k + 1) % n]
        s += x1 * y2 - x2 * y1
    return s * 0.5


def _arc_mid(center, r, a0, a1, seg):
    da = a1 - a0
    while da <= -math.pi:
        da += 2.0 * math.pi
    while da > math.pi:
        da -= 2.0 * math.pi
    seg = max(1, int(seg))
    pts = []
    for k in range(1, seg):
        a = a0 + da * k / float(seg)
        pts.append((center[0] + r * math.cos(a), center[1] + r * math.sin(a)))
    return pts


def offset_loop(verts, loop, width, join_segments=3, smooth_deg=25.0):
    P, Nin, Nout = loop_points(verts, loop)
    m = len(P)
    cos_lim = math.cos(math.radians(smooth_deg))
    info = {'join_arcs': 0, 'miter': 0, 'merged': 0}

    def seg_dir(k):
        d = _sub(P[(k + 1) % m], P[k])
        L = math.hypot(d[0], d[1]) or 1.0
        return (d[0] / L, d[1] / L)

    def cur_radius(k):
        ang = math.acos(max(-1.0, min(1.0, _dot(Nin[k], Nout[k]))))
        if ang < 1e-6:
            return 1e9
        pv1, pv2 = P[(k - 1) % m], P[(k + 1) % m]
        seg = 0.5 * (math.hypot(P[k][0] - pv1[0], P[k][1] - pv1[1]) +
                     math.hypot(pv2[0] - P[k][0], pv2[1] - P[k][1]))
        return seg / ang

    def offset_one(k, w):
        a, b = Nin[k], Nout[k]
        n = _add(a, b)
        L = math.hypot(n[0], n[1])
        n = a if L < 1e-9 else (n[0] / L, n[1] / L)
        return _add(P[k], _mul(n, w))

    groups = []
    for k in range(m):
        pk = P[k]
        a, b = Nin[k], Nout[k]
        if _dot(a, b) >= cos_lim:
            w_eff = width
            if _cross(a, b) < 0.0:
                w_eff = min(width, max(0.0, cur_radius(k) - 1e-3))
            groups.append([offset_one(k, w_eff)])
        elif _cross(a, b) > 0.0:
            q0 = _add(pk, _mul(a, width))
            q1 = _add(pk, _mul(b, width))
            a0 = math.atan2(q0[1] - pk[1], q0[0] - pk[0])
            a1 = math.atan2(q1[1] - pk[1], q1[0] - pk[0])
            groups.append([q0] + _arc_mid(pk, width, a0, a1, join_segments) + [q1])
            info['join_arcs'] += 1
        else:
            up = _sub(pk, P[(k - 1) % m])
            un = _sub(P[(k + 1) % m], pk)
            hit = _line_isect(_add(pk, _mul(a, width)), up,
                              _add(pk, _mul(b, width)), un)
            if hit is None or abs(hit[0]) > width * 6.0:
                q0 = _add(pk, _mul(a, width))
                q1 = _add(pk, _mul(b, width))
                groups.append([((q0[0] + q1[0]) * 0.5, (q0[1] + q1[1]) * 0.5)])
            else:
                groups.append([_add(_add(pk, _mul(a, width)), _mul(up, hit[0]))])
                info['miter'] += 1

    eps = max(1e-4, 0.02 * width)
    single = [len(g) == 1 for g in groups]
    if sum(single) >= 2:
        start = next((k for k in range(m) if not single[k]), None)
        order = list(range(m)) if start is None else [(start + 1 + i) % m for i in range(m - 1)]
        done = set()
        i = 0
        while i < len(order):
            k = order[i]
            if not single[k]:
                i += 1
                continue
            run = [k]
            j = i + 1
            px, py = groups[k][0]
            while j < len(order) and single[order[j]]:
                qx, qy = groups[order[j]][0]
                if math.hypot(qx - px, qy - py) > eps:
                    break
                run.append(order[j])
                j += 1
            if len(run) >= 2:
                anchor_q = groups[run[0]][0]
                lim = max(eps, 0.6 * width)
                while True:
                    kp = (run[0] - 1) % m
                    if not single[kp] or kp in run or kp in done:
                        break
                    q = groups[kp][0]
                    if math.hypot(q[0] - anchor_q[0], q[1] - anchor_q[1]) > lim:
                        break
                    run.insert(0, kp)
                while True:
                    kn = (run[-1] + 1) % m
                    if not single[kn] or kn in run or kn in done:
                        break
                    q = groups[kn][0]
                    if math.hypot(q[0] - anchor_q[0], q[1] - anchor_q[1]) > lim:
                        break
                    run.append(kn)
                p_a, d_a = groups[run[0]][0], seg_dir((run[0] - 1) % m)
                p_b, d_b = groups[run[-1]][0], seg_dir(run[-1])
                hit = _line_isect(p_a, d_a, p_b, d_b)
                if hit is not None and abs(hit[0]) <= width * 8.0 + 1e-9:
                    Q = _add(p_a, _mul(d_a, hit[0]))
                else:
                    Q = (sum(groups[t][0][0] for t in run) / len(run),
                         sum(groups[t][0][1] for t in run) / len(run))
                for t in run:
                    groups[t] = [Q]
                    done.add(t)
                info['merged'] += len(run)
                i = j
            else:
                i += 1
    return groups, info


def flatten(groups):
    pts = []
    for g in groups:
        for p in g:
            if not pts or abs(p[0] - pts[-1][0]) > 1e-9 or abs(p[1] - pts[-1][1]) > 1e-9:
                pts.append(p)
    if len(pts) > 1 and abs(pts[0][0] - pts[-1][0]) <= 1e-9 and abs(pts[0][1] - pts[-1][1]) <= 1e-9:
        pts.pop()
    return pts


def build_sidewalk(verts, faces, width, height, wall=True, join_segments=3,
                   smooth_deg=25.0):
    info = {'loops': 0, 'band': 0, 'wall': 0, 'join_arcs': 0, 'miter': 0, 'merged_total': 0, 'flipped': 0, 'skipped': 0}
    z0 = [(v[2] if len(v) > 2 else 0.0) for v in verts]
    loops = loops_of(verts, faces)

    sv = []
    svf = []
    cache = {}

    def vid(p, z):
        key = (round(p[0], 6), round(p[1], 6), round(z, 6))
        i = cache.get(key)
        if i is None:
            i = len(sv)
            cache[key] = i
            sv.append((p[0], p[1], z))
        return i

    for loop in loops:
        m = len(loop)
        if m < 3:
            continue
        info['loops'] += 1
        P = [verts[loop[k][0]][:2] for k in range(m)]
        ZZ = [z0[loop[k][0]] for k in range(m)]
        off, oinfo = offset_loop(verts, loop, width, join_segments, smooth_deg)
        info['join_arcs'] += oinfo['join_arcs']
        info['miter'] += oinfo['miter']
        info['merged_total'] += oinfo.get('merged', 0)

        for k in range(m):
            k2 = (k + 1) % m
            p0, p1 = P[k], P[k2]
            za, zb = ZZ[k], ZZ[k2]
            top_a, top_b = za + height, zb + height
            q0 = off[k][-1]
            q1 = off[k2][0]
            if abs(q0[0] - q1[0]) < 1e-9 and abs(q0[1] - q1[1]) < 1e-9:
                quad = [vid(q0, top_a), vid(p1, top_b), vid(p0, top_a)]
            else:
                quad = [vid(q0, top_a), vid(q1, top_b), vid(p1, top_b), vid(p0, top_a)]
            poly = [sv[i][:2] for i in quad]
            a2 = 0.0
            for j in range(len(poly)):
                x1, y1 = poly[j]; x2, y2 = poly[(j + 1) % len(poly)]
                a2 += x1 * y2 - x2 * y1
            if a2 < -1e-12:
                quad = list(reversed(quad))
                info['flipped'] += 1
                a2 = -a2
            if a2 <= 1e-9:
                info['skipped'] += 1
                continue
            svf.append(quad)
            info['band'] += 1
            if wall:
                svf.append([vid(p0, za), vid(p1, zb), vid(p1, top_b), vid(p0, top_a)])
                info['wall'] += 1
        for k in range(m):
            arc = off[k]
            if len(arc) < 3:
                continue
            pk = P[k]
            za, top_a = ZZ[k], ZZ[k] + height
            for j in range(len(arc) - 1):
                a0, a1 = arc[j], arc[j + 1]
                svf.append([vid(pk, top_a), vid(a0, top_a), vid(a1, top_a)])
                if wall:
                    svf.append([vid(a1, top_a), vid(a0, top_a), vid(a0, za), vid(a1, za)])
    return sv, svf, info